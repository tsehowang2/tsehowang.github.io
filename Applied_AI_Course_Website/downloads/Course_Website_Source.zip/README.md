# Editable course website source

The Markdown, notebooks, translation dictionaries and browser assets are the editable source. HTML and both search indexes are generated together.

1. Use Python 3.12 or 3.13 and install `python -m pip install -r requirements.txt`. Node.js must be on PATH for JavaScript syntax checks.
2. Edit course notes under `outputs/llm_course_v2/lectures/`, notebooks under `notebooks/`, and the corresponding English→Hong Kong Chinese entries under `work/zh_*.json` or `work/v3_zh_*.json`. Technical terms and example sentences remain English.
3. Run `python build.py` from this folder. It builds the course download, English pages, Chinese pages, concise slides, diagrams, inline reference links, both search indexes and the final ZIP. It runs page/link/JavaScript checks before packaging.
4. Upload the contents of `outputs/ai_course_website_bilingual/` or the resulting website ZIP to your GitHub Pages root.

Do not edit the generated search index separately. HTML is formatted over many lines to make inspection easier. `work/enhance_course_v3.py` controls the reader/slides interface and worked diagrams; `reader-v3.css` and `reader-v3.js` style and operate it. Keep custom source files in `source_manifest.json` so they are included in the downloadable source archive.

Model downloads and GPU experiments are separate from building this static website. See the course validation notes for exactly which experiments were run.
