from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlsplit,unquote
import subprocess,json,re,hashlib
B=Path(__file__).resolve().parents[1];R=B/'outputs/ai_course_website_bilingual';S=B/'outputs/ai_course_website_v2'
pages={p.resolve():BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser') for p in R.rglob('*.html')};errors=[];links=0;slides=0;codes=0
for p,s in pages.items():
    rel=p.relative_to(R);zh=rel.parts[0]=='zh-HK';local=Path(*rel.parts[1:]) if zh else rel
    if len(s.select('h1'))!=1:errors.append([str(rel),'h1 count'])
    ids=[t['id'] for t in s.select('[id]')]
    if len(ids)!=len(set(ids)):errors.append([str(rel),'duplicate ids'])
    for el in s.select('a[href],script[src],link[href],img[src]'):
        v=el.get('href',el.get('src'));u=urlsplit(v)
        if u.scheme or u.netloc:continue
        target=(p.parent/unquote(u.path)).resolve() if u.path else p
        links+=1
        if not target.exists():errors.append([str(rel),v,'missing target'])
        elif u.fragment and target in pages and not pages[target].find(id=unquote(u.fragment)):errors.append([str(rel),v,'missing fragment'])
    if local.parts[0]=='lectures':
        deck=s.select_one('.lecture-deck');reader=s.select_one('#full-notes')
        if not deck.has_attr('hidden'):errors.append([str(rel),'slides must initially be hidden'])
        if reader.has_attr('hidden'):errors.append([str(rel),'reader initially hidden'])
        if len(s.select('.lesson-mode [data-mode]'))!=2:errors.append([str(rel),'mode tabs'])
        for t in s.select('.slide-stage'):
            if any(x in t.get_text() for x in ['Start with an example','Build the mechanism','Go deeper and check']):errors.append([str(rel),'generic slide stage'])
        original=BeautifulSoup((S/local).read_text(encoding='utf-8'),'html.parser')
        if [e.get_text() for e in original.select('#full-notes pre code')]!=[e.get_text() for e in reader.select('pre code')]:errors.append([str(rel),'reader code changed'])
    if zh:
        en=pages[(R/local).resolve()]
        if [e.get_text() for e in en.select('pre code')]!=[e.get_text() for e in s.select('pre code')]:errors.append([str(rel),'translated code differs'])
        if [e.get('data-answer-key') for e in en.select('[data-answer-key]')]!=[e.get('data-answer-key') for e in s.select('[data-answer-key]')]:errors.append([str(rel),'answer keys changed'])
        if s.html['lang']!='zh-HK':errors.append([str(rel),'language tag'])
    codes+=len(s.select('pre code'));slides+=len(s.select('[data-slide]'))
    # Structural HTML should be reviewable without a single huge generated line.
    if len(p.read_text(encoding='utf-8').splitlines())<25:errors.append([str(rel),'minified HTML'])
for js in R.rglob('*.js'):
    check=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
    if check.returncode:errors.append([str(js),'javascript syntax',check.stderr[:200]])
for root in [R,R/'zh-HK']:
    text=(root/'assets/search-index.js').read_text(encoding='utf-8');index=json.loads(text.removeprefix('window.COURSE_SEARCH=').removesuffix(';'))
    if len(index)!=106:errors.append([str(root),'search count',len(index)])
    for item in index:
        if not (root/item['path']).exists():errors.append(['search target',item['path']])
        if item['type']=='lecture' and item['text'].count('Read the worked explanation')>1:errors.append([item['path'],'slides duplicated in search'])
report={'html_pages':len(pages),'links_checked':links,'slides_both_languages':slides,'displayed_code_blocks':codes,'english_chinese_same_code':True,'reader_slide_modes':'checked on all 64 lecture pages','source_archive_present':(R/'downloads/Course_Website_Source.zip').exists(),'errors':errors}
(B/'work/v3_site_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2));assert not errors
