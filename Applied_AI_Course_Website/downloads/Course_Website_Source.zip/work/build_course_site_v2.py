from pathlib import Path
import html,json,re,shutil,zipfile

BASE=Path(__file__).resolve().parents[1]
COURSE=BASE/'outputs'/'llm_course_v2'
SITE=BASE/'outputs'/'ai_course_website_v2'
for folder in ['assets','lectures','tutorials','tests','downloads/notebooks','downloads/scripts']:
    (SITE/folder).mkdir(parents=True,exist_ok=True)
tick=chr(96)

def esc(s):return html.escape(str(s),quote=True)
def inline(text):
    text=esc(text)
    text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',text)
    text=re.sub(tick+'([^'+tick+']+)'+tick,r'<code>\1</code>',text)
    return re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',text)

def md(src):
    lines=src.splitlines();out=[];para=[];i=0;listing=None;anchors={}
    def flush():
        if para:out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
    def close():
        nonlocal listing
        if listing:out.append('</'+listing+'>');listing=None
    while i<len(lines):
        line=lines[i]
        if line.startswith(tick*3):
            flush();close();language=line[3:].strip();code=[];i+=1
            while i<len(lines) and not lines[i].startswith(tick*3):code.append(lines[i]);i+=1
            out.append(codeblock('\n'.join(code),language or 'Code'))
        elif re.match(r'^#{1,6} ',line):
            flush();close();level=len(line)-len(line.lstrip('#'));label=line[level+1:]
            anchor=re.sub(r'[^a-z0-9]+','-',label.lower()).strip('-')
            anchors[anchor]=anchors.get(anchor,0)+1
            if anchors[anchor]>1:anchor+='-'+str(anchors[anchor])
            out.append(f'<h{level} id="{anchor}">'+inline(label)+f'</h{level}>')
        elif line.startswith('|') and i+1<len(lines) and re.match(r'^\|[\s:|\-]+\|$',lines[i+1]):
            flush();close();headers=[c.strip() for c in line.strip('|').split('|')]
            out.append('<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+inline(c)+'</th>' for c in headers)+'</tr></thead><tbody>')
            i+=2
            while i<len(lines) and lines[i].startswith('|'):
                cells=[c.strip() for c in lines[i].strip('|').split('|')]
                out.append('<tr>'+''.join('<td>'+inline(c)+'</td>' for c in cells)+'</tr>');i+=1
            out.append('</tbody></table></div>');continue
        elif re.match(r'^(- |\d+\. )',line):
            flush();kind='ol' if re.match(r'^\d+\. ',line) else 'ul'
            if listing!=kind:close();out.append('<'+kind+'>');listing=kind
            out.append('<li>'+inline(re.sub(r'^(- |\d+\. )','',line))+'</li>')
        elif not line.strip():flush();close()
        else:close();para.append(line)
        i+=1
    flush();close();return '\n'.join(out)

def codeblock(code,label='Python'):
    return '<div class="code-block"><div class="code-bar"><span>'+esc(label)+'</span><button type="button" class="copy-code">Copy code</button></div><pre><code>'+esc(code)+'</code></pre></div>'

lectures=[]
for p in sorted((COURSE/'lectures').glob('0[1-4]*.md')):
    content=p.read_text(encoding='utf-8')
    for match in re.finditer(r'^## Week (\d+) (.+)\n([\s\S]*?)(?=^## Week \d+ |\Z)',content,re.M):
        n,title,body=match.groups()
        lectures.append({'week':int(n),'title':title,'body':body.strip()})
assert len(lectures)==32
labs=[]
guide=(COURSE/'tutorials/LAB_GUIDE.md').read_text(encoding='utf-8')
for p in sorted((COURSE/'notebooks').glob('*.ipynb')):
    nb=json.loads(p.read_text(encoding='utf-8'));n=nb['metadata']['course']['lab']
    title=''.join(nb['cells'][0]['source']).splitlines()[0].split(' ',4)[-1]
    title=p.stem[3:].replace('_',' ').capitalize()
    found=re.search(r'^## Lab '+f'{n:02d}'+r' .+\n([\s\S]*?)(?=^## Lab |\Z)',guide,re.M)
    labs.append({'number':n,'title':title,'nb':nb,'file':p.name,'guide':found.group(1).strip()})

def week_sections(path):
    text=path.read_text(encoding='utf-8')
    return {int(n):body.strip() for n,body in re.findall(r'^## Week (\d+)\n([\s\S]*?)(?=^## Week |\Z)',text,re.M)}
tests=week_sections(COURSE/'assessments/WEEKLY_TESTS.md')
solutions=week_sections(COURSE/'solutions/WEEKLY_SOLUTIONS.md')
SEARCH=[]
WIDGETS={1:'prediction',2:'tokens',3:'geometry',4:'probabilities',6:'mixture',8:'attention',9:'attention',10:'block',13:'generation',15:'diffusion',16:'block',17:'geometry',18:'retrieval',19:'rag',20:'retrieval',22:'memory',25:'lora',27:'agent',28:'agent'}
WIDGET_NAMES={'prediction':'A missing word and a tiny dataset','tokens':'Words become row numbers','probabilities':'Scores become probabilities','mixture':'Attention starts with a mixture','block':'The transformer block','geometry':'Embedding geometry','attention':'Inside scaled causal attention','generation':'One token at a time','diffusion':'From a signal to noise','retrieval':'Hybrid retrieval','rag':'Follow the evidence','memory':'Where GPU memory goes','lora':'A low rank update','agent':'The agent and its controller'}
WIDGET_DESCS={'prediction':'Change the number of observed bus and train journeys. Counts become conditional probabilities.','tokens':'Step through an ordinary sentence. Token IDs are arbitrary indices, not numerical meanings.','probabilities':'Change one score and the temperature, then inspect all three normalized probabilities.','mixture':'Change how much of each information card enters the weighted sum. Start here before queries and keys.','block':'Trace the residual stream through communication and feature processing.','geometry':'Compare vector direction and magnitude using exact arithmetic.','attention':'Select a query and inspect scoring, scaling, the causal mask and value mixing.','generation':'Inspect next-token prediction and a growing prefix. The displayed probabilities are illustrative.','diffusion':'Move along a deterministic forward-noising schedule. This is not a trained image generator.','retrieval':'Inspect rank fusion and candidate recall after understanding exact vector search.','rag':'Follow a versioned question through evidence selection and a supported answer.','memory':'Compare parameter state and context-dependent cache estimates.','lora':'Follow the frozen matrix and a trainable low-rank update.','agent':'Inspect typed proposals, validators, observations and bounded termination.'}

def widget(name):
    return '<section class="visual-lesson" aria-label="'+esc(WIDGET_NAMES[name])+'"><div class="eyebrow">Explore the mechanism</div><h2>'+esc(WIDGET_NAMES[name])+'</h2><p class="visual-intro">'+esc(WIDGET_DESCS[name])+'</p><div data-widget="'+name+'"><p>Enable JavaScript to use this illustration. The lecture notes below explain the same mechanism.</p></div></section>'

def sidebar(prefix,week=0):
    out=['<a class="side-home" href="'+prefix+'index.html">Course overview</a>']
    for sem,start in [(1,1),(2,17)]:
        opened=' open' if (start<=week<start+16 or (not week and sem==1)) else ''
        out.append(f'<details class="semester-nav"{opened}><summary>Semester {sem}<span>Weeks {start}–{start+15}</span></summary><ol start="{start}">')
        for item in lectures[start-1:start+15]:
            n=item['week'];active=' aria-current="page"' if week==n else ''
            out.append(f'<li><a href="{prefix}lectures/{n:02d}.html"{active}><span class="week-number">{n:02d}</span><span>{esc(item["title"])}</span><span class="week-tick" data-week-tick="{n}"></span></a></li>')
        out.append('</ol></details>')
    out.append('<div class="side-links"><a href="'+prefix+'visuals.html">Visual laboratory <span>14 interactive lessons</span></a><a href="'+prefix+'project.html">Documentation assistant <span>Your capstone project</span></a><a href="'+prefix+'resources.html">Readings and setup</a></div>')
    return ''.join(out)

def page(path,title,content,week=0,kind='guide',description='Applied generative AI and LLM systems course material'):
    path=Path(path);prefix='../' if len(path.parts)>1 else ''
    is_home=str(path)=='index.html'
    html_doc='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'''
    html_doc+=f'<title>{esc(title)} · Applied AI</title><meta name="description" content="{esc(description)}"><meta name="theme-color" content="#173c36"><link rel="icon" href="{prefix}assets/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="{prefix}assets/style.css"><link rel="stylesheet" href="{prefix}assets/slides.css">'
    html_doc+=f'<script>window.COURSE_BASE={json.dumps(prefix)};</script><script defer src="{prefix}assets/site-config.js"></script><script defer src="{prefix}assets/search-index.js"></script><script defer src="{prefix}assets/app.js"></script><script defer src="{prefix}assets/visuals.js"></script><script defer src="{prefix}assets/slides.js"></script><script defer src="{prefix}assets/beginner-visuals.js"></script></head>'
    html_doc+=f'<body data-week="{week}" data-page-kind="{kind}"><a class="skip-link" href="#main">Skip to content</a><header class="topbar"><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="course-sidebar">Menu</button><a class="brand" href="{prefix}index.html"><span class="brand-mark" aria-hidden="true">a<span>i</span></span><span>APPLIED AI<small>Principles into practice</small></span></a><nav aria-label="Main navigation"><a href="{prefix}index.html">The course</a><a href="{prefix}visuals.html">Visual lab</a><a href="{prefix}project.html">Project</a></nav><button class="search-open" type="button">Search the course <span aria-hidden="true">/</span></button></header>'
    html_doc+=f'<aside id="course-sidebar" class="sidebar" aria-label="Course chapters">{sidebar(prefix,week)}<div class="side-progress"><div><span>Your progress</span><strong data-progress-count>0 / 32</strong></div><progress max="32" value="0" aria-label="Completed lectures"></progress><small>Saved in this browser</small></div></aside>'
    html_doc+=f'<main id="main" class="main {"home" if is_home else ""}"><div class="content">{content}</div><footer class="footer"><span>Applied AI · An independent self-study course</span><span>32 weeks · 10 hours per week</span><a href="{prefix}resources.html#about-this-course">About and sources</a></footer></main>'
    html_doc+='<dialog class="search-dialog" aria-labelledby="search-title"><div class="dialog-head"><h2 id="search-title">Find a concept</h2><button class="search-close" type="button" aria-label="Close search">Close</button></div><label class="sr-only" for="course-search">Search all lectures and tutorials</label><input id="course-search" type="search" placeholder="Try attention, fine-tuning, or harness…" autocomplete="off"><p class="search-status" aria-live="polite">Search lecture notes, tutorials, tests and readings.</p><div class="search-results"></div></dialog><div class="toast" role="status" aria-live="polite"></div></body></html>'
    (SITE/path).write_text(html_doc,encoding='utf-8')
    SEARCH.append({'title':title,'path':str(path).replace('\\','/'),'type':kind,
                   'text':html.unescape(re.sub(r'<[^>]*>',' ',content))})

def chapter_header(tag,title,sub=''):
    return '<div class="chapter-header"><div class="eyebrow">'+esc(tag)+'</div><h1>'+esc(title)+'</h1>'+('<p class="deck">'+esc(sub)+'</p>' if sub else '')+'</div>'


def slide_deck(lesson):
    parts=re.split(r'^### (.+)$',lesson['body'],flags=re.M)
    sections=[]
    if parts[0].strip():sections.append(('Before you begin',parts[0]))
    sections += [(parts[i],parts[i+1]) for i in range(1,len(parts),2)]
    slides=[]
    for j,(heading,body) in enumerate(sections):
        # Split on paragraph boundaries outside fenced code. Tables stay intact.
        blocks=[];block=[];fenced=False
        for line in body.splitlines():
            if line.startswith(tick*3):fenced=not fenced
            if not line.strip() and not fenced:
                if block:blocks.append('\n'.join(block));block=[]
            else:block.append(line)
        if block:blocks.append('\n'.join(block))
        groups=[];group=[];words=0
        for b in blocks:
            size=len(b.split())
            if group and words+size>155:groups.append(group);group=[];words=0
            group.append(b);words+=size
        if group:groups.append(group)
        for k,g in enumerate(groups):
            stage='Start with an example' if j<2 else 'Build the mechanism' if j<len(sections)*.6 else 'Go deeper and check understanding'
            if 'Further study' in heading or heading.startswith('Review ') or 'deeper pass' in heading:stage='Optional deeper study'
            body_html=re.sub(r' id="[^"]*"','',md('\n\n'.join(g)))
            title=heading+(' · continued' if k else '')
            slides.append('<section class="lecture-slide" data-slide'+(' hidden' if slides else '')+'><div class="slide-stage">'+esc(stage)+'</div><h3>'+esc(title)+'</h3><div class="slide-prose">'+body_html+'</div></section>')
    count=len(slides)
    return '<section class="lecture-deck" id="lecture-slides" aria-label="Lecture slides"><div class="deck-top"><div><div class="eyebrow">Lecture slides · Week '+str(lesson['week']).zfill(2)+'</div><h2>Learn one step at a time.</h2></div><button type="button" class="deck-present">Present</button></div><p class="deck-help">Read each explanation, pause to predict the result, then continue. Use the arrow keys while the presentation is focused. The complete lecture reader is below.</p><div class="slide-viewport" tabindex="0" aria-label="Presentation: use left and right arrow keys">'+''.join(slides)+'</div><div class="deck-controls"><button class="slide-prev" type="button">← Previous</button><span class="slide-counter" aria-live="polite">1 / '+str(count)+'</span><button class="slide-next" type="button">Next →</button></div><label class="slide-jump-label">Go to slide <select class="slide-jump" aria-label="Go to slide">'+''.join('<option value="'+str(i)+'">'+str(i+1)+'</option>' for i in range(count))+'</select></label><button class="deck-all" type="button" aria-pressed="false">Show all slides</button><a class="reader-link" href="#full-notes">Read the complete lecture ↓</a></section>'

for lesson in lectures:
    n=lesson['week'];lab=n;sem=1 if n<=16 else 2
    intro=chapter_header(f'Semester {sem} / Week {n:02d}',lesson['title'])
    intro+=f'<div class="lesson-links"><a href="../tutorials/{lab:02d}.html">Tutorial {lab:02d}</a><a href="../tests/{n:02d}.html">Test your understanding</a><button class="mark-complete" type="button" data-week="{n}" aria-pressed="false">Mark as complete</button></div>'
    intro+=slide_deck(lesson)
    if n in WIDGETS:intro+=widget(WIDGETS[n])
    intro+='<article class="prose full-notes" id="full-notes"><div class="eyebrow">Complete lecture reader</div><h2>Read the full explanation</h2>'+md(lesson['body'])+'</article>'
    prev=f'<a href="{n-1:02d}.html"><small>Previous week</small>{esc(lectures[n-2]["title"])}</a>' if n>1 else '<a href="../index.html"><small>Back to</small>Course overview</a>'
    nex=f'<a href="{n+1:02d}.html"><small>Next week</small>{esc(lectures[n]["title"])}</a>' if n<32 else '<a href="../project.html"><small>Finish with</small>Capstone defense</a>'
    intro+='<nav class="chapter-pagination" aria-label="Adjacent lectures">'+prev+nex+'</nav>'
    page(f'lectures/{n:02d}.html',lesson['title'],intro,n,'lecture')

for lab in labs:
    n=lab['number'];start=n
    content=chapter_header(f'Tutorial {n:02d} / Week {start}',lab['title'],
        'Read the walkthrough, inspect the code, then run the notebook when you are ready.')
    content+=f'<div class="lesson-links"><a href="../lectures/{start:02d}.html">Lecture {start:02d}</a><a class="button dark" href="../downloads/notebooks/{lab["file"]}" download>Download notebook</a><a class="colab-link" data-notebook="downloads/notebooks/{lab["file"]}" href="https://colab.research.google.com/" target="_blank" rel="noopener">Open in Colab ↗</a></div>'
    content+='<p class="save-note">When you run this notebook, also <a href="../downloads/Applied_Generative_AI_Course.zip" download>download and extract the full course pack</a> for the support files and teaching data. You can <a href="../implementation.html">read the support implementations</a> here.</p>'
    content+='<article class="prose"><h2>What to do and what to submit</h2>'+md(lab['guide'])+'<h2>Guided walkthrough</h2>'
    step=0
    for i,cell in enumerate(lab['nb']['cells']):
        src=''.join(cell['source'])
        if i==0:continue
        if cell['cell_type']=='markdown':content+=md(src)
        elif i==1:
            content+='<details class="setup-details"><summary>Notebook environment and course files</summary><p>This cell finds the extracted course files. It is needed when running the notebook.</p>'+codeblock(src)+'</details>'
        else:
            step+=1;content+=f'<h3>Code step {step}</h3>'+codeblock(src)
    content+='</article><div class="end-note">Reading the code is the first step. Complete the independent experiment and keep your actual results before marking this lab finished.</div>'
    page(f'tutorials/{n:02d}.html',f'Tutorial {n:02d} {lab["title"]}',content,start,'tutorial')
    shutil.copyfile(COURSE/'notebooks'/lab['file'],SITE/'downloads/notebooks'/lab['file'])
    shutil.copyfile((COURSE/'notebooks'/lab['file']).with_suffix('.py'),SITE/'downloads/scripts'/Path(lab['file']).with_suffix('.py').name)

for n in range(1,33):
    content=chapter_header(f'Weekly practice / Week {n:02d}',lectures[n-1]['title'],
        'Attempt the questions before opening the worked solutions. Allow 35–45 minutes.')
    content+=f'<div class="lesson-links"><a href="../lectures/{n:02d}.html">Back to lecture</a><span>10 points · Q1 3 · Q2 3 · Q3 4</span></div><article class="prose">'
    qs=re.findall(r'^\d+\. (.*?)(?=^\d+\. |\Z)',tests[n],re.M|re.S)
    ans=re.findall(r'^\d+\. (.*?)(?=^\d+\. |\Z)',solutions[n],re.M|re.S)
    assert len(qs)==len(ans)==3
    for i,(q,a) in enumerate(zip(qs,ans),1):
        key=f'week-{n}-question-{i}'
        content+=f'<section class="test-question"><div class="eyebrow">Question {i}</div>{md(q.strip())}<label for="{key}">Your working notes</label><textarea id="{key}" data-answer-key="{key}" rows="4" placeholder="Write your reasoning before checking the solution…"></textarea><details class="solution"><summary>Show worked solution</summary>{md(a.strip())}</details></section>'
    content+='</article><p class="save-note">Your working notes stay in this browser. Compare your reasoning with the solution; answers are not automatically graded.</p>'
    page(f'tests/{n:02d}.html',f'Week {n:02d} practice',content,n,'test')

exam_text=(COURSE/'assessments/EXAMS.md').read_text(encoding='utf-8')
exam_solutions=(COURSE/'solutions/EXAM_SOLUTIONS.md').read_text(encoding='utf-8')
for sem in [1,2]:
    exam=re.search(r'^## Semester exam '+str(sem)+r'\n([\s\S]*?)(?=^## Semester exam |\Z)',exam_text,re.M).group(1)
    answers=re.search(r'^## Semester exam '+str(sem)+r'\n([\s\S]*?)(?=^## Semester exam |\Z)',exam_solutions,re.M).group(1)
    content=chapter_header(f'Semester {sem} / Examination',f'Semester {sem} examination','Two hours · 100 points · Attempt without notes or an LLM.')
    content+='<article class="prose">'+md(exam)+'<details class="solution exam-solution"><summary>Open the complete marking guide after your attempt</summary>'+md(answers)+'</details></article>'
    page(f'tests/semester-{sem}.html',f'Semester {sem} examination',content,sem*16,'exam')

checkpoint_content=chapter_header('Pause and check the foundations','Checkpoint quizzes','Short diagnostic checks after weeks 4 and 8. Attempt them before opening the solution notes.')
checkpoint_content+='<article class="prose">'
for name in ['A','B']:
    section=re.search(r'^## Checkpoint '+name+r' (.+)\n([\s\S]*?)(?=^## |\Z)',exam_text,re.M)
    checkpoint_content+='<h2 id="checkpoint-'+name.lower()+'">Checkpoint '+name+' '+esc(section.group(1))+'</h2>'+md(section.group(2))
checkpoint_answer=re.search(r'^## Checkpoint calculations\n([\s\S]*?)(?=^## |\Z)',exam_solutions,re.M).group(1)
checkpoint_content+='<details class="solution"><summary>Show checkpoint calculation guide</summary>'+md(checkpoint_answer)+'<p>Use the matching weekly practice solutions for the conceptual questions: <a href="03.html">week 3</a>, <a href="04.html">week 4</a>, <a href="06.html">week 6</a>, <a href="07.html">week 7</a> and <a href="08.html">week 8</a>.</p></details></article>'
page('tests/checkpoints.html','Foundation checkpoint quizzes',checkpoint_content,kind='test')
implementation=chapter_header('Inspect the implementation','Reference code','The small, readable components behind the tutorials. These code samples do not execute on the website.')
implementation+='<article class="prose">'
for source,label in [('coursekit/core.py','Retrieval metrics tools and controller'),('coursekit/server.py','Local API'),('tests/test_contracts.py','Contract tests'),('cuda/vector_add.cu','CUDA vector addition')]:
    anchor=source.replace('/','-').replace('.','-')
    implementation+='<details class="setup-details" id="'+anchor+'"><summary>'+esc(label)+' · '+esc(source)+'</summary>'+codeblock((COURSE/source).read_text(encoding='utf-8'),'CUDA C++' if source.endswith('.cu') else 'Python')+'</details>'
implementation+='</article>'
page('implementation.html','Reference implementation code',implementation,kind='tutorial')

visuals=chapter_header('See the mechanism','The visual laboratory','Small, interactive explanations. Change one thing, inspect what happens, then connect it to the lecture.')
visuals+='<nav class="visual-index" aria-label="Visual lessons">'+''.join(f'<a href="#{name}">{esc(title)}</a>' for name,title in WIDGET_NAMES.items())+'</nav>'
for name in WIDGET_NAMES:visuals+=f'<div id="{name}" class="visual-anchor">'+widget(name)+'</div>'
page('visuals.html','Visual laboratory',visuals,kind='visuals')

project=chapter_header('Build something you can defend','Your documentation assistant','A second-semester project, begun after you understand the transformer.')
project+='<article class="prose">'+md((COURSE/'project/CAPSTONE.md').read_text(encoding='utf-8').split('\n',1)[1])
project+='<h2>Keep an experiment record</h2>'+md((COURSE/'project/EXPERIMENT_TEMPLATE.md').read_text(encoding='utf-8').split('\n',1)[1])
project+='<h2>Release and incident rehearsal</h2>'+md((COURSE/'project/RELEASE_CHECKLIST.md').read_text(encoding='utf-8').split('\n',1)[1])+'</article>'
page('project.html','Documentation assistant capstone',project,kind='project')

resources=chapter_header('Keep the sources close','Readings, setup and course information')
resources+='<div class="lesson-links"><a href="downloads/Applied_Generative_AI_Course.zip" download>Download the full course pack</a><a href="supplement.html">Worked supplement</a><a href="schedule.html">Full syllabus</a><a href="tests/checkpoints.html">Checkpoint quizzes</a><a href="implementation.html">Reference code</a></div><article class="prose">'
resources+='<h2>Setup and compute plan</h2>'+md((COURSE/'SETUP.md').read_text(encoding='utf-8').split('\n',1)[1])
resources+='<h2>Primary references</h2>'+md((COURSE/'REFERENCES.md').read_text(encoding='utf-8').split('\n',1)[1])
resources+='<h2 id="about-this-course">About this course</h2><p>Independent original self-study material. There is no Stanford or NTU affiliation or certificate. The teaching approach combines intuitive explanations, mechanisms, implementation and controlled experiments. Links to the instructors’ public materials are optional references, not copied lecture content.</p>'
resources+='<h2>Validation and limits</h2>'+md((COURSE/'VALIDATION.md').read_text(encoding='utf-8').split('\n',1)[1])+'</article>'
page('resources.html','Readings and setup',resources,kind='resources')
page('supplement.html','Worked supplement',chapter_header('Extra mechanisms and examples','The worked supplement')+'<article class="prose">'+md((COURSE/'lectures/05_worked_supplement.md').read_text(encoding='utf-8').split('\n',1)[1])+'</article>')
page('schedule.html','Full syllabus',chapter_header('Your study plan','Two semesters, one connected project')+'<article class="prose">'+md((COURSE/'SYLLABUS.md').read_text(encoding='utf-8').split('\n',1)[1])+'</article>')

hero='''<section class="hero"><div class="eyebrow">A two semester self study course</div><h1>Understand the model.<br><em>Build the system.</em></h1><p class="hero-deck">Begin with “I go to school by bus.” Build language models and transformers step by step, then study retrieval, agents and reliable delivery in semester two.</p><div class="hero-actions"><a class="button dark" href="lectures/01.html">Begin with week 01 <span aria-hidden="true">→</span></a><a class="text-link" href="visuals.html">Explore the visual lab ↗</a></div><div class="hero-facts"><span>32 weeks</span><span>10 hours a week</span><span>32 weekly tutorials</span></div></section>'''
hero+='''<section class="home-intro"><div><div class="eyebrow">How the course works</div><h2>A clear path from<br>intuition to evidence.</h2></div><div><p>Each week opens with an ordinary example, develops the mechanism and then goes deeper. Detailed HTML slides sit beside complete lecture notes, a guided tutorial and worked practice questions.</p><p>Semester one is for language models and transformers. Semester two turns that understanding into a documentation assistant, from search to evaluation, tools and release.</p><a class="text-link" href="schedule.html">See the workload and syllabus →</a></div></section>'''
hero+='<section class="featured-visual"><div><div class="eyebrow">A first look inside</div><h2>Attention is a weighted mixture.</h2><p>Choose a token. See the scores, remove future positions, and follow the weighted values.</p><a class="text-link" href="visuals.html#attention">Open the interactive explanation →</a></div><div class="attention-preview" aria-label="Illustrative causal attention weights"><div class="mini-label">Query → visible context</div>'+''.join('<div class="preview-row">' + ''.join(f'<span style="--v:{(i+j+1)%5/5 if j<=i else 0}" class="{"masked" if j>i else ""}"></span>' for j in range(5))+'</div>' for i in range(5))+'<div class="mini-label">Future positions are masked</div></div></section>'
for sem,start in [(1,1),(2,17)]:
    hero+=f'<section class="curriculum" id="semester-{sem}"><div class="section-heading"><div><div class="eyebrow">Semester {sem} · Weeks {start}–{start+15}</div><h2>{"Language models and transformers" if sem==1 else "Applications and delivery"}</h2></div><a href="tests/semester-{sem}.html">Semester examination ↗</a></div><div class="week-grid">'
    for item in lectures[start-1:start+15]:
        n=item['week'];hero+=f'<a class="week-card" href="lectures/{n:02d}.html"><span class="card-week">WEEK {n:02d}<span data-week-tick="{n}"></span></span><h3>{esc(item["title"])}</h3><span class="card-foot">Read lecture <span aria-hidden="true">↗</span></span></a>'
    hero+='</div></section>'
hero+='<section class="project-feature"><div class="eyebrow">Your capstone</div><h2>A technical documentation assistant.<br>With results you can defend.</h2><p>Version-aware retrieval, cited answers, bounded tools, measured adaptation, an API, and a clear release decision.</p><a class="button light" href="project.html">Explore the project →</a></section>'
hero+='<section class="home-start"><h2>Start with a question.</h2><p>What might come after “I go to school by”? Your first lecture begins with a few sentences and a count, before introducing any neural network.</p><a class="text-link" href="lectures/01.html">Open your first lecture →</a></section>'
page('index.html','Applied AI',hero,kind='home')

(SITE/'assets/search-index.js').write_text('window.COURSE_SEARCH='+json.dumps(SEARCH,ensure_ascii=False)+';',encoding='utf-8')
shutil.copyfile(BASE/'outputs/Applied_Generative_AI_Course_v2.zip',SITE/'downloads/Applied_Generative_AI_Course.zip')
(SITE/'.nojekyll').write_text('')
(SITE/'assets/favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#173c36"/><text x="12" y="45" fill="#f1eddc" font-family="Georgia,serif" font-size="40">ai</text></svg>')
print('Built',len(SEARCH),'searchable pages from the complete course.')
