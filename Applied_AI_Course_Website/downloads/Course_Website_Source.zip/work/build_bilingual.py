from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
import json, shutil, re, zipfile, subprocess

B=Path(__file__).resolve().parents[1]
SOURCE=B/'outputs/ai_course_website_v2'
DEST=B/'outputs/ai_course_website_bilingual'
ZH=DEST/'zh-HK'
MAPFILES=['zh_01_08.json','zh_09_16.json','zh_17_24.json','zh_25_32.json','zh_practice.json','zh_guides.json','zh_dynamic.json','zh_extra.json','zh_review.json']

def dictionary():
    d={}
    for name in MAPFILES+[p.name for p in sorted((B/'work').glob('v3_zh_*.json'))]:
        p=B/'work'/name
        if p.exists():
            data=json.loads(p.read_text(encoding='utf-8-sig'))
            assert isinstance(data,dict),(name,type(data))
            d.update(data)
    protected={'矩陣':'matrix','正規化':'normalize','歸一化':'normalize','提示詞':'prompt','詞元':'token','權杖':'token','點積':'dot product','函數':'function'}
    for k,v in d.items():
        if not isinstance(v,str):raise TypeError(k)
        for chinese,english in protected.items():v=v.replace(chinese,english)
        d[k]=v
    return d

def translate(s,d):
    if s in d:return d[s]
    core=s.strip()
    if core in d:return s[:len(s)-len(s.lstrip())]+d[core]+s[len(s.rstrip()):]
    return s

def build():
    d=dictionary()
    shutil.copytree(SOURCE,DEST,dirs_exist_ok=True)
    for asset in ['locale.js','bilingual.css']:
        shutil.copyfile(B/'work'/asset,DEST/'assets'/asset)
    patterns=B/'work/locale_patterns.js'
    if patterns.exists():(DEST/'assets/locale-patterns.js').write_text('window.COURSE_LOCALE_PATTERNS='+patterns.read_text(encoding='utf-8').strip()+';',encoding='utf-8')
    app=DEST/'assets/app.js'
    app.write_text(app.read_text(encoding='utf-8').replace("location.pathname.split('/').filter(Boolean)","location.pathname.split('/').filter(Boolean).filter(s=>s!=='zh-HK')"),encoding='utf-8')
    ZH.mkdir(exist_ok=True)
    uncovered={}
    for p in sorted(SOURCE.rglob('*.html')):
        rel=p.relative_to(SOURCE);depth=len(rel.parts)-1;prefix='../'*depth
        english=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
        nav=english.select_one('.topbar nav')
        if nav:
            a=english.new_tag('a',href=prefix+'zh-HK/'+rel.as_posix(),hreflang='zh-HK')
            a['class']='language-switch';a['lang']='zh-HK';a.string='繁體中文';nav.append(a)
        link=english.new_tag('link',rel='alternate',hreflang='zh-HK',href=prefix+'zh-HK/'+rel.as_posix());english.head.append(link)
        css=english.new_tag('link',rel='stylesheet',href=prefix+'assets/bilingual.css');english.head.append(css)
        (DEST/rel).write_text(str(english),encoding='utf-8')
        soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
        soup.html['lang']='zh-HK'
        for node in list(soup.find_all(string=True)):
            if node.parent.name in ['script','style'] or node.find_parent(['code','pre']):continue
            raw=str(node)
            if raw.strip() and re.search('[A-Za-z]',raw):
                replacement=translate(raw,d)
                if replacement!=raw:node.replace_with(NavigableString(replacement))
                elif len(raw.strip())>45:
                    uncovered.setdefault(raw.strip(),[]).append(rel.as_posix())
        for tag in soup.find_all(True):
            for attr in ['aria-label','placeholder','title','alt']:
                if isinstance(tag.get(attr),str):tag[attr]=translate(tag[attr],d)
            for attr in ['href','src']:
                v=tag.get(attr)
                if not isinstance(v,str):continue
                # Share code/notebook downloads and original assets; local pages stay translated.
                if re.match(r'^(?:\.\./)*downloads/',v) or re.match(r'^(?:\.\./)*assets/',v):
                    tag[attr]='../'+v
        if soup.title:
            source_title=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser').title.get_text()
            heading=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser').select_one('h1')
            if heading:
                title=heading.get_text(' ',strip=True)
                soup.title.string=translate(title,d)+' · Applied AI'
        # Shared scripts, but the translated search index lives with translated pages.
        for tag in soup.select('script[src]'):
            if tag['src'].endswith('assets/search-index.js'):tag['src']=prefix+'assets/search-index.js'
        config=soup.new_tag('script');config.string='window.COURSE_LANGUAGE="zh-HK";window.COURSE_TRANSLATIONS='+json.dumps(d,ensure_ascii=False).replace('</','<\\/')+';'
        # Before app scripts execute, expose dictionary. Its DOM observer starts after parsing.
        soup.head.insert(0,config)
        patterns_script=soup.new_tag('script',src='../'+prefix+'assets/locale-patterns.js',defer=True);soup.head.append(patterns_script)
        locale=soup.new_tag('script',src='../'+prefix+'assets/locale.js',defer=True);soup.head.append(locale)
        css=soup.new_tag('link',rel='stylesheet',href='../'+prefix+'assets/bilingual.css');soup.head.append(css)
        nav=soup.select_one('.topbar nav')
        if nav:
            a=soup.new_tag('a',href='../'+prefix+rel.as_posix(),hreflang='en')
            a['class']='language-switch';a['lang']='en';a.string='English';nav.append(a)
        link=soup.new_tag('link',rel='alternate',hreflang='en',href='../'+prefix+rel.as_posix());soup.head.append(link)
        out=ZH/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(str(soup),encoding='utf-8')
    assets=ZH/'assets';assets.mkdir(exist_ok=True)
    index=[]
    for p in sorted(ZH.rglob('*.html')):
        soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');main=soup.select_one('main') or soup
        title=soup.select_one('h1')
        index.append({'title':title.get_text(' ',strip=True) if title else p.stem,'path':p.relative_to(ZH).as_posix(),'type':soup.body.get('data-page-kind','guide'),'text':main.get_text(' ',strip=True)})
    (assets/'search-index.js').write_text('window.COURSE_SEARCH='+json.dumps(index,ensure_ascii=False)+';',encoding='utf-8')
    (B/'work/zh_uncovered.json').write_text(json.dumps(uncovered,ensure_ascii=False,indent=2),encoding='utf-8')
    # Carry the complete translated dictionary once, rather than embedding megabytes in every page.
    (DEST/'assets/translations-zh-HK.js').write_text('window.COURSE_LANGUAGE="zh-HK";window.COURSE_TRANSLATIONS='+json.dumps(d,ensure_ascii=False).replace('</','<\\/')+';',encoding='utf-8')
    for p in ZH.rglob('*.html'):
        soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
        first=soup.head.find('script');first.clear();first['src']='../'+'../'*(len(p.relative_to(ZH).parts)-1)+'assets/translations-zh-HK.js'
        p.write_text(str(soup),encoding='utf-8')
    print(json.dumps({'dictionary':len(d),'pages_per_language':len(index),'uncovered_long_nodes':len(uncovered)},ensure_ascii=False))

if __name__=='__main__':build()
