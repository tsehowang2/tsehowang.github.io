from pathlib import Path
import zipfile
B=Path(__file__).resolve().parents[1];C=B/'outputs/llm_course_v2'
with zipfile.ZipFile(B/'outputs/Applied_Generative_AI_Course_v2.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(C.rglob('*')):
        if p.is_file() and not any(a in ['runs','__pycache__'] for a in p.relative_to(C).parts):z.write(p,Path('llm_course')/p.relative_to(C))
print('Packaged second-edition course.')
