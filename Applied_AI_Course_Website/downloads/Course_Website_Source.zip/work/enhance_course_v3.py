"""Derive readable HTML, presentation summaries, inline visuals and search from sources."""
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
import re,json,copy,math,html
B=Path(__file__).resolve().parents[1];ROOT=B/'outputs/ai_course_website_bilingual'

def fragment(markup):return BeautifulSoup(markup,'html.parser')
def label(zh,en,cn):return cn if zh else en
def flow(title,steps,caption):
    return '<figure class="mechanism-figure"><figcaption>'+html.escape(title)+'</figcaption><ol class="mechanism-flow">'+''.join('<li><span class="mechanism-number">'+f'{i+1:02d}'+'</span><strong>'+html.escape(t)+'</strong><small>'+html.escape(d)+'</small></li>' for i,(t,d) in enumerate(steps))+'</ol><p>'+html.escape(caption)+'</p></figure>'

def visual(week,zh):
    pick=lambda en,cn:label(zh,en,cn)
    if week==3:
        return '<figure class="mechanism-figure"><figcaption>'+pick('One query, two different rankings','同一 query，兩種不同排名')+'</figcaption><svg class="vector-chart" viewBox="0 0 500 290" role="img" aria-label="q=[1,0], a=[0.8,0.6], b=[3,4]"><defs><marker id="vector-arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="context-stroke"/></marker></defs><path d="M45 250 H455 M45 250 V20" stroke="#aab9ae" fill="none"/><path d="M45 250 L101 250" stroke="#ba633b" stroke-width="4" marker-end="url(#vector-arrow)"/><path d="M45 250 L89.8 216.4" stroke="#25816d" stroke-width="4" marker-end="url(#vector-arrow)"/><path d="M45 250 L213 26" stroke="#5752a6" stroke-width="4" marker-end="url(#vector-arrow)"/><text x="106" y="269">q = [1, 0]</text><text x="100" y="207">a = [0.8, 0.6]</text><text x="228" y="40">b = [3, 4]</text></svg><div class="table-wrap"><table><tr><th>Candidate</th><th>dot product</th><th>cosine</th></tr><tr><td>a</td><td>0.8</td><td>0.8</td></tr><tr><td>b</td><td>3.0</td><td>0.6</td></tr></table></div><p>'+pick('Dot product ranks b first; cosine ranks a first. The numeric coordinates are a teaching example.','Dot product 把 b 排第一；cosine 把 a 排第一。座標是教學用數值。')+'</p></figure>'
    if week==6:
        rows=[[.5,.3,.2],[.1,.8,.1],[.2,.2,.6]];names=['go','school','bus']
        return '<figure class="mechanism-figure"><figcaption>'+pick('An attention heatmap with visible numbers','看得見數值的 attention heatmap')+'</figcaption><table class="attention-heatmap"><thead><tr><th>Query / Key</th>'+''.join('<th>'+n+'</th>' for n in names)+'</tr></thead><tbody>'+''.join('<tr><th>'+names[i]+'</th>'+''.join('<td style="background:rgba(37,129,109,'+str(.08+.8*x)+')">'+f'{x:.1f}'+'</td>' for x in row)+'</tr>' for i,row in enumerate(rows))+'</tbody></table><p>'+pick('Each row sums to 1. All three positions are visible here; the causal mask is introduced in week 8. These are attention weights, not entries of the learned projection matrices.','每個 row 的總和為 1。這裏三個 positions 都可見；第 8 週才加入 causal mask。這些是 attention weights，並非學習得到的 projection matrix entries。')+'</p></figure>'
    data={
      2:('Count pairs across this corpus','先點算 corpus 中的 pairs',[('b u s','bus × 4'),('b u s y','busy × 2'),('p l u s','plus × 1')],'Count adjacent pairs over the corpus: (u,s)=7, (b,u)=6. Merge the most frequent pair first.','按 corpus 點算相鄰 pairs：(u,s)=7、(b,u)=6。先合併最常見的 pair。'),
      4:('Scores become a learning signal','Score 變成學習訊號',[('logits','[2, 1, 0]'),('softmax','[0.6652, 0.2447, 0.0900]'),('target: train','−ln(0.2447) ≈ 1.4076')],'Softmax normalizes scores; the target determines which probability enters the loss.','Softmax normalize scores；target 決定哪個 probability 用來計算 loss。'),
      8:('One attention row, in execution order','一個 attention row 的執行次序',[('Compare','QKᵀ / √d_head'),('Restrict','apply mask'),('Normalize','softmax over keys'),('Mix','weights × V')],'Mask the scores before softmax. A hidden future key contributes zero weight.','在 softmax 前 mask scores。不可見的未來 key，其 weight 為零。'),
      9:('RoPE compares different position angles','RoPE 比較不同 position angles',[('q angle','30°'),('k angle','90°'),('relative offset','60°'),('dot product','cos(60°) = 0.5')],'Starting from q=k=[1,0], shifting both angles by the same amount keeps the relative offset and dot product unchanged.','由 q=k=[1,0] 開始，把兩個 angles 一起平移，relative offset 和 dot product 均不變。'),
      10:('A pre-normalization transformer block','Pre-normalization transformer block',[('x','residual stream'),('h','x + Attention(Norm(x))'),('y','h + MLP(Norm(h))')],'Attention mixes positions. The MLP transforms features at each position. Residual additions preserve the tensor shape.','Attention 混合 positions；MLP 在各 position 轉換 features；residual addition 保持 tensor shape。'),
      12:('One complete training step','一個完整 training step',[('Forward','tokens → logits'),('Objective','shifted target → loss'),('Backward','loss → gradients'),('Update','optimizer → parameters')],'Clear or deliberately accumulate gradients. The optimizer update changes the model used by the next forward pass.','清除或有計劃地累積 gradients。Optimizer update 會改變下一次 forward pass 所用的 model。'),
      13:('Prefill and cached decode','Prefill 與 cached decode',[('Prefill','I go → cache K/V for I, go'),('Choose','last logits → to'),('Decode','process to; append its K/V'),('Choose again','last logits → school')],'The cached entries are per-layer key/value tensors, not saved final answers.','Cache entries 是每個 layer 的 key/value tensors，並非儲存的最終答案。'),
      15:('A diffusion training pair','Diffusion training 的一組配對',[('Clean sample','x₀'),('Corrupt','choose t, add noise ε'),('Predict','εθ(x_t, t, condition)'),('Learn','squared noise-prediction error')],'Generation runs a learned reverse process; moving a forward-noising slider backward is not that learned process.','Generation 使用學習得到的 reverse process；把 forward-noising slider 倒轉移動，並不等於該 process。'),
      17:('What contrastive training compares','Contrastive training 比較甚麼',[('Encode','question and passages'),('Score','pairwise similarity matrix'),('Scale','similarity / temperature'),('Learn','positive-pair cross-entropy')],'The candidate softmax is a training comparison, not a probability that evidence is true.','Candidate softmax 是 training 時的比較，並非 evidence 真實的 probability。'),
      19:('Preserve structure before retrieval','Retrieval 前先保留結構',[('Source','heading + timetable + footnote'),('Chunks','keep row/column associations'),('Retrieve','select supporting evidence'),('Answer','claim + source')],'A correct page match cannot repair a table whose values were attached to the wrong rows.','若 table values 已被配到錯誤 rows，即使找到正確頁面亦無法修復。'),
      21:('Three different evaluation boundaries','三個不同 evaluation boundaries',[('Retrieval','did required evidence arrive?'),('Answer','are required facts correct?'),('Support','does cited evidence support each claim?')],'A high retrieval score does not establish answer correctness or faithful citation.','高 retrieval score 並不等於答案正確，亦不等於 citation faithful。'),
      22:('What occupies device memory','甚麼會佔用 device memory',[('Weights','parameters + quantization metadata'),('State','KV cache or training states'),('Transient','activations + workspace'),('Runtime','allocator + framework overhead')],'Use one unit consistently. 1 GiB = 2³⁰ bytes; 1 GB = 10⁹ bytes.','一致使用同一單位。1 GiB = 2³⁰ bytes；1 GB = 10⁹ bytes。'),
      25:('LoRA keeps two computation paths','LoRA 的兩條計算路徑',[('Frozen base','Wx'),('Trainable branch','(α/r) B(Ax)'),('Combine','Wx + (α/r)B(Ax)')],'With random A and zero B, the initial adapter update is zero. B can receive the first nonzero gradient.','A random、B 為零時，初始 adapter update 為零；B 可收到第一次非零 gradient。'),
      26:('A small positive DPO margin','一個小正值的 DPO margin',[('Relative margin','0.4 − 0.1 = 0.3'),('Scale','β=0.1 → 0.03'),('Loss','−ln σ(0.03) ≈ 0.67826')],'The zero-margin reference is ln(2)≈0.69315. β is a configuration choice, not a universal best value.','Zero-margin 參考值是 ln(2)≈0.69315。β 是 configuration 選擇，並無通用最佳值。'),
      27:('The model proposes; application code executes','Model 提議；application code 執行',[('Proposal','tool name + arguments'),('Validate','schema + scope + dependency'),('Execute','bounded tool call'),('Observe','record result or typed failure')],'Parallel execution is appropriate only when calls are independent and permitted.','只有互相獨立、且獲允許的 calls，才適合 parallel execution。'),
      28:('The MCP communication boundary','MCP 的通訊 boundary',[('Host','assistant application + policy'),('Client','connection to one server'),('Server','exposed capabilities + execution')],'MCP standardizes communication. The harness still manages state, permissions, and termination.','MCP 標準化通訊；harness 仍管理 state、permissions 和 termination。'),
      29:('Continuous batching: a slot is reused','Continuous batching：重用空出的 slot',[('Step 1','requests A and B decode'),('Step 2','A completes; B continues'),('Step 3','C enters; B and C decode')],'This is a teaching timeline; real schedulers also manage prefill work, KV memory, and latency limits.','這是教學 timeline；實際 scheduler 亦需管理 prefill、KV memory 和 latency limits。'),
      30:('Keep external text outside the authority boundary','把 external text 放在 authority boundary 外',[('Untrusted input','document / page / tool text'),('Application policy','authenticated scope + validation'),('Allowed operation','authorized tool + bounded arguments')],'A link or image request can transmit data. Treat generated destinations and retrieved instructions as untrusted inputs.','Link 或 image request 可傳送資料。Generated destinations 和 retrieved instructions 應視為 untrusted inputs。')}
    if week not in data:return ''
    en,cn,steps,cap,zcap=data[week]
    return flow(pick(en,cn),steps,pick(cap,zcap))

def brief(text,zh):
    text=' '.join(text.split())
    # Use an existing sentence rather than inventing a new technical claim.
    parts=re.split(r'(?<=[。！？])|(?<=[.!?])\s+(?=[A-Z“"\[])',text)
    first=parts[0].strip() if parts else text
    # Keep a whole sentence; a formula may contain decimal points.
    return first if len(first)>=24 else text

def build_deck(soup,article,deck,week,zh):
    viewport=deck.select_one('.slide-viewport');viewport.clear();sections=[]
    current=None
    for child in list(article.children):
        if getattr(child,'name',None)=='h3':
            current=[child,[]];sections.append(current)
        elif current and getattr(child,'name',None) in ['p','ul','ol','div','table','figure']:
            current[1].append(child)
    count=0
    for heading,body in sections:
        if not body:continue
        title=heading.get_text(' ',strip=True)
        if re.match(r'Review [A-Z]:|複習 [A-Z]：',title):continue
        points=[];extras=[]
        for node in body:
            if node.name=='p':
                text=node.get_text(' ',strip=True)
                if not text.startswith(('Source:', '來源：')):points.append(brief(text,zh))
            elif node.name in ['ul','ol']:
                points.extend(brief(li.get_text(' ',strip=True),zh) for li in node.select('li')[:3])
            elif node.name=='figure' or node.select_one('table'):extras.append(node)
            elif node.select_one('pre'):
                # Full runnable code is kept in the reader/tutorial; slides link to it.
                continue
        if not points and not extras:continue
        chunks=[points[i:i+3] for i in range(0,len(points),3)] or [[]]
        if len(chunks)>2:chunks=chunks[:2]
        for part,items in enumerate(chunks):
            slide=soup.new_tag('section');slide['class']='lecture-slide';slide['data-slide']=''
            if count:slide['hidden']=''
            stage=soup.new_tag('div');stage['class']='slide-stage';stage.string=label(zh,f'Week {week:02d} · Section {len(viewport.select("[data-slide]"))+1}',f'第 {week:02d} 週 · 課節 {len(viewport.select("[data-slide]"))+1}')
            h=soup.new_tag('h3');h.string=title+(label(zh,' · continued',' · 續') if part else '')
            prose=soup.new_tag('div');prose['class']='slide-prose';ul=soup.new_tag('ul');ul['class']='slide-keypoints'
            for t in items:
                li=soup.new_tag('li');li.string=t;ul.append(li)
            prose.append(ul)
            if part==0:
                for e in extras[:1]:
                    clone=copy.deepcopy(e)
                    for el in clone.select('[id]'):
                        old=el['id'];new=old+'-slide-'+str(count);el['id']=new
                        for attrnode in clone.find_all(True):
                            for attr,value in list(attrnode.attrs.items()):
                                if isinstance(value,str):attrnode[attr]=value.replace('url(#'+old+')','url(#'+new+')')
                    prose.append(clone)
            a=soup.new_tag('a',href='#'+heading['id']);a['class']='slide-section-link';a.string=label(zh,'Read the worked explanation','閱讀完整解說')
            prose.append(a);slide.extend([stage,h,prose]);viewport.append(slide);count+=1
    jump=deck.select_one('.slide-jump');jump.clear()
    for i,slide in enumerate(viewport.select('[data-slide]')):
        o=soup.new_tag('option',value=str(i));o.string=f'{i+1}. '+slide.h3.get_text(' ',strip=True);jump.append(o)
    deck.select_one('.slide-counter').string=f'1 / {count}'
    deck.select_one('.deck-top h2').string=label(zh,'Key steps and worked visuals','重點步驟與圖解')
    deck.select_one('.deck-help').string=label(zh,'Use these slides to review the mechanism. Open “Read the worked explanation” for the complete notes and code.','用 slides 溫習機制；按「閱讀完整解說」可開啟完整講義及程式碼。')
    deck.select_one('.reader-link').decompose()

def link_references(soup,refs,prefix,titles):
    patterns=re.compile(r'\bR\d{2,3}\b|\b[Nn]otebook\s+(\d{1,2})\b')
    for node in list(soup.main.find_all(string=True)):
        if node.find_parent(['a','code','pre','script','style','svg','textarea']):continue
        s=str(node);matches=list(patterns.finditer(s))
        if re.fullmatch(r'\s*R\d{2,3}\s*',s) and node.find_parent('tr') and str(node.find_parent('tr').get('id','')).startswith('reference-'):continue
        if not matches:continue
        pieces=[];at=0
        for m in matches:
            token=m.group();pieces.append(NavigableString(s[at:m.start()]));a=None
            if token in refs:
                a=soup.new_tag('a',href=prefix+'resources.html#reference-'+token.lower());a['class']='inline-reading';a.string=refs[token]['title']+' ('+token+')'
            elif m.group(1) and 1<=int(m.group(1))<=32:
                n=int(m.group(1));a=soup.new_tag('a',href=prefix+f'tutorials/{n:02d}.html');a.string=f'Tutorial {n:02d}: '+titles.get(n,'')
            pieces.append(a if a else NavigableString(token));at=m.end()
        pieces.append(NavigableString(s[at:]));node.replace_with(*pieces)

def main():
    resource=BeautifulSoup((ROOT/'resources.html').read_text(encoding='utf-8'),'html.parser');refs={}
    for row in resource.select('tr'):
        cells=row.find_all(['td','th'],recursive=False)
        if cells and re.fullmatch(r'R\d{2,3}',cells[0].get_text(strip=True)):
            a=cells[1].find('a') if len(cells)>1 else None
            if a:refs[cells[0].get_text(strip=True)]={'title':a.get_text(' ',strip=True),'url':a.get('href')}
    totals={}
    for langroot in [ROOT,ROOT/'zh-HK']:
        zh=langroot.name=='zh-HK';titles={}
        for p in (langroot/'tutorials').glob('*.html'):
            if p.stem.isdigit():titles[int(p.stem)]=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser').h1.get_text(' ',strip=True)
        allpages=[p for p in langroot.rglob('*.html') if zh or not p.is_relative_to(ROOT/'zh-HK')]
        for p in allpages:
            soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');rel=p.relative_to(langroot);prefix='../'*(len(rel.parts)-1)
            assetprefix=('../' if zh else '')+prefix
            for name in ['reader-v3.css']:
                soup.head.append(soup.new_tag('link',rel='stylesheet',href=assetprefix+'assets/'+name))
            soup.head.append(soup.new_tag('script',src=assetprefix+'assets/reader-v3.js',defer=True))
            if p.parent.name=='lectures':
                week=int(p.stem);article=soup.select_one('#full-notes');deck=soup.select_one('.lecture-deck')
                # Remove exact duplicate prose and repeated transition boilerplate.
                seen=set()
                for para in list(article.find_all('p',recursive=False)):
                    text=' '.join(para.get_text(' ',strip=True).split())
                    if text in seen:para.decompose()
                    else:seen.add(text)
                for h in list(article.find_all('h3',recursive=False)):
                    if h.get_text().startswith(('A deeper pass after','完成引導例子後','深入一層')):
                        nxt=h.find_next_sibling('p');h.decompose()
                        if nxt and ('following reference treatment' in nxt.get_text().lower() or '第二次閱讀' in nxt.get_text()):nxt.decompose()
                # Add a notation key close to the mechanism rather than relying on a glossary elsewhere.
                if week in [7,8,9,10,22]:
                    key=fragment('<aside class="notation-key"><strong>'+label(zh,'Notation in this lesson','本課 notation')+'</strong><p>B: batch · T: tokens · d_model: model width · H: query heads · H_kv: key/value heads · d_head: query/key width per head · d_value: value width per head</p></aside>')
                    article.insert(2,key)
                fig=visual(week,zh)
                if fig:
                    headings=article.find_all('h3',recursive=False)
                    target=next((h for h in headings if any(k in h.get_text().lower() for k in {2:['byte pair','bpe'],3:['numerical','數值','dot product'],6:['heatmap'],9:['rotary','rope'],13:['cache','ledger'],17:['contrastive'],28:['mcp connects','mcp'],25:['two by two','二乘二','小型']}.get(week,[]))),None)
                    target=target or (headings[min(2,len(headings)-1)] if headings else article)
                    target.insert_after(fragment(fig).figure)
                build_deck(soup,article,deck,week,zh)
                # Preserve the unique reference material without making the reader repeat it.
                reviews=[h for h in article.find_all('h3',recursive=False) if re.match(r'Review [A-Z]:|複習 [A-Z]：',h.get_text(' ',strip=True))]
                if reviews:
                    details=soup.new_tag('details');details['class']='reference-details';details['id']='reference-details'
                    summary=soup.new_tag('summary');summary.string=label(zh,'Reference details and checks','參考細節與學習檢查');details.append(summary)
                    main_words=set(re.findall(r'\w+',article.get_text(' ',strip=True).lower()))
                    for h in reviews:
                        content=[];nxt=h.next_sibling
                        while nxt and getattr(nxt,'name',None)!='h3':content.append(nxt);nxt=nxt.next_sibling
                        details.append(h.extract())
                        for item in content:details.append(item.extract())
                    article.append(details)
                    for a in deck.select('.slide-section-link'):
                        if a.get('href','')[1:] in {h.get('id') for h in details.select('h3')}:a['data-open-reference']='true'
                tabs=fragment('<div class="lesson-mode" role="tablist" aria-label="'+label(zh,'Lesson view','課堂檢視')+'"><button type="button" role="tab" id="mode-read" aria-controls="full-notes" aria-selected="true" data-mode="read">'+label(zh,'Read lesson','閱讀講義')+'</button><button type="button" role="tab" id="mode-slides" aria-controls="lecture-slides" aria-selected="false" data-mode="slides">'+label(zh,'Lesson slides','課堂 slides')+'</button></div>')
                soup.select_one('.lesson-links').insert_after(tabs);deck['hidden']='';deck['role']='tabpanel';article['role']='tabpanel'
                toc=soup.new_tag('nav');toc['class']='reader-toc';toc['aria-label']=label(zh,'In this lesson','本課內容')
                summary=soup.new_tag('strong');summary.string=label(zh,'In this lesson','本課內容');toc.append(summary)
                ol=soup.new_tag('ol')
                for h in article.find_all('h3',recursive=False):
                    li=soup.new_tag('li');a=soup.new_tag('a',href='#'+h['id']);a.string=h.get_text(' ',strip=True);li.append(a);ol.append(li)
                toc.append(ol);article.insert_before(toc)
            if p.name=='resources.html':
                for row in soup.select('tr'):
                    cells=row.find_all(['td','th'],recursive=False)
                    if cells and re.fullmatch(r'R\d{2,3}',cells[0].get_text(strip=True)):row['id']='reference-'+cells[0].get_text(strip=True).lower()
                a=soup.new_tag('a',href=(('../' if zh else '')+'downloads/Course_Website_Source.zip'));a['class']='source-download';a.string=label(zh,'Download editable website source and rebuild instructions','下載可編輯網站 source 及 rebuild 說明');soup.select_one('.lesson-links').append(a)
            link_references(soup,refs,prefix,titles)
            # prettify preserves preformatted code and breaks structural HTML into reviewable lines.
            p.write_text(soup.prettify(),encoding='utf-8')
        index=[]
        for p in allpages:
            s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');main=copy.deepcopy(s.main)
            # The reader is authoritative; do not double every paragraph in search via its slides.
            for t in main.select('.lecture-deck,.reader-toc'):t.decompose()
            index.append({'title':s.h1.get_text(' ',strip=True),'path':p.relative_to(langroot).as_posix(),'type':s.body.get('data-page-kind','guide'),'text':main.get_text(' ',strip=True)})
        (langroot/'assets').mkdir(exist_ok=True)
        (langroot/'assets/search-index.js').write_text('window.COURSE_SEARCH='+json.dumps(index,ensure_ascii=False)+';',encoding='utf-8')
        totals['zh-HK' if zh else 'en']={'pages':len(allpages),'slides':sum(len(BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser').select('[data-slide]')) for p in allpages)}
    for file in ['reader-v3.css','reader-v3.js']:(ROOT/'assets'/file).write_text((B/'work'/file).read_text(encoding='utf-8'),encoding='utf-8')
    (B/'work/v3_site_stats.json').write_text(json.dumps(totals,indent=2),encoding='utf-8');print(json.dumps(totals))

if __name__=='__main__':main()
