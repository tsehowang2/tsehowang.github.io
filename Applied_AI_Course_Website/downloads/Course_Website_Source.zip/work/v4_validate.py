from v4_common import *
import subprocess,sys,os
import numpy
env=dict(os.environ)
env['PYTHONPATH']=str(Path(numpy.__file__).parents[1])+os.pathsep+str(C)
env['PYTHONIOENCODING']='utf-8'
results=[]
for p in sorted((C/'notebooks').glob('*.ipynb')):
    nb=json.loads(p.read_text(encoding='utf-8'))
    for i,c in enumerate(nb['cells']):
        if c['cell_type']=='code':ast.parse(''.join(c['source']),filename=f'{p.name}:{i}')
    ast.parse(p.with_suffix('.py').read_text(encoding='utf-8'))
    n=int(p.name[:2])
    if n in [1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,19,20,21,22,23,24,25,27,29,30,31,32]:
        r=subprocess.run([sys.executable,'-X','utf8',str(p.with_suffix('.py'))],cwd=C,capture_output=True,text=True,encoding='utf-8',timeout=55,env=env)
        results.append({'week':n,'passed':r.returncode==0,'stdout':r.stdout,'stderr':r.stderr})
    if n in [26,28]:
        previous=Path.cwd();os.chdir(C)
        scope={};exec(''.join(nb['cells'][1]['source']),scope)
        os.chdir(previous)
        for i,c in enumerate(nb['cells']):
            text=''.join(c['source'])
            if c['cell_type']=='code' and any(term in text for term in ['scaled_margin = beta','teacher = np.array','def broken_planner']):
                exec(compile(text,p.name+':'+str(i),'exec'),scope)
        results.append({'week':n,'passed':True,'scope':'DPO/distillation or invalid-JSON CPU cells only; model path not run'})
(W/'v4_runtime_validation.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps({'passed':sum(r['passed'] for r in results),'total':len(results),'failures':[r for r in results if not r['passed']]},indent=2))
