from pathlib import Path
import json, re, ast, zipfile
B=Path(__file__).resolve().parents[1]
C=B/'outputs/llm_course_v2'
W=B/'work'
Z={}
def md(s):return {'cell_type':'markdown','metadata':{},'source':s.splitlines(keepends=True)}
def code(s):return {'cell_type':'code','metadata':{},'source':s.strip().splitlines(keepends=True),'outputs':[],'execution_count':None}
def src(c,s):c['source']=s.splitlines(keepends=True)
def add(nb,title,body,script,zh):
    en='### '+title+'\n'+body
    Z[en]='### '+title+'\n'+zh
    Z[title]=title
    Z[body]=zh
    nb['cells'] += [md(en),code(script)]
def load(n):
    p=next((C/'notebooks').glob(f'{n:02d}_*.ipynb'))
    return p,json.loads(p.read_text(encoding='utf-8'))
def save(p,nb):
    p.write_text(json.dumps(nb,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
    p.with_suffix('.py').write_text('\n\n'.join(''.join(c['source']) if c['cell_type']=='code' else '\n'.join('# '+x for x in ''.join(c['source']).splitlines()) for c in nb['cells'])+'\n',encoding='utf-8')
def edit(rel,f):
    p=C/rel;p.write_text(f(p.read_text(encoding='utf-8')),encoding='utf-8')
