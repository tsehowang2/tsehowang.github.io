from v4_common import *
from bs4 import BeautifulSoup
site=B/'outputs/ai_course_website_bilingual'
checks=[]
def check(name,value):
    checks.append({'check':name,'passed':bool(value)})
    if not value:raise AssertionError(name)
for n in range(1,33):
    p,nb=load(n)
    check(f'notebook {n}: reference output or expected checks',any('### Reference output' in ''.join(c['source']) for c in nb['cells']))
    for c in nb['cells']:
        if c['cell_type']=='code':
            ast.parse(''.join(c['source']))
            check(f'notebook {n}: clean distributed outputs',c['outputs']==[] and c['execution_count'] is None)
    if n<=16:check(f'notebook {n}: standalone setup','coursekit' not in ''.join(nb['cells'][1]['source']))
    if n>=17:
        soup=BeautifulSoup((site/f'tests/{n:02d}.html').read_text(encoding='utf-8'),'html.parser')
        check(f'week {n}: three marking guides',len(soup.select('.solution'))==3 and all('Marking:' in el.get_text() for el in soup.select('.solution')))
for lang in ['', 'zh-HK/']:
    for n in range(1,33):
        soup=BeautifulSoup((site/f'{lang}tutorials/{n:02d}.html').read_text(encoding='utf-8'),'html.parser')
        check(f'{lang}tutorial {n}: full pack link',bool(soup.select('a[href$="Applied_Generative_AI_Course.zip"]')))
    soup=BeautifulSoup((site/f'{lang}lectures/28.html').read_text(encoding='utf-8'),'html.parser')
    article=soup.select_one('.full-notes')
    fig=next(x for x in article.select('figure') if 'MCP' in x.get_text())
    check(lang+'MCP figure under MCP section','MCP' in fig.find_previous_sibling('h3').get_text())
soup=BeautifulSoup((site/'lectures/11.html').read_text(encoding='utf-8'),'html.parser')
check('no reference-only slides',all(not el.select_one('.slide-keypoints') or not el.select_one('.slide-keypoints').get_text().strip().startswith('Source:') for el in soup.select('.lecture-slide')))
check('home title fixed','Applied AI · Applied AI' not in (site/'index.html').read_text(encoding='utf-8'))
for n in [22,27]:
    p,nb=load(n);allcode='\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type']=='code')
    check(f'week {n}: corrected arithmetic',('ceiling == 200' in allcode) if n==22 else ('answer == 6' in allcode))
report={'checks':checks,'passed':len(checks),'failed':0,'limits':['Model downloads/training/reload not executed','CUDA not executed','No visual browser verification']}
(W/'v4_revision_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'checks_passed':len(checks),'errors':0}))
