from pathlib import Path
from bs4 import BeautifulSoup
import json,re
from build_bilingual import dictionary
B=Path(__file__).resolve().parents[1];S=B/'outputs/ai_course_website_v2';d=dictionary();missing={}
for p in S.rglob('*.html'):
    soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
    for n in soup.main.find_all(string=True):
        s=str(n).strip()
        if n.find_parent(['pre','code','script','style']) or not s or not re.search('[A-Za-z]',s):continue
        if s not in d and str(n) not in d and len(s)>35:missing.setdefault(s,[]).append(p.relative_to(S).as_posix())
(B/'work/v3_missing_translations.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(missing,ensure_ascii=False,indent=2))
