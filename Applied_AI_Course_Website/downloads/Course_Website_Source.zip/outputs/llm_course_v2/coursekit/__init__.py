"""Small, inspectable instructional components; no external dependencies."""
