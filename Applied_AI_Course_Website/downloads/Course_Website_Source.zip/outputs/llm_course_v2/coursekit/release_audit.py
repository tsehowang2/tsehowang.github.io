"""Check submitted course artifacts; never promote a blank draft as ready."""
from pathlib import Path
import json

REQUIRED = ['week12_config.json', 'tiny_lm.pt', 'week18_retrieval.json',
            'week20_context.txt', 'week21_to_grade.json', 'week24_train.json',
            'week24_dev.json', 'week26_training.json', 'week26_adapter',
            'week27_trace.json', 'week28_agent.json', 'week29_manifest.json',
            'week29_latency.json', 'week30_incident.json',
            'project_cases.json', 'project_results.json', 'manual_grades.json',
            'environment.txt', 'release_manifest.json', 'limitations.md']

def audit_release(course, runs):
    course, runs = Path(course), Path(runs)
    missing = [name for name in REQUIRED if not (runs/name).exists()]
    invalid = []
    loaded = {}
    for name in REQUIRED:
        p = runs/name
        if not p.exists():
            continue
        if p.is_dir():
            if not any(p.iterdir()):
                invalid.append(name + ': empty directory')
        elif p.stat().st_size == 0:
            invalid.append(name + ': empty file')
        elif p.suffix == '.json':
            try:
                loaded[name] = json.loads(p.read_text(encoding='utf-8'))
                if not loaded[name]:
                    invalid.append(name + ': empty data')
            except (ValueError, UnicodeError) as exc:
                invalid.append(name + ': ' + type(exc).__name__)
    cases = loaded.get('project_cases.json', [])
    case_list = cases if isinstance(cases, list) else []
    checked = [c for c in case_list if c.get('checked') is True]
    if len(checked) < 40:
        invalid.append('project_cases.json: need at least 40 manually checked cases')
    if len({c.get('id') for c in checked}) != len(checked):
        invalid.append('project_cases.json: duplicate case IDs')
    manifest = loaded.get('release_manifest.json', {})
    keys = ['corpus_revision', 'chunker_revision', 'embedding_revision',
            'index_revision', 'generator_revision', 'tokenizer_revision',
            'adapter_revision', 'prompt_revision', 'tool_revision',
            'environment_revision', 'evaluation_run']
    # Components intentionally unused must be explicitly marked not_used, not null.
    unfilled = [key for key in keys if not isinstance(manifest,dict) or not manifest.get(key)]
    if unfilled:
        invalid.append('release_manifest.json: unfilled ' + ', '.join(unfilled))
    return {'missing_artifacts':missing, 'invalid_artifacts':invalid,
            'checked_cases':len(checked), 'ready':not missing and not invalid,
            'scope':'Artifact checks only. Independently review quality, support, privacy and measurements.'}
