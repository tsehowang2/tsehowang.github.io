"""Local instructional HTTP API. No authentication; binds to loopback only."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from .core import extract_answer, LexicalIndex, load_docs

INDEX = LexicalIndex(load_docs())


class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, body):
        payload = json.dumps(body).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        self.send_json(200 if self.path == '/health' else 404,
                       {'status': 'ok'} if self.path == '/health' else {'error': 'not found'})

    def do_POST(self):
        if self.path != '/ask':
            self.send_json(404, {'error': 'not found'})
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 1 <= length <= 65536:
                self.send_json(413, {'error': 'request size invalid'})
                return
            self.connection.settimeout(5)
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict) or not set(data) <= {'question', 'version'}:
                raise ValueError('invalid fields')
            question, version = data.get('question'), data.get('version', '2')
            if not isinstance(question, str) or not 1 <= len(question) <= 2000:
                raise ValueError('question must contain 1..2000 characters')
            if version not in ('1', '2', 'all'):
                raise ValueError('invalid version')
            self.send_json(200, extract_answer(question, INDEX, version))
        except (ValueError, TypeError, TimeoutError) as exc:
            self.send_json(400, {'error': str(exc)})

    def log_message(self, fmt, *args):
        # Avoid logging request bodies; extend with request IDs in tutorial 30.
        pass


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=0)
    args = parser.parse_args()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    print(json.dumps({'host':'127.0.0.1','port':server.server_port}), flush=True)
    server.serve_forever()
