"""Retrieval, evaluation and a bounded tool controller.

This is an educational baseline. Lexical extraction is not LLM generation,
and structural citation validation is not semantic grounding verification.
"""
import ast
from collections import Counter
import hashlib
import json
import math
import operator
from pathlib import Path
import random
import re
import time

ROOT = Path(__file__).resolve().parents[1]
STOP = set('a an the is are of to in on for what how do does i it and with my can'.split())


def load_docs():
    return json.loads((ROOT / 'data' / 'docs.json').read_text(encoding='utf-8'))


def tokens(text):
    return [t for t in re.findall(r'[a-z0-9_]+', text.lower()) if t not in STOP]


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class LexicalIndex:
    """BM25 reference with filtering before scoring and stable tie ordering."""
    def __init__(self, docs):
        self.docs = list(docs)
        if len({d['id'] for d in docs}) != len(docs):
            raise ValueError('document IDs must be unique')
        self.counts = [Counter(tokens(d['title'] + ' ' + d['text'])) for d in docs]
        self.lengths = [sum(c.values()) for c in self.counts]
        self.avgdl = sum(self.lengths) / max(1, len(docs))
        self.df = Counter(t for c in self.counts for t in c)

    def search(self, question, version='2', k=3):
        if version not in ('1', '2', 'all'):
            raise ValueError('version must be 1, 2 or all')
        if type(k) is not int or not 1 <= k <= 100:
            raise ValueError('k must be an integer in [1,100]')
        query = set(tokens(question))
        hits = []
        n = len(self.docs)
        for d, counts, length in zip(self.docs, self.counts, self.lengths):
            if version != 'all' and d['version'] != version:
                continue
            score = 0.0
            for term in query:
                tf = counts[term]
                if not tf:
                    continue
                idf = math.log(1 + (n - self.df[term] + 0.5) / (self.df[term] + 0.5))
                score += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / self.avgdl))
            if score > 0:
                hits.append({**d, 'score': score})
        return sorted(hits, key=lambda d: (-d['score'], d['id']))[:k]


def extract_answer(question, index=None, version='2', k=3):
    """Evidence-only baseline. It can return irrelevant excerpts: assess relevance."""
    index = index or LexicalIndex(load_docs())
    start = time.perf_counter()
    hits = index.search(question, version, k)
    return {
        'answer': '\n'.join(d['text'] for d in hits) if hits else 'Insufficient evidence in this version.',
        'citations': [d['id'] for d in hits],
        'version': version,
        'status': 'evidence_found' if hits else 'insufficient_evidence',
        'generator': 'lexical_extractor_not_llm',
        'grounding_verified': False,
        'latency_ms': (time.perf_counter() - start) * 1000,
    }


def retrieval_metrics(retrieved, relevant, k):
    if type(k) is not int or k < 1:
        raise ValueError('k must be positive')
    gold = set(relevant)
    if not gold:
        return {'recall': None, 'hit': None, 'rr': None}
    ranked = list(dict.fromkeys(retrieved))[:k]
    ranks = [i for i, item in enumerate(ranked, 1) if item in gold]
    return {'recall': len(set(ranked) & gold) / len(gold),
            'hit': int(bool(ranks)), 'rr': 1 / min(ranks) if ranks else 0.0}


def rrf(rankings, c=60):
    if c < 0:
        raise ValueError('c must be nonnegative')
    scores = Counter()
    for ranking in rankings:
        for rank, item in enumerate(dict.fromkeys(ranking), 1):
            scores[item] += 1 / (c + rank)
    return sorted(scores.items(), key=lambda x: (-x[1], x[0]))


def paired_bootstrap(a, b, repeats=2000, seed=7):
    """Percentile interval of mean(B-A), resampling paired task indices."""
    if not a or len(a) != len(b) or repeats < 20:
        raise ValueError('need equal nonempty paired samples and >=20 repeats')
    rng = random.Random(seed)
    delta = [y - x for x, y in zip(a, b)]
    samples = sorted(sum(rng.choice(delta) for _ in delta) / len(delta) for _ in range(repeats))
    return {'difference': sum(delta) / len(delta),
            'ci95': [samples[int(0.025 * (repeats - 1))], samples[int(0.975 * (repeats - 1))]],
            'n': len(delta), 'seed': seed}


class ToolError(ValueError):
    pass


def _exact_keys(value, expected):
    if not isinstance(value, dict) or set(value) != set(expected):
        raise ToolError('argument keys do not match schema')


def calculate(expression):
    """Bounded arithmetic AST, never Python eval; intentionally excludes powers."""
    if not isinstance(expression, str) or not 1 <= len(expression) <= 128:
        raise ToolError('expression must be 1..128 characters')
    try:
        tree = ast.parse(expression, mode='eval')
    except (SyntaxError, RecursionError) as exc:
        raise ToolError('invalid arithmetic syntax') from exc
    if sum(1 for _ in ast.walk(tree)) > 32:
        raise ToolError('expression too complex')
    binary = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}
    unary = {ast.UAdd: operator.pos, ast.USub: operator.neg}

    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            value = node.value
        elif isinstance(node, ast.BinOp) and type(node.op) in binary:
            try:
                value = binary[type(node.op)](visit(node.left), visit(node.right))
            except (ArithmeticError, OverflowError) as exc:
                raise ToolError('arithmetic failure') from exc
        elif isinstance(node, ast.UnaryOp) and type(node.op) in unary:
            value = unary[type(node.op)](visit(node.operand))
        else:
            raise ToolError('operator or value not allowed')
        try:
            valid = math.isfinite(value) and abs(value) <= 1e9
        except OverflowError:
            valid = False
        if not valid:
            raise ToolError('numeric bound exceeded')
        return value
    return visit(tree.body)


def validate_config(config):
    _exact_keys(config, ('timeout_ms', 'retries'))
    errors = []
    if type(config['timeout_ms']) is not int or not 1 <= config['timeout_ms'] <= 120000:
        errors.append('timeout_ms must be an integer in [1,120000]')
    if type(config['retries']) is not int or not 0 <= config['retries'] <= 5:
        errors.append('retries must be an integer in [0,5]')
    return {'valid': not errors, 'errors': errors}


def execute_tool(name, arguments, index, allowed_version):
    if name == 'lookup':
        _exact_keys(arguments, ('query', 'version'))
        if arguments['version'] != allowed_version:
            raise ToolError('version outside request scope')
        if not isinstance(arguments['query'], str) or not 1 <= len(arguments['query']) <= 2000:
            raise ToolError('query length invalid')
        return index.search(arguments['query'], allowed_version, 3)
    if name == 'calculate':
        _exact_keys(arguments, ('expression',))
        return {'value': calculate(arguments['expression'])}
    if name == 'validate_config':
        _exact_keys(arguments, ('config',))
        return validate_config(arguments['config'])
    raise ToolError('unknown tool')


def run_agent(question, planner, version='2', max_steps=4, index=None):
    """Synchronous controller: step-bounded, not a wall-clock sandbox.

    Model planners must implement their own generation timeout/cancellation.
    Final citations are checked for existence in prior lookup observations only.
    """
    if version not in ('1', '2') or type(max_steps) is not int or not 1 <= max_steps <= 20:
        raise ValueError('invalid request scope or step budget')
    index = index or LexicalIndex(load_docs())
    observations, trace, evidence = [], [], set()
    for step in range(max_steps):
        state = {'question': question, 'version': version, 'step': step,
                 'observations': json.loads(json.dumps(observations))}
        try:
            proposal = planner(state)
        except Exception as exc:
            kind = 'invalid_json' if isinstance(exc, json.JSONDecodeError) else 'planner_exception'
            trace.append({'step': step, 'event': kind, 'error': type(exc).__name__})
            return {'status': 'planner_error', 'trace': trace, 'error': type(exc).__name__}
        try:
            if not isinstance(proposal, dict):
                raise ToolError('proposal must be an object')
            if proposal.get('type') == 'final':
                _exact_keys(proposal, ('type', 'answer', 'citations'))
                if not isinstance(proposal['answer'], str) or len(proposal['answer']) > 8000:
                    raise ToolError('invalid answer')
                ids = proposal['citations']
                if not isinstance(ids, list) or any(not isinstance(i, str) for i in ids):
                    raise ToolError('invalid citations')
                if not set(ids) <= evidence:
                    raise ToolError('citation not in observed evidence')
                return {'status': 'completed', 'answer': proposal['answer'],
                        'citations': ids, 'trace': trace, 'grounding_verified': False}
            _exact_keys(proposal, ('type', 'name', 'arguments'))
            if proposal['type'] != 'tool':
                raise ToolError('unknown proposal type')
            result = execute_tool(proposal['name'], proposal['arguments'], index, version)
            if proposal['name'] == 'lookup':
                evidence.update(d['id'] for d in result)
            event = {'step': step, 'name': proposal['name'], 'arguments': proposal['arguments'], 'result': result}
            trace.append(event)
            observations.append({'name': proposal['name'], 'result': json.dumps(result)[:4096]})
        except ToolError as exc:
            return {'status': 'invalid_action', 'trace': trace, 'error': str(exc)}
    return {'status': 'budget_exhausted', 'trace': trace}


def make_manifest(extra=None):
    return {'course_version': '1.0', 'corpus_sha256': sha256_file(ROOT / 'data' / 'docs.json'),
            'retriever': 'bm25_reference_v1', 'generator': 'lexical_extractor_not_llm',
            **(extra or {})}


def verify_manifest(manifest):
    if manifest['corpus_sha256'] != sha256_file(ROOT / 'data' / 'docs.json'):
        raise ValueError('corpus hash mismatch; rebuild/re-evaluate dependent artifacts')
    return True
