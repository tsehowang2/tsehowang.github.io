import json
from .core import extract_answer, load_docs, LexicalIndex, retrieval_metrics, ROOT


def main():
    index = LexicalIndex(load_docs())
    tasks = json.loads((ROOT / 'data' / 'queries.json').read_text(encoding='utf-8'))
    results = []
    for task in tasks:
        response = extract_answer(task['question'], index, task['version'])
        results.append({'id': task['id'], 'response': response,
                        'retrieval': retrieval_metrics(response['citations'], task['relevant'], 3)})
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
