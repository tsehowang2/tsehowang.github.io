# Semester 2 External evidence evaluation and adaptation

## Week 17 From word vectors to semantic search

### contrastive

Contrastive learning compares labeled matching pairs with alternatives in the same objective.

### A simple school handbook

Imagine three handbook passages. H1 says “School opens at 08:00.” H2 says “The school bus leaves at 07:30.” H3 says “A ticket for the school bus costs 4 dollars.” A student asks “When does school start?”

Searching is the task of choosing useful passages for this question. The question uses start while H1 uses opens. Exact word matching can find school, but it may also find the bus passage. A good representation should help distinguish useful evidence from merely related text.

We postponed this application until after learning representations and transformers. Now “embed the question” refers to a concrete kind of numerical computation, not an unexplained magic API.

### A lexical baseline first

A lexical retriever compares words or terms. An inverted index maps a term to passages containing it. Term weighting can reduce the influence of common words and emphasize more distinctive terms.

For the question about school starting, a simple overlap method may score both H1 and H2. The failure is understandable. The method lacks a learned relationship between start and opens, and it may not distinguish the main subject well.

BM25 is a widely used lexical scoring family with term-frequency saturation and length normalization. We will compare it with semantic methods rather than assuming neural vectors win on every kind of query. Exact API names and error codes often reward precise lexical matching.

### A sentence embedding represents the input for a task

A transformer encoder can produce contextual token vectors. A pooling or other representation procedure creates a passage or sentence vector. Training then encourages useful geometry for the intended comparison.

An embedding model trained for retrieval aims to make relevant question-passage pairs score well under its chosen similarity function. A random average of token rows is a different method with different limitations.

The question and passage can be encoded independently in a bi-encoder. Passage vectors can be stored once and reused for many questions. This reuse is the computational reason that dense retrieval can scale beyond re-reading every passage jointly with every query.

### A tiny numerical ranking

Use the invented unit question vector q=[1,0]. Let H1=[0.9,√0.19], H2=[0.6,0.8], and H3=[0,1]. All three passage vectors have unit length. Their dot products with q are exactly 0.9, 0.6, and 0. The second coordinate of H1 is about 0.43589.

H1 ranks first. These coordinates are designed for calculation; they are not measured outputs from a real embedding model. The ranking operation is exact given the vectors, while whether the vectors encode the right relevance remains empirical.

In the tutorial, replace invented coordinates with actual model embeddings. Keep the question set and evidence labels fixed so the experiment tests the representation rather than a hand-picked demonstration.

### How retrieval embeddings can be trained

A positive pair is a question and a passage that supports its answer. A negative pair does not support it. A contrastive objective can increase the positive score relative to competing scores.

A hard negative resembles the question but is wrong. For “When does school open?” the bus departure time is a useful distractor. A passage about school opening in a different year is another.

False negatives occur when a passage marked negative actually provides useful evidence. Dataset construction therefore matters. The embedding space reflects the objective and labels, not an objective universal measure of meaning.

### A contrastive training example with three questions

Return to our school handbook. Q1 is “When does school start?”, Q2 is “When does the school bus leave?”, and Q3 is “How much does a ticket for the school bus cost?” Their supporting passages are H1, H2, and H3 respectively. We label these positive pairs before training. The other passages in this small example do not answer that particular question.

A bi-encoder encodes each question and each passage separately. The following table contains invented training logits, after any similarity scaling, so we can calculate the objective easily. They are not raw cosine similarities: a cosine cannot equal 2. Larger logits give a pair more probability relative to the other candidates.

| Question | H1 | H2 | H3 |
|---|---|---|---|
| Q1 | 2 | 1 | 0 |
| Q2 | 0 | 2 | 1 |
| Q3 | 1 | 0 | 2 |

For Q1, the positive passage is H1. Apply the same softmax operation you learned in week 4 to the row [2,1,0]. With temperature equal to 1 for this calculation, the normalized candidate probabilities are approximately [0.66524,0.24473,0.09003]. These probabilities describe the training choice among these three candidates; they are not calibrated probabilities that a passage is true or sufficient.

The loss for Q1 is the negative natural logarithm of the probability assigned to H1: −ln(0.66524), approximately 0.40761. Q2 and Q3 have the same score pattern with their positive in a different column, so the mean loss over these three rows is also approximately 0.40761. We want the positive to score well relative to competing passages, not merely to make every similarity score larger.

To see the learning direction, the derivative of this row loss with respect to its three scores is approximately [−0.33476,0.24473,0.09003] at temperature 1. Gradient descent therefore pushes the positive score upward and competing scores downward locally. In a real model, backpropagation follows the score through the question and passage encoders to update their trainable parameters. We do not keep this small score table as the model.

### Temperature connects cosine similarity to training logits

The earlier [2,1,0] row is a teaching example with temperature 1. In a common retrieval setup, normalize embeddings, compute cosine similarities, then divide by a temperature τ: logits = cosine/τ. Equivalently, multiply cosine by scale=1/τ. The model and objective determine the appropriate scale; training libraries may fix or learn it.

For invented cosines [0.8,0.6,0.2] and τ=0.05, logits are [16,12,4]. Stable softmax gives positive-candidate probability about 0.982008 and positive loss about 0.018156. At τ=1, the same cosines give probability about 0.422379 and loss about 0.861852. Temperature changes the sharpness and gradient scale, so a loss near 0.41 from our earlier example is not a universal practical target.

### A false negative changes what the model is taught

Now replace H2 with “Classes at this school begin at 08:00.” For Q1, this is another useful answer, not a negative. Keeping only H1 as the positive would penalize the model for also matching H2. If the Q1 scores change from [2,1,0] to [2,2,0], that single-positive loss rises to about 0.75862 even though the second supporting passage now scores better. The problem is the label assumption. Review duplicates and passages with multiple valid answers before treating other batch items as negatives.

### Bi-encoder retrieval and cross-encoder reranking

The bi-encoder stores passage vectors ahead of time and scores a new question against them. A cross-encoder instead reads a question and a candidate passage together and produces a pair score. It can examine their token interactions directly, but must process each selected pair. A common arrangement retrieves a small candidate set with a bi-encoder, then reranks those candidates with a cross-encoder [R28]. A reranker cannot recover a supporting passage that was never included in its candidate set.

Check your understanding: identify the positive column in each table row; reproduce the Q1 softmax and loss; explain why another correct school-opening passage must not automatically become a negative. This is one common contrastive setup [R27], not the only way to train an embedding model.

### Prepare the query and passage the way the model expects

An embedding checkpoint includes an input recipe. Some retrieval models distinguish inputs with prefixes such as “query: When does school start?” and “passage: School opens at 08:00.” Other models use an instruction template or no prefix. Follow that model card and its query/document encoding methods, including pooling, normalization, maximum length, and truncation. Adding an arbitrary prefix to every model is not an improvement.

### One vector, several vectors, or sparse term weights

A Matryoshka-trained embedding organizes useful information into nested prefixes of its vector. A model trained for dimensions 64, 128, and 256 can let you choose a supported prefix length, renormalize if required, and compare the quality/storage tradeoff. Ordinary embeddings have no such guarantee: cutting any 256-dimensional vector to its first 64 numbers can discard essential information.

ColBERT keeps multiple contextual token vectors for a passage rather than pooling everything into one vector. In its late-interaction score, each query token finds its strongest passage-token match, then those maxima are summed. For query tokens “bus fare”, suppose one passage gives maximum similarities [0.9,0.2] and another [0.7,0.8]. Their illustrative scores are 1.1 and 1.5; the second covers both concepts better. Passage representations can be precomputed, but many token vectors need more index storage than one vector per passage.

SPLADE takes another route: a neural encoder produces a sparse vector over vocabulary terms, with learned term expansion. A query containing “bus fare” may receive weight on “ticket” even when that word was not typed. An inverted index can compare the nonzero term weights. This differs from BM25’s hand-designed term weighting and from a compact dense vector. The choices address different matching and storage requirements; evaluate them on the same questions.

### Relevance needs labels and a definition

For our question, H1 is relevant. For “How much does the school bus cost and when does it leave?” both H2 and H3 are necessary. A single related passage may be insufficient for a complete task.

Hit@k asks whether at least one relevant passage appears. Recall@k asks what fraction of required relevant passages appear. We will compute both carefully in week 21.

An unsupported question, such as “What color is the headteacher's car?”, has no supporting passage in this small handbook. A retriever can still return a nearest vector. Nearest does not mean sufficient.

### Moving toward technical documentation

The same structure applies when passages describe API parameters instead of school schedules. Exact names, version constraints, and code blocks become important. The approachable handbook example teaches the mechanism first; the documentation corpus supplies the harder setting.

Choose a fixed corpus revision and retain passage IDs and source provenance. Keep question labels separate from training or configuration tuning. Do not select evaluation questions only after seeing which ones the new retriever handles well.

We will add persistence, metadata, and approximate search next week. You can understand and test the ranking mechanism with a list of vectors before operating a database.

### Worked practice and a readiness check

Label necessary evidence for “When does the bus leave and what does a ticket cost?” Explain why retrieving H2 alone gives Hit@1=1 but Recall@1=1/2.

Compare a paraphrase question and an exact identifier question under lexical and actual dense search. Save raw ranks and one failure for each method.

You are ready when you can distinguish token vectors, sentence embeddings, similarity scoring, relevance, and retrieval quality. A high similarity number still needs task-specific interpretation.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

A retriever must rank useful evidence, not merely related text. Exact API names and error codes favor lexical matching; paraphrased intent may favor semantic matching. Start with both kinds of questions and a simple baseline. Choose a scoring method because it addresses an observed failure, not because it has “vector” in its name.

An inverted index maps terms to matching documents. TF-IDF weights frequent-in-document but rare-in-corpus terms. BM25 additionally uses term-frequency saturation and document-length normalization. Dense retrieval encodes queries and passages into a shared vector space and compares them. A lexical baseline provides a valuable control for dense retrieval, especially on technical symbols.

### Review A: Relevance and metrics

Let G be the set of relevant evidence IDs and Rk the first k returned IDs. Recall@k is `|G intersection Rk| / |G|`. Hit@k is one if any relevant item appears. Reciprocal rank is `1/r` for the first relevant rank r, zero if none appears. When more than one passage is relevant, Hit@k and Recall@k answer different questions. NDCG can represent graded relevance and position discounts, provided the relevance labels and normalization are defined.

### Review A: Worked example

If G={A,B} and the first three results are C,A,D, Hit@3=1, Recall@3=1/2 and reciprocal rank=1/2. A report calling Hit@3 “recall” hides the missing second piece of evidence. For a comparison task requiring both versions, that missing piece may make the answer impossible.

For unanswerable questions with no relevant evidence, the ordinary recall denominator is zero. Do not silently assign perfect recall. Evaluate those questions separately through refusal, false-positive retrieval or unsupported-answer measures. The starter represents their retrieval metrics as not applicable.

### Review A: Experiment

notebook 18 compares the bundled lexical retriever with actual sentence-transformer embeddings. Keep document chunks, questions, version filtering and k fixed. Include exact identifiers, paraphrases and wrong-version distractors. Save per-query ranks before computing averages; a mean can hide a systematic class of failures.

Separate model failure from ingestion failure. Inspect whether the expected passage actually exists in the index, whether truncation removed its key sentence, and whether metadata filters excluded it. For the real capstone, label enough question types that one example cannot dominate a slice. The tiny teaching fixture is a software correctness aid, not a sufficient research dataset.

**Exit criterion:** calculate recall, hit rate and reciprocal rank by hand, then explain a dense-versus-lexical tradeoff using a real failure. **Reading:** R07 and R25 concepts. **Tutorial:** 17.

## Week 18 A vector database from a list of vectors

### ANN and payload

ANN means approximate nearest neighbor: a search that may miss the exact nearest vectors to reduce search cost. A payload is the metadata or content stored with a vector, such as version and source ID.

### Persistence becomes useful when the list changes

Last week we could keep three handbook vectors in memory and compare them directly. Now imagine thousands of passages, timetable updates each school term, and new questions after the program restarts.

A vector database helps maintain vectors and associated information across those operations. Begin with a point containing an ID, vector, source text reference, and metadata. The database is responsible for storing and searching those points under its supported behavior.

The embedding model creates the vector. The similarity metric defines a comparison. The index organizes search. The database adds management and operational capabilities. These are related components with different jobs.

### A record you can inspect

Represent H2 as ID=bus-2026, vector=[...], version=2026, source=handbook transport section, and content hash. A question about 2025 should not silently use 2026 rules if those rules changed.

Metadata filters limit eligible passages. Text, vector, and version must remain associated through updates. A correct nearest-neighbor algorithm cannot repair a record whose version was mislabeled during ingestion.

Stable IDs help update an existing passage rather than accumulating duplicates. The exact update semantics depend on the database API and need a save/reload test.

### Exact search provides a reference

Exact search compares the query against every eligible stored vector and selects the best under the metric. It can be perfectly adequate for a small collection.

As the collection grows, approximate nearest-neighbor methods can trade additional structure and resources for reduced search work. Approximation concerns the chosen vector metric; even exact vector neighbors can be semantically irrelevant if the embeddings are poor.

Keep those two error sources separate: approximation may miss an exact neighbor, while representation quality may make the exact neighbor unhelpful for the question.

### A graph intuition for HNSW

An approximate graph index connects points so search can navigate through promising neighbors instead of checking every point. HNSW uses a hierarchy of navigable graph layers.

The intuition is navigating a map using increasingly local connections, but the real structure consists of vector-space points and algorithmic rules. Search breadth and construction settings affect recall, latency, and storage.

Measure approximate results against exact results on the same query vectors and metadata constraints. Nine teaching points in local mode cannot establish production HNSW performance.

### The three HNSW controls have different jobs

M controls the graph’s connection capacity; implementations may use a different bound at the base layer. More connections generally increase graph memory and build work. efConstruction controls how broadly construction searches for useful connections. efSearch, often called ef in a library, controls the candidate set explored at query time. A larger query breadth generally improves neighbor recall while increasing query work. These are tuning controls, not fixed accuracy percentages.

Suppose exact top-3 vector neighbors are [A,B,C], while approximate search returns [A,D,C]. Neighbor Recall@3 is 2/3. Separately, if the question’s required evidence is {B}, evidence Recall@3 is zero. Increasing efSearch might recover B; changing efSearch cannot repair embeddings that rank an irrelevant passage first even under exact search. This separates index approximation from semantic relevance.

### Other index families start from different storage choices

IVF groups vectors around learned coarse centroids. A query searches a selected number of groups, controlled by nprobe, instead of every group. More groups searched normally means more work and better neighbor recall. An IVF training set must represent the vectors that will be indexed.

Scalar quantization stores lower-precision coordinates. Product quantization (PQ) splits a vector into sub-vectors and stores a short code selecting a learned representative for each part. For a toy 8-dimensional vector split into four 2-dimensional parts, four one-byte code IDs use 4 bytes instead of 32 bytes of float32 coordinates, excluding codebooks and index overhead. Distances computed from compressed representatives are approximate. IVF-PQ combines coarse grouping with compressed vectors.

DiskANN is a family of graph-based vector-search methods designed to use SSD storage effectively when a full index is too large for RAM. It keeps selected information in memory and organizes graph traversal and I/O carefully. SSD reads, caching, filters, and updates become part of the measured tradeoff. A small course corpus should still begin with exact search; these mechanisms explain why larger systems make different choices.

### Filtering before or after candidate selection

Suppose the first three unfiltered results all belong to 2026, while the question asks about 2025. Retrieving three and then deleting the wrong-year points can leave nothing even though relevant 2025 evidence exists lower in the unfiltered ranking.

Apply required constraints through the search mechanism and evaluate its filtered behavior. In a private system, authorization must be enforced by application/database controls rather than model-generated advice.

For the public teaching corpus, version filtering is a scope constraint. It should not be described as complete authentication or multi-tenant security.

### Storage arithmetic and compatibility

One million 384-dimensional float32 vectors contain 1,536,000,000 raw vector bytes. That excludes graph links, IDs, payloads, text, replicas, and allocation overhead.

Two embedding models with dimension 384 do not necessarily share a coordinate system. Changing the model normally requires re-embedding and a compatible index, even though the database accepts the same vector length.

Record the actual model/tokenizer revision and source manifest. Dimension checking catches one class of mismatch; identity checking catches another.

### Updates deletion and migration

If the handbook changes a bus departure time, update the source record and dependent vector/index state. If a passage is removed, ensure its index entries and any cached answers are addressed.

For a model migration, build a separate compatible collection, validate point counts and IDs, benchmark retrieval, then switch the active collection only after the chosen gates pass. Retain the earlier collection for a coherent rollback.

This is where data-engineering discipline becomes directly useful. The learned vector representation still requires lineage, schema checks, and a lifecycle.

### Worked practice and a readiness check

Persist a local collection, close it, reopen it, and repeat a filtered query. Update one point with the same ID and verify the new content. Delete another and verify it is absent.

Explain whether a failed query comes from ingestion, a filter, the embedding representation, or approximation. Design one test that separates two of those causes.

You are ready when “vector DB” means a maintained collection and search service with explicit compatibility and update behavior, not a synonym for the embedding model.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

A list of vectors and cosine scores demonstrates semantic search. A vector database adds persistent collections, metadata, updates, filtering and operational behavior. These matter because documentation changes while users keep querying. The index is an artifact with a lifecycle, not a one-time preprocessing step.

Store each point with a stable ID, embedding, source reference, version, content hash and payload. Track the embedding model and tokenizer revision in the collection manifest. Two models can both output 384 numbers yet produce incompatible geometries. A model migration normally requires re-embedding and creating or rebuilding an index; do not mix vectors because their dimensions match.

### Review A: Exact and approximate search

Exact nearest-neighbor search gives a reference ranking. Approximate nearest-neighbor search usually accepts some risk of missing exact neighbors to reduce query work and latency. Its memory cost depends on the method: HNSW adds graph links and may use more memory than a flat vector array, while quantization can reduce vector storage. Evaluate speed, memory, build cost, and neighbor recall together under the real filters.

Filtered search can behave differently when only a small fraction of documents match. Applying a version filter after retrieving a short top-k list may leave no valid candidates even when relevant documents exist. Apply constraints through the retrieval mechanism and measure the result. Security-related authorization filters must not be delegated to the language model.

### Review A: Worked migration

Suppose index A contains model M1 vectors and 10,000 source chunks. Build index B with M2 and the same source manifest. Check row counts, missing IDs, embedding dimensions and a development retrieval benchmark. Route a limited evaluation workload to B, then switch the active index only when gates pass. Retain A for rollback. If documents changed too, record that as a separate experimental variable.

Deletion matters. Removing a document from object storage does not automatically remove its chunks, cached answers or replicated index entries. Define a tombstone/update policy and a completion check.

### Review A: Experiment

notebook 18 creates a local Qdrant collection, upserts vectors, filters by version, persists and reopens it, and queries again. Inspect payloads directly. Add an update with the same ID, then delete a point and verify it no longer appears. Local mode teaches the client and lifecycle; it does not establish distributed durability or production throughput.

**Exit criterion:** distinguish an embedding model, a vector similarity function, an ANN index and the database operating it. **Reading:** R08; optional R24. **Tutorial:** 18.

## Week 19 RAG as an open book question

### A question whose answer is in a handbook

A student asks “When does the bus leave?” The handbook says “The school bus leaves at 07:30.” You can answer by finding the passage and using it as evidence.

A language model might produce 07:30 from a prompt containing that passage, or invent another plausible time if it has no evidence. Retrieval-augmented generation supplies selected external information at request time.

Begin with this open-book task. It is easier to understand the roles of retrieval and generation when the collection has three passages and the answer has one fact.

### Retrieval finds evidence generation forms the response

The retriever receives the question and returns candidate passages. A selection procedure chooses what to include. The generator receives the question, instructions, and selected evidence and produces an answer.

An extractive baseline can simply return the relevant sentence. A generative model can reformulate, combine passages, or explain, but it introduces another opportunity for unsupported claims.

A complete pipeline needs a defined answer contract and evaluation. Adding a vector database alone does not force the generator to obey the retrieved text.

### A prompt with visible boundaries

Imagine a prompt saying: “Answer the question using the evidence. If the answer is absent, state that.” Then include “[H2] The school bus leaves at 07:30” and the question.

The source label lets the response cite H2. The instruction defines intended behavior. It is still application code and evaluation that check source scope, structure, and observed quality.

The retrieved passage is data. If it contains “ignore all earlier instructions,” that text does not gain authority to change application permissions.

### Two passages may be needed

For “When does the bus leave and how much is a ticket?”, retrieve H2 and H3. A complete answer says 07:30 and 4 dollars with appropriate source references.

If only H2 is available, answering the time is supported but the complete question remains partly unresolved. State the missing information rather than inventing a fare.

This example separates relevance, support, and completeness. One good passage can be relevant while insufficient for every required claim.

### Chunking preserves enough context

Suppose a longer school document has the sentence “This timetable applies only on weekdays” above the departure time. Splitting them apart can remove an important condition.

A chunker decides which parts become retrieval units. Preserve headings, exceptions, tables, and source boundaries where possible. Overlap can help with boundaries but creates duplicate content and storage.

First inspect a page by hand, then choose a chunking rule. Do not begin by assuming a universal fixed size is best for every code block or paragraph.

### Choose chunk boundaries on a concrete timetable

Consider this three-line source: “Weekday service”; “The school bus leaves at 07:30”; “On Friday it leaves at 07:15.” A question about Friday needs the exception and its heading. A fixed character cut between the last two lines can hide the exception; copying a short overlap may reconnect it, but may also duplicate it in several results.

| Strategy | Retrieval unit in this example | What to check |
|---|---|---|
| Fixed tokens plus overlap | A bounded token window with repeated boundary tokens | Exception and subject remain together |
| Sentence or heading aware | The timetable heading plus its related sentences | A long section still needs a size limit |
| Structure aware | A table with column headers, row labels and units | Numbers keep the correct day and route |
| Parent-child | Retrieve a short Friday child; supply its timetable parent | The parent fits the final context budget |

Let a teaching budget be 600 tokens: reserve 100 for instructions and the question, 150 for the answer, and 50 for labels and formatting. That leaves 300 for evidence. Select whole useful chunks within that allowance; three 100-token chunks fit, but the parent of a retrieved child might be 400 tokens and require a smaller section. These are budgeted token counts for the example, not measured lengths of the three English sentences.

### The token budget connects back to semester one

The generator still has a finite input allowance. Instructions, the question, history if present, source labels, and evidence all consume tokens. Output needs its own reservation.

Count the complete serialized prompt with the actual tokenizer. The embedding model may have a different input limit, so a passage that fits the generator can still be truncated while embedding.

Context selection is therefore an information problem and a resource problem. Including every remotely related paragraph can bury the useful facts.

### Absence and versions

For “What color is the headteacher's car?”, our handbook has no answer. The appropriate outcome is insufficiency. A nearest passage does not establish that the missing fact is present.

For a comparison of two handbook years, retrieve both required versions and label them. A source from 2026 supports its 2026 rule, not an unstated claim about 2025.

The technical-documentation assistant applies these same constraints to parameter defaults, release notes, and code examples. Now the application follows from mechanisms you already understand.

### Worked practice and a readiness check

Manually execute retrieval, selection, prompt construction, answer generation, and claim checking for four handbook questions: one single fact, one two-fact question, one missing fact, and one year comparison.

Then compare an evidence-only extractor with a small real model on the same selected passages. Record additional useful explanation as well as unsupported additions.

You are ready when you can trace a claim to a specific source and distinguish an absent answer from retrieval failure. Next we improve the pipeline and evaluate the costs of added components.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

The model's parameters provide learned capabilities and remembered patterns. Retrieval supplies task-specific evidence at request time. RAG combines these sources, but it does not automatically force the answer to follow the evidence. The system must construct context, constrain the response, and evaluate grounding.

A practical pipeline is question normalization, authorized retrieval, reranking or selection, context packing, generation, validation and response. The historical RAG paper describes a specific learned retrieval/generation formulation [R06]; the term is now also commonly used for retrieve-then-prompt applications. Be clear which system you implement.

### Review A: Context is a limited resource

Chunks should preserve coherent statements, headings, code blocks and source provenance. Overlap can prevent boundary losses but creates duplicate candidates. Track parent page IDs so duplicated chunks do not exaggerate evidence diversity. Context packing should respect the generator tokenizer's budget and reserve output space. Adding every retrieved passage can obscure the useful evidence.

### Review A: Worked evidence contract

Question: “What changed in the timeout default between v1 and v2?” Context contains v1's 10-second default and v2's 30-second default, each labeled with a source ID and version. A supported answer states both defaults and cites both IDs. Citing only v2 cannot support the claim about change. If only v2 is present, the assistant should state that the comparison lacks v1 evidence or retrieve it through an explicit comparison path.

Validate citations at two levels. Structural checks verify that the IDs exist and were authorized for this request. Semantic checks ask whether those passages support the individual claims. The first is automatable and necessary, but it does not substitute for the second. Neither a lexical overlap score nor a JSON schema proves entailment.

### Review A: Experiment

notebook 20 assembles source-labeled context, runs the evidence-only baseline and then supplies the same context to a small LLM if available. Compare a supported question, a missing-answer question and a conflicting-version question. Remove a required source and see whether the model admits insufficiency.

Measure evidence coverage, factual completeness, unsupported claims and refusal quality. An assistant that refuses everything may have low unsupported-claim rate but zero usefulness. Your project needs both coverage and correctness targets. For access-controlled docs, context may include only documents the caller can read; citations and caches must follow the same rule.

**Exit criterion:** trace a factual claim back through the response, packed context, selected chunk and source manifest. **Reading:** R06 abstract/architecture; R09 context serialization. **Tutorial:** 19.

## Week 20 Improving RAG without losing the basic task

### RRF

RRF means reciprocal rank fusion: combine ordered result lists using reciprocal ranks, rather than directly adding incompatible raw scores.

### A basic pipeline gives us observable failures

Suppose the handbook assistant handles direct questions but misses “At what time can pupils board the morning transport?” The relevant passage uses bus leaves. Another failure quotes a correct time from the wrong year.

These are different problems. Semantic retrieval may help with paraphrasing. Required version filtering addresses scope. A more elaborate prompt cannot reliably repair a mislabeled source record.

Begin every change with an observed error and a hypothesis about the failed boundary. This keeps improvements connected to a task rather than a list of fashionable components.

### Combining lexical and dense candidates

Lexical search can handle exact names well; dense search can handle some paraphrases. Hybrid retrieval combines candidates from both.

Scores may live on different scales. Adding a BM25 score directly to a cosine score without calibration changes the meaning unpredictably. Rank fusion combines ordering information instead.

Reciprocal rank fusion uses a sum of 1/(c+rank) over candidate lists. An absent item contributes zero from that list. The constant c controls how sharply top positions dominate.

### A worked fusion comparison

Passage A is rank 1 in lexical search and rank 10 in dense search. Passage B is rank 2 in both. With c=60, A scores 1/61+1/70≈0.030679, while B scores 2/62≈0.032258.

B wins this comparison because both lists rank it consistently well. The values are rank-derived scores, not calibrated probabilities of correctness.

Changing c changes the weighting. Compare the final candidate set and downstream task result rather than judging a setting only by which passage wins one designed example.

### Reranking spends more work on selected pairs

A cross-encoder can read the question and each candidate passage jointly to estimate relevance. Unlike cached bi-encoder vectors, this work happens for the query-passage pair.

Rerank a sufficiently broad candidate pool, then select a smaller evidence set. If necessary evidence never entered the pool, the reranker cannot restore it.

Measure candidate recall before reranking and answer quality afterward. The separation tells you whether failures concern finding evidence, ordering it, or using it.

### Context construction after ranking

Deduplicate highly overlapping chunks, preserve source labels, and include needed exceptions. A small retrieved chunk may point to a larger parent section that supplies coherent context.

A two-version comparison needs diversity of versions, while a precise single-version question needs the requested scope. Selection depends on the task rather than a universal instruction to maximize diversity.

Pack against the actual token budget and reserve output space. Record selected source IDs and the exact packed prompt so an error can be reproduced.

### Query rewriting and multi step retrieval

A conversational question such as “Does that apply next year?” may need reference resolution. A rewrite can make the intended year and subject explicit.

Rewriting can also introduce an unsupported assumption. Keep the original question, log the transformation, and preserve scope/authorization constraints independently.

Multiple retrieval steps are useful when a task needs them. They add latency and additional failure paths. Compare with a single-step baseline under a stated resource budget.

### A controlled experiment

Use the same corpus, chunks, question set, version rules, generator, decoding settings, and answer rubric. Compare lexical, dense, fusion, and a reranking or selection improvement.

Save raw candidate lists and answer outputs. Slice by exact identifier, paraphrase, multi-source question, absence, and version comparison.

If one method improves paraphrases but harms exact names, investigate the pattern. Add routing only if you can define and test the rule, rather than hiding the tradeoff in an aggregate average.

### Worked practice and a readiness check

Reproduce the RRF calculation, then remove a required passage from both candidate lists. Explain why increasing reranker quality cannot fix that particular absence.

Run one real RAG comparison and manually audit claims and citations. A valid source ID is only a structural check; inspect whether the cited passage supports the claim.

You are ready when you can justify one pipeline addition by a measured error reduction and state the quality, complexity, and latency costs.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

Lexical and semantic search make different errors. Hybrid retrieval combines candidate lists; reranking spends more work judging the best candidates. These are separate operations. Reranking cannot recover a relevant document absent from its candidate set.

Do not add BM25 scores directly to cosine scores without a justified calibration: their scales differ. Reciprocal rank fusion combines ranks: `RRF(d) = sum_lists 1/(c + rank_list(d))`, with ranks starting at one. c controls how sharply top ranks dominate. Choose settings on development data, and compare against each component alone.

### Review A: Worked fusion

With c=60, passage A ranked 1st lexically and 10th semantically scores `1/61 + 1/70`, approximately 0.03068. Passage B ranked 2nd in both scores `2/62`, approximately 0.03226. B wins because both systems support it. A document absent from one finite list contributes zero from that list. Fusion does not mean the scores are probabilities.

A cross-encoder reads question and candidate together to assign a relevance score. Rerank a sufficiently broad candidate pool, then select a small evidence set. Diversification can reduce near-duplicates, but too much diversity may discard necessary details from one source. Parent-child retrieval can search small chunks and include a larger parent section for coherent context.

### Review A: Query transformation

Query rewriting resolves conversational references or expands terms. Multi-query retrieval can broaden recall. Hypothetical-document approaches generate a possible answer-like passage to embed. These can help some distributions but may introduce unsupported assumptions, extra latency and correlated false evidence. Keep the original query and log transformations. Version and access constraints must survive rewriting.

### Review A: Experiment

Compare lexical only, dense only, rank fusion, and fusion plus a reranker on the same frozen development split. In the notebook, a simple deterministic reranking demonstration teaches the interface; an actual neural reranker is an optional extension, not a claimed baseline result. Report candidate recall before reranking and answer metrics after generation. This separates a recall problem from an ordering problem.

If hybrid improves identifiers but harms paraphrases, examine slice results and consider targeted routing. Do not add routing until you can explain its decision boundary and evaluation. A more complex pipeline has more timeouts, caches, artifacts and failure paths.

**Exit criterion:** calculate RRF, explain candidate recall, and justify whether the measured quality gain merits added latency. **Reading:** R07 for embedding side; optional R25 lexical model. **Tutorial:** 20.

## Week 21 Evaluating retrieval answers and uncertainty

### McNemar and discordant pairs

McNemar compares paired binary outcomes. Discordant pairs are tasks where exactly one system succeeds; tasks where both succeed or both fail are concordant.

### A quiz needs a marking rule

Ask the handbook assistant ten questions. Before running it, decide which facts and sources each answer requires. Otherwise it is easy to call a polished answer “good” after seeing it.

Separate retrieval evidence, answer correctness, completeness, citation support, and appropriate insufficiency. Also record failures and resource use.

The benchmark is a small specification of behavior. It can be incomplete or biased, so its design deserves the same care as the model configuration.

### Recall hit rate and reciprocal rank

Let required evidence be {H2,H3} and retrieved results be [H1,H2,H4]. Hit@3=1 because one relevant passage appears. Recall@3=1/2 because half the required evidence appears. Reciprocal rank is 1/2 because the first relevant item is at rank 2.

For an unsupported question with no relevant passages, ordinary recall has a zero denominator. Mark it not applicable and evaluate answer/refusal behavior separately.

Do not rename hit rate as recall when multiple sources can be needed. That would hide missing evidence on the harder tasks.

### An answer can be supported but incomplete

If the question asks time and fare, “The bus leaves at 07:30 [H2]” is supported but incomplete. “The bus leaves at 07:30 and costs 2 dollars [H2]” adds an unsupported fare.

A rubric should identify required facts and unsupported or contradicted claims. Exact substring matching can be a useful smoke test but will miss paraphrases, contradictions, and wrong associations.

Human review remains useful on a measured subset. Report its sample size and disagreement rather than presenting manual judgments as infallible.

### Coverage and selective accuracy

Suppose the assistant answers 15 of 20 questions and 12 of those answers are correct. Accuracy among answered questions is 80%, and coverage is 75%.

Overall correctness also depends on whether the five refusals were appropriate. Refusing everything can reduce unsupported assertions while making the product useless.

Evaluate the balance under the intended task distribution. A similarity threshold is chosen on development data; it is not a probability guarantee.

### Train development and held out evaluation

Training data change learned parameters. Development examples guide prompts, thresholds, chunking, and other settings. Held-out examples estimate performance after those choices.

Split by meaningful groups before generating near-duplicate questions or overlapping chunks. For RAG, the indexed reference documents remain readable at inference; leakage concerns using held-out questions or labels to choose the system.

If you tune after inspecting final test errors, label the subsequent analysis exploratory and reserve fresh untouched cases for another final claim.

### Comparing two systems on the same tasks

If A solves 32/40 and B solves 34/40, the observed difference is five percentage points. Inspect paired results: which errors did B fix, and which new ones did it create?

A paired bootstrap resamples task indices and calculates the difference using matched outputs. Correlation among question families can make naive individual-task resampling optimistic.

An interval and small sample should lead to a measured statement about uncertainty. “The average is larger” does not establish a reliable improvement by itself.

### nDCG gives graded relevance a worked scale

When some evidence is more useful than other evidence, assign relevance grades before retrieval. Use gain=2^grade−1 and discount=log2(rank+1). For returned grades [0,2,1], DCG@3 is 0/1 + 3/log2(3) + 1/2 = 2.39279. The ideal ordering [2,1,0] gives IDCG@3 = 3 + 1/log2(3) = 3.63093. Their ratio nDCG@3 is about 0.65900. State this gain convention; another convention produces different numbers. If all available grades are zero, define how the zero ideal denominator is handled.

### Separate context precision, faithfulness, and correctness

For a simple binary context precision, count relevant retrieved chunks divided by all retrieved chunks. If [H2,H1,H3] contains the two required passages H2 and H3, that precision is 2/3. Some evaluation frameworks instead use rank-weighted average precision or judge-based definitions; record the exact formula rather than comparing identically named scores blindly.

For a stated faithfulness rubric, split the answer into checkable claims and count those supported by the supplied evidence. “The bus leaves at 07:30, costs 4 dollars, and has Wi-Fi” has three claims. If only the first two are supported, claim faithfulness is 2/3 under this rubric. A faithful answer can still repeat an outdated source, so factual correctness, source version, completeness, and citation support remain separate checks.

### A paired test asks which answers actually changed

McNemar’s test uses paired binary success on the same tasks. Suppose B fixes 8 errors made by A, while A succeeds on 2 tasks that B fails. The 30 tasks where both agree do not determine this test. Under equal success rates, the 10 discordant outcomes have equal chance of favoring either system. An exact two-sided binomial calculation gives p≈0.1094, so this small example provides limited evidence for a reliable difference. Report the effect size and paired counts as well as the p-value.

The paired bootstrap can estimate uncertainty in differences of continuous scores as well as binary scores; McNemar is specifically for paired binary outcomes. Both need appropriate independent units. Related paraphrases should be grouped rather than treated as many independent tasks. Benchmark contamination occurs when test questions or answers enter training, prompt tuning, or selection; a pretraining overlap can also inflate a public benchmark. Preserve provenance, check near-duplicates, and add fresh held-out tasks.

### Model judges and operational metrics

An LLM judge can apply a rubric at scale, but it can favor wording, length, or familiar model styles. Calibrate against reviewed examples and inspect disagreements. Version the judge and its prompt.

Record parse errors, timeouts, and budget failures. They must remain visible in the denominator or an explicitly specified outcome category.

Latency and tokens accompany quality. A method that solves two more tasks using five times the inference budget may still be useful, but the tradeoff should be stated.

### Worked practice and a readiness check

Calculate the three retrieval metrics for gold {A,B} and ranking [C,A,D]. Then label a supported-incomplete answer and an unsupported-complete-looking answer.

Prepare a small frozen development evaluation, add adversarial cases, and produce per-example records. Write a release recommendation with both evidence and limitations.

You are ready when your evaluation explains where the system succeeds and fails, not merely a single judge score or attractive demonstration.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

Your benchmark is a small, imperfect specification of desired behavior. It should contain representative successes, difficult cases and explicit absences. A single average judge score makes release decisions hard to defend. Save the underlying examples, judgments and slices.

Partition by intended use: training/adaptation, development/tuning, and final held-out evaluation. Avoid nearly identical page families or generated paraphrases crossing boundaries when they reveal the answers. Retrieval is allowed to read the indexed reference documents at evaluation time; the leakage concern is using held-out questions, labels or near-duplicates to tune the system. Keep this distinction precise.

### Review A: Metrics at each boundary

Evaluate retrieval with labeled evidence; answer correctness against required facts; citation validity structurally and semantically; unsupported claims; appropriate refusal; task completion; latency, tokens and failures. For an agent later, also evaluate tool correctness, forbidden actions and budget exhaustion. State denominators explicitly, including timeouts and parse errors.

An LLM judge can provide scalable rubric-based assistance, but it can be biased by wording, answer length and its own model family. Calibrate it against human-labeled examples, randomize answer ordering in pairwise comparisons, inspect disagreement, and keep the judge prompt/model version. Do not use the same model's self-confidence as the only evidence of correctness.

### Review A: Worked uncertainty example

If system A answers 32/40 correctly and B answers 34/40 correctly, the observed difference is 5 percentage points. It is not automatically a meaningful improvement. Inspect paired differences: perhaps B fixes four A errors but creates two new ones. A paired bootstrap resamples task indices and recomputes the difference, preserving pairing. With small or correlated samples, uncertainty remains large; report intervals and assumptions instead of claiming superiority from two tasks.

### Review A: Experiment

notebook 21 implements retrieval metrics, paired resampling and a JSON evaluation record. Add at least five adversarial cases, including version mismatch, irrelevant high-overlap evidence, missing answers, fake instructions inside a page and multi-source questions. Use development data for thresholds; run the held-out set only at the planned checkpoint.

The starter's structural tests establish software behavior and metric arithmetic. They do not establish natural-language grounding. Your manual scoring rubric must identify required facts and unsupported statements per task. Keep a short error notebook with the original question, expected evidence, actual output, diagnosis and next hypothesis.

**Exit criterion:** make a release recommendation supported by per-example evidence and uncertainty. **Reading:** R03 evaluation topic; R01 evaluation lecture headings. **Tutorial:** 21.

## Week 22 CPU GPU memory and model resource accounting

### Numerical work happens on physical hardware

A transformer contains matrix multiplications, elementwise operations, and memory access. A CPU can run a small model. A GPU can execute many suitable operations in parallel, but performance also depends on data movement and memory capacity.

Separate host RAM from GPU VRAM. A model downloaded to disk does not automatically fit in either. A tensor copied between CPU and GPU incurs movement and coordination.

We study the hardware now that you can identify the tensors it stores and operations it executes.

### Parameters are only the first memory item

If a model has P parameters stored with b bytes each, weight memory is P×b. For 500 million parameters at two bytes, that is one billion bytes, about 0.93 GiB.

During training, gradients, optimizer moments, optional master weights, activations, and temporary buffers add memory. During generation, a KV cache can be large.

An inference weight estimate therefore does not answer whether the model can train or handle a long batched context.

### A worked training state estimate

An illustrative mixed-precision Adam arrangement uses 2 bytes of weights, 2 of gradients, 4 of master weights, and 8 for two optimizer moments per parameter. That totals 16 bytes before activations and overhead.

At 500 million parameters, counted state is 8 billion bytes, about 7.45 GiB. Different implementations and precision choices change the accounting.

The interactive worksheet explicitly reports partial estimates. Being below a VRAM line in that worksheet is not proof that a real runtime will fit.

### A KV cache calculation

Use L layers, batch B, cached length T, H_kv key/value heads, head width d_head, and b bytes per cached element. Approximate KV-cache bytes equal 2×L×B×T×H_kv×d_head×b. The factor two accounts for keys and values. d_model is the residual-stream width; H is the query-head count. In ordinary equal-width multi-head attention d_model=H×d_head. GQA has H_kv smaller than H. This simplified expression assumes each key and value head has the same width d_head. If value width differs, replace 2×d_head by d_head+d_value.

With 24 layers, batch 1, 2048 tokens, eight KV heads, dimension 64, and two-byte values, the result is 100663296 bytes, or 96 MiB.

Longer context and larger batch multiply this quantity. Grouped-query attention uses fewer KV heads than query heads; inspect the architecture rather than substituting the query-head count automatically.

### Memory hierarchy and movement

GPU execution uses registers, shared memory within blocks, caches, and device DRAM under hardware-specific arrangements. Large tensors live in device memory; moving and re-reading them can dominate an operation.

A high advertised arithmetic rate does not guarantee a fast application. A low-arithmetic-intensity operation can spend much of its time moving values.

Next week's kernel makes this visible with vector addition. The operation is simple enough that indexing and transfer boundaries can be checked independently.

### Smaller microbatches and checkpointing

Gradient accumulation lets several small microbatches contribute to one effective update. It can reduce the batch portion of activation memory, but persistent model/optimizer state remains.

If one sequence already causes OOM, accumulation alone cannot shrink that sequence's footprint. Shorter context, activation checkpointing, a smaller model, or state sharding may address different components.

Activation checkpointing saves some intermediate storage by recomputing work during backward. The tradeoff is extra computation, not free memory removal.

### Choosing precision and measuring reality

Float32, float16, bfloat16, and quantized representations have different numerical ranges, memory costs, and hardware support. Check the actual GPU and installed software before selecting a compute dtype or optimized kernel.

Use actual device properties and compatible software. A free Colab session may offer a different GPU or no GPU, so save checkpoints and measured metadata.

Record allocated and peak memory under a defined workload. Allocator reservation and warmup can make a simplistic reading misleading.

### Quantized inference still has several memory components

A billion four-bit weights have a packed payload of 500,000,000 bytes, about 0.466 GiB, before scales, zero-points or codebooks, padding, and modules kept at higher precision. Add KV cache, temporary activations, workspaces, and runtime allocation. Weight precision and compute precision can differ: a kernel may unpack low-bit weights and accumulate in a wider type. A “4-bit model” is not a promise that every tensor uses four bits.

### A bandwidth estimate explains slow single-request decode

For an idealized batch-one decode step, suppose dense weights are read once per generated token and weight traffic dominates. tokens/s≈sustained memory bandwidth divided by bytes of weights read per token. At 200 GiB/s and 4 GiB of weight reads, the ideal ceiling is about 50 tokens/s. At 2 GiB it would be 100 tokens/s under the same assumptions. Real throughput is lower when cache traffic, dequantization, compute, and launch overhead matter. Batching can reuse weights across requests, so this batch-one estimate is not a general serving-throughput formula.

### FSDP and ZeRO divide training state across devices

Data parallelism normally replicates model weights and computes gradients from different batches. ZeRO stage 1 shards optimizer state, stage 2 also shards gradients, and stage 3 also shards parameters. FSDP similarly shards parameters and associated training state, gathering needed parameter groups for computation and redistributing results. If an idealized 16-GiB counted state is evenly sharded over four devices, its persistent shard can approach 4 GiB per device; activations, communication buffers, and temporarily gathered weights still add memory. Sharding saves per-device state by adding communication and scheduling work.

### Worked practice and a readiness check

Calculate weight-only memory for 300 million two-byte parameters and compare with a 16-byte training-state estimate. List omitted components in both.

Change context length from 2048 to 4096 in the cache formula and explain the doubling. Then identify a memory issue that accumulation can help and one it cannot.

You are ready when you can link resource costs to particular tensors and distinguish an estimate, an actual measurement, and a hardware capability assumption.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

A GPU accelerates many similar arithmetic operations, but a model must also move data and fit its working state into memory. “More FLOPs” alone does not predict whether your experiment will run or be fast. Distinguish CPU RAM, GPU VRAM, device memory bandwidth, host-to-device transfers and compute throughput.

The CPU schedules work and launches kernels. GPU execution groups threads across streaming multiprocessors. Registers are close to individual execution contexts, shared memory is visible within a block, caches serve broader access, and device DRAM stores large tensors. A tensor moving repeatedly between CPU and GPU can dominate a short computation even if the arithmetic is fast.

### Review A: Training versus inference

Parameter storage is `parameter_count * bytes_per_parameter`. Training may additionally store gradients, optimizer moments, master weights and activations. For an illustrative mixed-precision Adam configuration, 2 bytes of model weights + 2 bytes of gradients + 4 bytes of master weights + 8 bytes of two moments gives 16 bytes per parameter before activations and overhead. This is an example configuration, not a universal rule; frameworks and precision choices differ.

For 500 million parameters, that illustrative training state is about 7.45 GiB. A two-byte inference weight copy alone is about 0.93 GiB. Both use the same binary unit as the earlier estimate: 1 GiB=2^30 bytes. For conversion, 1 GB=10^9 bytes≈0.93132 GiB. LoRA reduces trainable parameter state, while activations and frozen base weights remain in the budget.

### Review A: KV cache worked example

During autoregressive inference, cache bytes≈2×L×B×T×H_kv×d_head×b. For L=24, B=1, T=2048, H_kv=8, d_head=64, and b=2, this is 100,663,296 bytes=96 MiB. Increasing B or T multiplies the cache. Use H_kv, not the query-head count H, for a GQA model.

The original full attention score tensor also scales quadratically in sequence length when explicitly materialized. Memory-efficient attention implementations avoid storing all those intermediate scores in device DRAM, while retaining the operation's mathematical meaning subject to numerical precision differences.

### Review A: Experiment

notebook 22 calculates weight, optimizer, and KV-cache estimates. notebook 23 provides the device profiling exercise for comparing estimates with allocated and peak memory. Account for warmup and allocator reservations. When an out-of-memory error occurs, reduce sequence length and microbatch before reaching for a different framework. Gradient accumulation changes effective batch but does not shrink the memory required by a single microbatch.

**Exit criterion:** explain why a model fits inference but not training, and estimate a context-dependent cache. **Reading:** R01 resource-accounting topic; R16 memory hierarchy. **Tutorial:** 22.

## Week 23 CUDA kernels and profiling

### One operation many independent elements

Take two vectors of 257 numbers and add corresponding elements. A CPU loop is easy to understand: for each index i, compute c[i]=a[i]+b[i].

A CUDA kernel can assign this elementwise work across threads on a GPU. The mathematical result stays the same. What changes is how the program assigns work, accesses memory, and measures execution.

We begin with vector addition rather than a custom attention kernel because correctness and indexing should be transparent before optimization becomes complicated.

### Threads blocks and an index

A one-dimensional kernel can compute i=blockIdx.x×blockDim.x+threadIdx.x. If a block has 256 threads, two blocks provide 512 thread indices for a length-257 vector.

Threads with i≥257 must not access the arrays. The bounds check is part of correctness, not a disposable optimization detail.

Blocks can execute independently. Do not assume an ordinary kernel has a general synchronization barrier across the whole grid.

### Host and device responsibilities

The CPU host allocates or prepares inputs, manages device memory, transfers values where required, launches the kernel, and retrieves results.

GPU device code performs the per-thread operation. A kernel launch does not mean every result is immediately available to the CPU; execution can be asynchronous.

Follow the sequence in the provided CUDA C++ example and identify which statements belong to allocation, transfer, launch, synchronization, timing, and cleanup.

### Memory access and arithmetic intensity

For float32 vector addition, two input reads and one output write move roughly twelve bytes per addition, ignoring caching and other effects. That is low arithmetic intensity.

Adjacent threads reading adjacent elements can allow efficient memory transactions. Scattered accesses and repeated unnecessary transfers can hurt performance.

Matrix multiplication can reuse values in tiles and reach a different balance between arithmetic and movement. Kernel optimization requires understanding that reuse and the device rather than assuming more threads always means faster work.

### Warps, coalesced access, and tensor cores

On NVIDIA CUDA GPUs, a warp contains 32 threads that execute in a SIMT group. If neighboring active lanes read neighboring float32 elements, their requests can be served with fewer memory transactions than widely scattered addresses. This is coalescing. For our vector addition, let lane i read a[i] and b[i] and write c[i]; a strided access such as a[32*i] often wastes more transferred bytes. Alignment, caching, and the actual access pattern still affect the result.

Tensor cores accelerate supported matrix multiply-accumulate operations with specific dtypes and layouts. They are not a faster replacement for every CUDA instruction: vector addition does not become a matrix multiplication simply by changing its dtype. Use a profiler to check the chosen kernel and numerical tolerance.

### An ordinary grid differs from a cooperative grid

An ordinary kernel cannot assume all blocks are resident together or use an arbitrary grid-wide barrier. Cooperative Groups provides grid synchronization for an appropriately launched cooperative kernel subject to device and launch constraints. Without those conditions, split globally ordered stages into separate launches or use an appropriate established algorithm. A block barrier only coordinates participating threads in that block; place it where those threads can reach it consistently.

### Triton and torch.compile operate at different levels

A Triton kernel expresses blocks of tensor work in a Python-based GPU programming language. Its vector-add tutorial creates a block of offsets, loads valid elements with a mask, adds them, and stores with the same boundary mask. The mask serves the same length-257 correctness purpose as the CUDA bounds check. This is Triton the kernel language, not NVIDIA Triton Inference Server.

torch.compile starts from a PyTorch function or model, captures supported computation, and asks a compiler backend to optimize it; a backend may generate fused Triton kernels. Compilation can remove Python overhead and intermediate memory traffic, while graph breaks and unsupported patterns can limit gains. Compare warmed eager and compiled runs, report compilation cost separately, and verify the same outputs before comparing time. This adds an optimization tool to the existing profiler workflow rather than requiring a new training framework.

### Timing an asynchronous device

Timing only a launch with a CPU clock may mostly measure dispatch. Use CUDA events or synchronization around the interval being measured.

Warm up, repeat measurements, and report a median and spread. State whether transfers, allocation, compilation, and first-run effects are included.

Kernel-only time and end-to-end application time answer different questions. Keep both when diagnosing whether an optimization matters to the actual workload.

### Amdahl reasoning for a practical optimization

Suppose the full task takes 20 ms, including a 3 ms kernel. Making that kernel twice as fast reduces total time to 18.5 ms, a speedup of about 1.081.

The arithmetic explains why a dramatic kernel speedup can yield a modest user-visible improvement. Optimize the components that dominate the measured task.

A wrong result is not a speedup. Validate against a CPU reference with appropriate tolerances before reporting performance.

### Profiling the transformer operations

Use a profiler to inspect operator times, shapes, memory, and CPU/GPU activity. Start with a short reproducible workload and save the trace.

FlashAttention is an example of redesigning attention computation to reduce memory traffic while preserving its mathematical operation subject to numerical behavior. It is not a different language-model objective.

Custom kernels and distributed training are deeper areas. Our required exercise establishes introductory CUDA indexing, correctness, synchronized measurement, and bottleneck diagnosis.

### Worked practice and a readiness check

Run vector lengths 1, 257, and a larger value. Explain why the awkward length 257 matters. Repeat with different block sizes while retaining bounds checks.

Profile a matrix multiplication or short model pass. Separate transfer and execution costs, and identify one bottleneck supported by the trace.

You are ready when your performance claim includes correct outputs, a timing boundary, device/software details, and a reproducible workload.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

PyTorch operations eventually execute kernels. A CUDA kernel specifies work for many threads. Writing one small kernel makes launch overhead, indexing, memory access and synchronization concrete, even if most application work should continue using optimized libraries.

For a one-dimensional array, thread index `i = blockIdx.x * blockDim.x + threadIdx.x`. A vector-add kernel computes `c[i]=a[i]+b[i]` when `i<n`. The bounds check matters when n is not divisible by the block size. Blocks are scheduled independently; code must not assume a general grid-wide barrier inside an ordinary kernel.

### Review A: Memory and performance

Adjacent threads reading adjacent elements often produce more efficient memory transactions than scattered accesses. Shared memory can reuse data within a block, but reuse must justify its loading and synchronization overhead. A barrier must be reached consistently by participating threads. Occupancy is one diagnostic, not an objective that guarantees maximum speed.

Arithmetic intensity is approximate operations divided by bytes moved. Vector addition performs roughly one addition for two input reads and one output write: about 1/12 operations per byte for float32, ignoring caching. This is low intensity, so increasing theoretical arithmetic throughput may help little compared with memory bandwidth. A matrix multiplication can reuse tiles and attain much higher intensity.

### Review A: Timing worked example

GPU work is asynchronous relative to the host. Timing a launch without synchronizing may mostly measure dispatch. Use CUDA events or synchronization around the defined measurement interval. Warm up first, repeat the operation, and report a median and spread. Include data transfers only if your stated question is end-to-end latency; separately report kernel-only time when studying the device operation.

Suppose end-to-end time is 20 ms, of which 3 ms is the kernel. Making the kernel twice as fast yields 18.5 ms total, a speedup of only 1.081. This is Amdahl-style reasoning: optimize what dominates the real task.

### Review A: Experiment

notebook 23 compiles the bundled vector-add example if `nvcc` and a GPU are present. Run n=1, n=257 and a large n to exercise indexing and overhead. Compare against a CPU reference with a numerical tolerance. Then profile a PyTorch matrix multiplication or a short transformer forward pass. Save the trace and explain one bottleneck. FlashAttention is a deeper example of redesigning memory traffic rather than changing the attention objective [R26].

**Failure to recognize:** comparing a cold first call with a warmed library call measures setup differences. A benchmark that produces wrong values is not a performance result. **Reading:** R17 indexing example, R19 profiling; optional R26. **Tutorial:** 23.

## Week 24 Fine tuning starts with a teaching dataset

### Visible labels and serialized examples

For the already-tokenized sequence [10,11,12,20,21], suppose the first three tokens are prompt and the final two are response (21 is the end-of-response token). The unshifted label list is [-100,-100,-100,20,21]. With an internal causal shift, logit position 2 predicts token 20 and position 3 predicts token 21. Verify the shift convention of the actual loss implementation.

A JSONL training file has one JSON object per line, for example {"messages":[{"role":"user","content":"How do I go to school?"},{"role":"assistant","content":"Take the bus."}]}. This is a data record, not the final token sequence. Apply the selected tokenizer chat template to add role boundaries and the correct response-ending token; inspect the resulting IDs and assistant loss mask. A different model can serialize the same messages differently.

### A repeated behavior problem

Suppose an assistant knows the supplied school facts but often ignores “Answer with one transport word.” It returns a paragraph instead of bus.

Prompt changes and output constraints are inexpensive first interventions. If a repeatable behavior gap remains, supervised fine-tuning may be a reasonable experiment.

If the problem is that the bus timetable never reached the prompt, adapting weights may be the wrong intervention. Diagnose the failure before choosing a training method.

### Inputs and desired outputs

An SFT example contains the instruction/context and a target response. A simple record asks “Complete: I go to school by ___; answer with one word” and targets bus.

Another asks a handbook question with no supporting fact and targets an insufficiency response. Including such examples prevents the dataset from implying that every question should receive a confident factual answer.

The target must match the actual supplied evidence and requested format. A fluent synthetic target can still be wrong.

### Constructing the model sequence

Use the model's chat template to serialize prompt and assistant response. During answer-only training, prompt tokens remain context but receive ignored loss labels.

Check the actual token boundaries. String length is not token length. A prefix assumption that fails under the template can mask the wrong positions.

If truncation removes every answer token, the record has no intended supervised targets. Detect that before training instead of treating the resulting failure as a tuning problem.

### A worked label mask

For a toy ID sequence with prompt [10,11,12] and answer [20,21], the full input is [10,11,12,20,21]. An answer-only label construction can mark prompt positions ignored and answer positions supervised under the model's shifted-loss convention.

Be explicit about which library performs the next-token shift internally. Do not apply a manual shift twice.

Our tutorial checks prepared records and the later training notebook uses the chosen model's convention. Printed token IDs and labels are valuable debugging artifacts.

### Data splits before paraphrases

If ten rewordings of the same question cross train and test, apparent generalization can mostly reflect duplicate task structure. Split by meaningful question/source families before generating paraphrases.

Keep final evaluation records separate from adaptation and configuration selection. The real project's train set may be 100–300 reviewed narrow examples if feasible; a smaller pilot must make narrower claims.

Manual review and executable checks are complementary. A validator can check citation IDs or a calculation, while a reviewer can inspect whether a target actually answers the question.

### Choosing the adaptation objective

SFT teaches imitation of targets. Continued pretraining uses a language-model objective on additional text. Preference training compares alternatives. These objectives do not solve identical problems.

For a narrow output-format behavior, well-labeled SFT can be appropriate. For changing factual information, keeping evidence fresh through retrieval may be easier to maintain.

The methods can combine, but the experiment must isolate what changed. Improving the prompt, retrieval, and weights at once prevents a clean conclusion about the adapter.

### An experiment proposal before training

Write the failure distribution, planned dataset, baseline, expected improvement, and possible regression. For example: improve valid tool-call format while monitoring argument correctness and inappropriate answering.

Choose metrics on independent examples and define the release gate before seeing the result. Training loss is a diagnostic, not the final application criterion.

Next week we reduce trainable parameter state with LoRA. That optimization still depends on the dataset and objective you design now.

### Worked practice and a readiness check

Create correct-format, wrong-format, insufficient-evidence, and wrong-version examples. Inspect their serialized tokens and loss masks.

Propose a grouped split and audit ten records. Identify one failure that SFT is unlikely to repair because the relevant evidence is absent.

You are ready when “fine-tune the model” means a specific dataset, objective, trainable configuration, baseline comparison, and evaluation plan.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

When an assistant fails, changing model weights is only one possible intervention. Missing source material suggests ingestion. Missing relevant passages suggests retrieval. An answer that ignores available evidence suggests context, prompting or model capability. Consistently wrong output format may be a candidate for supervised fine-tuning. Diagnose the failed boundary before paying a training cost.

Prompting changes instructions and demonstrations at inference time. RAG changes the information supplied. Supervised fine-tuning changes parameters to imitate desired outputs. Continued pretraining changes parameters through a language-model objective on new text. Preference optimization changes relative preferences among possible responses. These methods can coexist, but they solve different immediate problems and have different update costs.

### Review A: SFT dataset design

An SFT example contains inputs and a target response. For our assistant, teach a narrow behavior such as selecting a valid tool or producing an evidence-referencing JSON answer. Include answerable tasks, insufficiency cases, version-specific evidence and tool failures. If every example is answerable, the model may learn that producing an answer is always rewarded.

The target must be correct under the supplied context. A synthetic generator can create plausible but wrong examples; manually audit a sample and use executable or source checks where possible. Save provenance and generation settings. Split by task family or documentation group before making paraphrases. Otherwise stylistic near-duplicates can leak into evaluation.

### Review A: Worked intervention decision

Imagine 50 development failures: 25 have missing evidence, 10 contain the right evidence but invalid JSON, 10 require an unavailable calculation tool, and 5 are genuinely ambiguous. Training on all 50 would mix four causes. Fix ingestion/retrieval first, add a typed calculation interface, and clarify ambiguous tasks. Fine-tune format adherence only if prompt/schema constraints still leave a measured gap.

For an answer-only loss, mask prompt tokens with an ignored label and supervise answer tokens. Keep the evidence in the input. Do not train on the final held-out labels or use the hidden test set to choose the number of epochs. Record truncation rates; an example whose target is cut away provides no intended supervision.

### Review A: Experiment

notebook 24 builds training records, checks source IDs and splits grouped tasks. Its tiny synthetic examples teach the data pipeline, not a useful production behavior. Build a larger, reviewed development dataset for your real project. Before training, write a prediction: which metric should improve and which might regress? Keep the frozen RAG baseline for comparison.

**Exit criterion:** justify SFT with an error taxonomy and construct a leakage-aware dataset. **Reading:** R01 post-training topic; R14 configuration overview. **Tutorial:** 24.
