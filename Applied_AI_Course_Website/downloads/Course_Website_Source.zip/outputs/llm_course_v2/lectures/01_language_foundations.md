# Semester 1 Language models from ordinary sentences

## Week 1 What a language model is trying to learn

### Unseen continuations and smoothing

Exact counting assigns zero probability to a vocabulary item with no observations. If a prefix has no matching examples at all, the empirical conditional distribution is undefined, rather than every next word having probability zero. One simple fallback is add-alpha smoothing: p(w|prefix)=(count(w)+alpha)/(total+alpha*V), for a fixed vocabulary of size V and alpha>0. With no matches and three allowed words, alpha=1 gives 1/3 each. This shares probability mass, but it does not learn that school and work are related.

### An ordinary sentence with one missing word

Start with “I go to school by ___.” Before thinking about a neural network, write three possible completions. Bus, train, and bicycle are all reasonable. Banana is grammatically possible after “by” in some strange invented story, but it is an unlikely completion of this ordinary sentence. The task is to assign different probabilities to possible next pieces of text using the words already available.

Now shorten the prompt to “I go to ___.” School is possible, but work, sleep, and the park become plausible too. The plausible next word changed because the available context changed. Context means the text on which a prediction depends. During the first part of this course, context is simply a prefix of an ordinary sentence.

The model does not need to know your actual commute to assign a high probability to bus. It might have learned that people often describe travel to school this way. This distinction matters. A likely continuation can sound sensible while being false about a particular person. Prediction is the starting task; truthful question answering requires additional decisions we will study much later.

### A tiny collection that we can inspect

Imagine five training sentences: “I go to school by bus” appears three times, “I go to school by train” appears once, and “I go to school by bicycle” appears once. Among examples with exactly the prefix “I go to school by,” the observed next-word proportions are 3/5, 1/5, and 1/5. Our first language model can therefore predict bus with probability 0.6, train with 0.2, and bicycle with 0.2.

These numbers describe our tiny collection, not transportation in the real world. Change the collection and the estimates change. If the collection contains no sentence about boats, a count-based model has no direct evidence about boat for this prefix. A later neural model can share information across related contexts, but it still learns from the examples and objective we give it.

We have already identified the essential ingredients of a learning problem: examples, an input, possible outputs, predictions, and a way to judge them. We will add numerical representations and trainable functions gradually rather than introducing a complete transformer all at once.

### A prediction becomes a sequence

Suppose the model selects bus. The available text is now “I go to school by bus.” To continue, it makes another next-token prediction using this longer prefix. It might choose a period. If an end marker follows, generation stops. Generating a paragraph repeats this operation many times.

This is autoregressive generation: each new prediction depends on earlier elements of the sequence. The model need not choose the whole paragraph in one decision. During generation, a mistake becomes part of the prefix for later predictions, which helps explain why a continuation can drift. Choosing an unlikely word once changes the situation the model sees next.

For now, imagine tokens are words. Week 2 will replace that simplifying assumption with a precise description of token IDs, punctuation, and subwords. A useful first explanation can make a simplifying assumption, provided we state it and later remove it.

### Conditional probability in familiar notation

Write p(bus | I go to school by). The vertical bar reads “given.” It asks for the probability of bus given that prefix. The probabilities across all allowed next tokens add to one. A language model is a function that produces such a distribution for each prefix.

The probability of a whole sequence can be written as a product of conditional probabilities. For a short example, p(I, go, home) equals p(I) multiplied by p(go | I) multiplied by p(home | I go). This chain-rule decomposition is a probability identity. A particular language model supplies estimates of those terms.

If those three probabilities are 0.5, 0.4, and 0.25, the sequence probability is 0.05. A longer sequence accumulates more factors, so raw probabilities of sentences with different lengths require care when comparing them. Later we will average negative log probabilities over prediction positions.

### Training and using a model are different activities

During training, we use examples to adjust a model. During inference, we use the resulting model to make predictions. Our count-based model “trains” by counting. A neural language model trains by changing numerical parameters so that appropriate next tokens receive higher probability on the training examples.

The sentence “I go to school by bus” can provide several training situations. “I” predicts go. “I go” predicts to. “I go to” predicts school. We do not need a person to label each of these separately because the next token already appears in the text. This is the basic self-supervised signal behind next-token training.

Do not confuse a training example with a command to the model. A sentence is data from which we derive prediction tasks. Instruction following will enter the course after we understand how the underlying prediction model works.

### A small model can be useful for understanding

Our five-sentence collection cannot support a general assistant. Its value is that every probability can be explained. If a later program gives bus probability 0.2 instead of 0.6, we can inspect counts and find the mistake.

A larger model introduces learned vectors and nonlinear functions, but the questions remain recognizable: What input did it receive? Which output did we expect? What probability did it assign? What changed during learning? Keep returning to these questions when the equations become more complex.

The first semester will develop a transformer as a solution to representing and combining context. We will postpone vector databases, RAG, agent frameworks, and deployment until the model itself is familiar.

### Worked practice and a readiness check

Add “I go to school by train” twice more. There are now seven matching examples: bus three, train three, bicycle one. The probabilities become 3/7, 3/7, and 1/7. Bus and train tie under the count model. A tie does not mean the task is broken; the observed data simply do not distinguish them.

Explain why “I go to work by” might require a different distribution. Then explain what information a simple exact-prefix count model cannot share between school and work. That limitation will motivate learned representations.

Before continuing, you should be able to distinguish an example, a prefix, a next-token distribution, a generated token, training, and inference. You should also be able to say why a probable sentence need not be a true statement about the user. The tutorial builds this tiny count model without a neural-network library.

## Week 2 From text to tokens and numerical IDs

### Why the model needs a representation

We can read “I go to school by bus,” but a numerical model needs a reproducible way to represent it. Start with the toy rule “split at spaces.” The sentence becomes six tokens: I, go, to, school, by, bus. A vocabulary lists the token types the model knows.

Assign IDs: I=0, go=1, to=2, school=3, by=4, bus=5. The sentence becomes [0,1,2,3,4,5]. An ID is a label. School does not become more meaningful because its ID is larger than the ID for go. If we consistently permuted the IDs and corresponding model tables, the labels themselves would not change the task.

Keep three objects separate: the original text, the token sequence, and the ID sequence. A tokenizer determines the conversion. A vocabulary determines which IDs correspond to which token strings. The model consumes those IDs through a representation layer.

### Punctuation reveals a weakness in word splitting

Compare “bus” and “bus.” A naive space splitter treats them as different strings. What about “school-bus,” “school bus,” or a misspelling? Treating every possible word form as a separate vocabulary item creates many rare entries and difficulty with unseen words.

A character tokenizer instead represents b, u, s, and punctuation separately. It has a smaller basic inventory but creates longer sequences. A subword tokenizer uses reusable pieces between whole words and characters. Common words may be single tokens while less common words break into several pieces.

There is no rule that one token equals one word. Once we use a real model, we must inspect its actual tokenizer. Word splitting remains useful as a teaching device because we can follow every ID by hand.

### A vocabulary is learned or chosen before use

Suppose the vocabulary includes school and schools as whole tokens but not schoolyard. A word-level system needs an unknown-token policy. A subword system might encode schoolyard using school and yard, or other pieces depending on the learned vocabulary.

Tokenization must stay compatible with the trained model. If ID 5 meant bus during training and means train during inference, the model receives the wrong representation even though both inputs are valid integers. A model checkpoint and its tokenizer therefore belong together.

Special tokens may mark the beginning or end of a sequence, padding, or conversation boundaries. Their exact meanings depend on the model. We will introduce conversation templates later rather than assuming that a visible word such as “assistant” automatically acts as a special role marker.

### Byte pair encoding with a tiny example

Use the invented training corpus bus four times, busy twice, and plus once. Split each word into characters and a visible end marker _. We count adjacent pairs with the word frequencies included: u,s occurs 7 times, b,u occurs 6 times, and s,_ occurs 5 times. The other pairs occur less often. Therefore u,s is the unique most frequent pair and becomes us.

| Word and frequency | Before the first merge | After u,s becomes us |
|---|---|---|
| bus × 4 | b u s _ | b us _ |
| busy × 2 | b u s y _ | b us y _ |
| plus × 1 | p l u s _ | p l us _ |

Count again after the merge. The pair b,us occurs 6 times, while us,_ occurs 5 times. The next merge is b,us into bus. BPE repeatedly merges the most frequent adjacent pair in the current representation; it does not choose the longest word or permanently keep the original pair counts. Ties in other corpora require a deterministic rule.

Save the learned vocabulary and merge order. Encoding a new sentence uses those saved rules; fitting a fresh tokenizer for every sentence would change the meaning of the model input IDs. The end marker in this hand calculation is a teaching convention, not a claim about a particular pretrained tokenizer.

### Bytes, subword algorithms, and SentencePiece

Byte-level BPE starts from byte symbols rather than a separate initial symbol for every Unicode character. The English word bus is the UTF-8 bytes [98,117,115]. A Chinese character can occupy several UTF-8 bytes; learned merges may combine those bytes into larger tokens. A complete byte alphabet can represent any UTF-8 input, although normalization and decoding settings still determine the final text round trip. Byte count and model token count are different measurements.

BPE learns frequent pair merges. WordPiece is another subword family: its vocabulary-training criterion differs from simple BPE frequency counting, and common implementations encode words by matching vocabulary pieces. Unigram begins with candidate pieces and learns a probabilistic segmentation model while pruning the vocabulary. SentencePiece is a tokenizer toolkit and text-processing approach that can train BPE or Unigram models directly from raw text; it is not a fourth mutually exclusive merge algorithm.

Whitespace and digits are part of the input. The strings bus and “ bus” can follow different tokenization paths, and 2026 may split into one or several pieces depending on the tokenizer. Visible markers such as a leading-space symbol are tokenizer conventions. Inspect token IDs and decoded pieces rather than removing spaces or assuming that every number is a single token.

### English and Traditional Chinese use different token budgets

For a Hong Kong application, compare “I go to school by bus.” with a meaning-matched Traditional Chinese sentence such as “我搭巴士返學。” using the exact tokenizer of the chosen model. Record text, UTF-8 byte count, token IDs, number of tokens, and the tokenizer revision. Repeat with a code identifier, a date, and English mixed with Chinese. This separates language coverage from sentence length and formatting.

Tokenizers allocate vocabulary capacity differently, so there is no fixed English-to-Chinese token ratio. Some English-heavy vocabularies encode Chinese less compactly; a multilingual vocabulary may behave differently. More tokens use more context space and can increase model work and token-priced service cost. Translate first, measure with the deployed tokenizer, and budget input and output tokens separately.

### IDs become vectors through a lookup table

An embedding table contains one learned vector per vocabulary entry. If the table has six rows and each vector has three coordinates, its shape is [6,3]. Looking up bus, ID 5, selects row 5.

For illustration, assign bus the vector [0.2,0.8,0.1] and school [0.9,0.1,0.4]. These coordinates are invented numbers for tracing the computation. They are not a statement that the first coordinate literally means education or the second means transport.

The six-token sentence now becomes a matrix with six rows and three columns. Each row corresponds to one position in the sequence. Week 3 will examine vector geometry; attention will later combine information across these rows.

### One hot encoding and lookup mean the same selection

A one-hot vector for ID 5 has six coordinates, all zero except a one at index 5. Multiplying that row vector by the [6,3] embedding table selects the same row as a lookup. This equivalence explains the operation mathematically.

An implementation normally performs an efficient indexing operation instead of materializing a huge one-hot matrix. The distinction is between a mathematical description and an efficient implementation of the same selection.

At this point, the vector for bus does not depend on its sentence. The lookup produces the same starting row wherever bus appears. Contextual processing will change the representation using surrounding tokens.

### Length and decoding

If a word tokenizer produces six tokens but a character tokenizer produces twenty-one, a model processes sequences of different lengths for the same text. Length influences how much computation and memory later stages need.

Decoding converts IDs back to text under the tokenizer's rules. Whitespace and special tokens deserve attention; joining token strings with spaces is not a universal decoding algorithm. Keep the original string when checking round-trip behavior.

Our tutorial compares a simple word tokenizer with UTF-8 bytes. Byte count is useful to inspect encoding, but it is not a substitute for the token count of a pretrained model.

### Worked practice and a readiness check

Write a vocabulary for “I go to school by bus” and “You go to work by train.” Decide how you will represent a period and an end marker. Encode both sentences and decode them again. Then encode “I go to school by bicycle” when bicycle is absent.

State your policy for the unknown token, and explain why another tokenizer could avoid that particular unknown by using smaller pieces. Given a vocabulary of 100 entries and vector width 16, calculate 1600 embedding parameters. Given a sentence of seven tokens, write its representation shape as [7,16].

You are ready when you can explain why IDs are labels, why the tokenizer must match the model, and how an ID selects a vector. The lookup itself is an indexing operation on the embedding table.

## Week 3 What word vectors can represent

### Two words can be different labels but related inputs

Our count model treated “I go to school by” and “I go to work by” as unrelated exact strings. A neural model can reuse numerical features across examples. If school and work occur in some similar travel contexts, their learned representations may share useful properties for predicting transportation words.

This does not mean the two words have identical meaning. A representation is useful for a task when its coordinates help the model reduce that task's error. What the model learns depends on the data and objective.

Start with an ordinary two-dimensional vector so we can draw it. A vector has a direction and a length. Those two properties affect common similarity calculations differently.

### A dot product is a weighted comparison

For query q=[1,0] and candidate a=[0.8,0.6], the dot product is 1×0.8+0×0.6=0.8. For b=[3,4], the dot product is 3. Raw dot product therefore ranks b above a. We will keep these same three vectors in the next calculation.

A dot product combines direction and magnitude. In attention, learned query and key projections produce the vectors being compared. In retrieval, the scoring rule must match the embedding model and its training objective. The arithmetic alone does not define semantic relevance.

### Cosine compares direction

The norms are ||q||=1, ||a||=sqrt(0.8²+0.6²)=1, and ||b||=sqrt(3²+4²)=5. Cosine similarity divides the dot product by both norms. Thus cosine(q,a)=0.8 and cosine(q,b)=3/5=0.6. Cosine ranks a first, while raw dot product ranks b first: a real ranking reversal, not just a tie.

| Candidate | Norm | dot(q,candidate) | cosine(q,candidate) |
|---|---|---|---|
| a=[0.8,0.6] | 1 | 0.8 | 0.8 |
| b=[3,4] | 5 | 3 | 0.6 |

Normalize each nonzero candidate to unit length: a stays [0.8,0.6], while b becomes [0.6,0.8]. Dot products with unit q now equal the cosine values. A zero vector has no defined cosine because its norm is zero.

Choose the operation that fits the model. Normalizing removes magnitude information, which can help one task and discard useful information for another. We will measure retrieval relevance in week 17 instead of declaring one score always better.

### An embedding table learns through prediction errors

Suppose a simple model sees the token school and predicts the next token. It selects the school row, transforms it, and produces scores over vocabulary entries. If the correct next token is by and the model gives it too little probability, training changes parameters through gradients.

The embedding coordinates are among the parameters that can change. Repeated contexts create pressure for useful shared structure. We are not manually assigning school an “education coordinate.”

Different random seeds can produce different coordinate values that support similar predictions. Rotating a representation space together with compatible downstream transformations can preserve relevant behavior. This is one reason to avoid interpreting individual coordinates as fixed human concepts.

### Starting vectors and contextual vectors

The starting vector for bus comes from its vocabulary row. In “I go to school by bus” and “The bus broke down,” that lookup row can be the same. After context processing, the representation at bus can differ between the sentences.

The context tells us whether we are discussing a travel choice or a breakdown. A contextual vector represents a token at a position under available context. Later, the causal mask will determine which other positions are available.

Keep token embeddings, contextual token representations, and whole-sentence embeddings distinct. A vector chosen from a lookup table is not automatically a good summary of an entire paragraph.

### One word, several senses, and uneven geometry

Polysemy means one word has several senses. Compare “I waited by the bank of the river” with “I deposited cash at the bank.” A static lookup can begin with the same bank vector in both sentences, while contextual layers produce different representations from the surrounding words. The context available to a causal model matters: it cannot use words it has not yet received.

Anisotropy describes an embedding space whose vectors occupy some directions more strongly than others. Many contextual embeddings share common directional components, so even unrelated words can have a high cosine. The observed geometry depends on model, layer, pooling, and training. A cosine such as 0.8 is therefore a comparison score, not an 80% semantic-match probability.

The familiar king − man + woman analogy can illustrate a pattern in some learned spaces, but it is not a reliable algebra of meaning. Results change with vocabulary, context, scoring, and the chosen examples; social associations in the data can also introduce stereotypes. Inspect several counterexamples and evaluate the actual task instead of treating one successful analogy as proof that vector coordinates encode universal human concepts.

### A simple sentence representation and its limitations

One easy way to represent a sentence is to average its token vectors. This combines information but loses much of the ordering. “The dog chased the boy” and “The boy chased the dog” contain the same word inventory under a simple tokenizer, so an order-insensitive average can be identical.

That limitation motivates context and position processing. Averaging can still be a useful baseline, but knowing its failure mode prevents us from mistaking convenience for a complete language model.

In week 17, we will return to sentence embeddings trained for search. That application requires an objective and evaluation of its own. For now, the goal is understanding how numerical representations can share information.

### A small numerical experiment

Move q to [0,1]. Its dot products with a=[0.8,0.6] and b=[3,4] become 0.6 and 4; their cosines are 0.6 and 0.8. Both methods now prefer b. A scoring rule and the query direction together determine the ranking.

For q=[−1,0], dot products are −0.8 and −3, while cosines are −0.8 and −0.6. Negative values are valid scores. Compute each ranking explicitly and use the geometry illustration to compare direction and magnitude.

### Worked practice and a readiness check

Calculate the norm of [3,4], normalize it, and compute its cosine with [1,0]. The answers are 5, [0.6,0.8], and 0.6. Then compare [6,8] and explain what changes and what remains the same.

Explain why changing the embedding table without adjusting the rest of a trained model can change behavior. Explain why two separately trained 384-dimensional models do not necessarily use compatible coordinates.

You should now be able to follow an embedding lookup, a dot product, normalization, and the difference between an initial and contextual representation. These are the numerical building blocks we need before attention.

### A second representation example

Suppose a toy vocabulary has school=[1,0], work=[0.8,0.2], and bus=[0,1]. A mean representation for “school bus” is [0.5,0.5], while “work bus” gives [0.4,0.6]. Their similarity partly reflects a shared bus component. These coordinates are deliberately chosen; an actual model would need training and evaluation.

Now reverse “school bus” to “bus school.” The mean stays the same because addition is commutative. This gives an exact counterexample to the claim that averaging always preserves language meaning. We do not need a large benchmark to establish this particular invariance.

The next question is constructive: how could the model distinguish the orders? Position information can change the starting rows, and contextual processing can combine them differently. This connects the limitation of a simple vector average directly to the architecture we are building.

## Week 4 From scores to probabilities and learning signals

### A score is not yet a probability

For the prefix “I go to school by,” imagine a model produces scores bus=2, train=1, bicycle=0. Scores can be any real numbers. They do not add to one, and they may be negative. A model needs a transformation if we want a next-token probability distribution.

Softmax converts a list of scores into positive numbers that sum to one. It exponentiates each score and divides by the sum of all exponentials. Bigger scores receive more probability, but the size of a score matters relative to the other candidates.

The term logit refers to the unnormalized model score in this setting. Do not interpret a logit of 2 as 200% or a probability of 0.2.

### Softmax by hand

For [2,1,0], the exponentials are approximately [7.389,2.718,1]. Their sum is 11.107. The resulting probabilities are approximately [0.665,0.245,0.090].

Add 100 to every score. The probabilities remain the same because the common multiplicative factor cancels between numerator and denominator. An implementation subtracts the largest score before exponentiating to improve numerical stability.

For [1000,999], subtracting 1000 gives [0,-1]. The probabilities are approximately [0.731,0.269]. We can compute them without taking exp(1000), which would overflow ordinary floating-point arithmetic.

### The expected token supplies a loss

Suppose the actual training sentence ends with train. Using its unrounded probability 0.244728, cross entropy is −ln(0.244728)≈1.408 nats. If training changes the model so train receives probability 0.7, the loss becomes −ln(0.7)≈0.357 nats.

The loss rewards assigning probability to the observed target. It does not say that every other transportation choice is impossible. Across many examples, the model balances different targets and contexts under its capacity and training procedure.

An overconfident wrong prediction can be expensive: target probability 0.01 gives loss about 4.605. This explains why accuracy alone does not describe the entire training objective. Two models may select the same most likely token while assigning quite different target probabilities.

### Cross entropy, likelihood, and units

For observed targets y1,…,yN, maximum likelihood chooses parameters that make the product of their conditional probabilities large. Taking a natural logarithm turns that product into a sum. Minimizing the mean negative log likelihood is therefore the same optimization as maximizing likelihood. With a one-hot target at each position, this negative log likelihood is the cross-entropy loss used above.

For a target distribution p and prediction q, cross entropy is H(p,q)=−Σ p_i ln(q_i). It equals H(p)+KL(p||q). H(p) is fixed by the target distribution, so reducing cross entropy reduces the KL divergence from target to prediction. In the single one-hot example, H(p)=0 and the loss is simply −ln(q_target).

Natural logarithms measure loss in nats. Base-2 logarithms measure it in bits: loss_bits=loss_nats/ln(2). A uniform choice among four tokens gives −ln(1/4)=ln4≈1.386 nats, or exactly 2 bits. Keep the log base fixed when comparing reported losses.

### Compute log probabilities without numerical overflow

Use log_softmax directly rather than taking log(softmax(logits)) as two separate numerical steps. For logits z, logsumexp(z)=m+ln Σ exp(z_i−m), where m is the largest logit. Then log_softmax(z)_i=z_i−logsumexp(z). This keeps large exponentials out of the calculation.

For [1000,999], logsumexp is approximately 1000.3133 and log probabilities are [−0.3133,−1.3133]. If the second token is correct, its loss is 1.3133 nats. PyTorch CrossEntropyLoss and functional.cross_entropy accept raw logits and class IDs; they already combine log_softmax with the negative log-likelihood calculation. Do not apply softmax first.

### Where the scores come from

Let h be a contextual vector with d_model coordinates. A vocabulary output layer can compute z=hW+b, where W has shape [d_model,V] and V is vocabulary size. Each output coordinate is a score for one vocabulary entry.

If h has shape [1,4] and the vocabulary has ten entries, W has shape [4,10] and z has shape [1,10]. Softmax runs across those ten candidate scores. The hidden width and vocabulary size describe different axes.

We have not yet built the contextual vector h. The next several weeks will explain how a transformer constructs it from token and position information.

### Gradients connect prediction to parameters

For softmax followed by cross entropy, the derivative with respect to a logit is predicted probability minus the target's one-hot indicator. If train is the target, the derivative vector for [0.665,0.245,0.090] is approximately [0.665,-0.755,0.090].

Gradient descent subtracts a scaled gradient. At the logit level, this points toward reducing the competing scores and increasing the target score. In a real network, the chain rule propagates the signal through the output layer and earlier representations.

This is a learning signal, not a hand-written language rule such as “after by always choose bus.” The same parameters participate in many prediction tasks, so learning aggregates evidence across them.

### Temperature changes a distribution

Sampling sometimes uses softmax(z/temperature). With logits [2,0], temperature 1 gives about [0.881,0.119]. Temperature 2 gives about [0.731,0.269]. A larger temperature flattens this example's distribution.

Temperature is an inference choice here. It does not rewrite the training collection or verify a fact. Greedy decoding selects the largest logit directly; it should not be implemented by dividing by temperature zero.

We will study decoding more fully after building the transformer. For now, recognize that the same scores can lead to different sampling behavior under a different transformation.

### Loss across several prediction positions

A sentence supplies a target at each valid next-token position. If three target probabilities are 0.5,0.25,0.25, the average negative log probability is (ln2+ln4+ln4)/3, approximately 1.155. Perplexity is exp(average loss), about 3.175.

Perplexity is exp(mean loss in nats), or 2^(mean loss in bits). A uniform four-token distribution has perplexity 4, so we can interpret it as an effective branching factor per prediction. For uneven predictions it is the geometric mean of inverse target probabilities, not a literal count of equally likely choices. Compare perplexity only under the same tokenization and evaluation protocol.

Padding positions should not become ordinary prediction targets. We will distinguish information masks and loss masks when we train a complete sequence model.

### Worked practice and a readiness check

Compute softmax([0,0,0]). Each candidate has probability 1/3. If the correct token is bus, its cross entropy is ln3, about 1.099. Explain why subtracting a common constant from all three scores leaves the answer unchanged.

Then predict what happens if the bus score increases while the others stay fixed. Calculate the new distribution rather than stating only that bus “becomes more likely.”

You should be able to identify the score vector, the vocabulary axis, the target ID, the probability distribution, and the loss. The attention mechanism will reuse softmax for a different purpose: choosing mixture weights across available positions.

### A second loss example with two students

Imagine two models both choose bus as their most probable token, while the true target is train. Model A assigns train probability 0.4, and model B assigns it 0.01. Both have zero top-one accuracy on this example, but their losses are about 0.916 and 4.605. The objective distinguishes uncertainty from an extremely confident mistake.

Now suppose the next example's target is bus. A complete comparison should include both examples rather than selecting only the one favoring a model. Average losses over the declared valid prediction positions.

This is why we keep the distribution and target visible when learning. A final selected word discards information that the optimizer uses. Later evaluation will also need more than one flattering example, although application metrics can differ from next-token loss.

## Week 5 Why language needs context and order

### Why recurrent gradients can fade

The update h_t=0.5*h_(t-1)+x_t multiplies the influence of an earlier state by 0.5 at each step. Its derivative across k steps is 0.5^k: at ten steps it is about 0.00098. This is a simple example of vanishing gradients, which can make distant dependencies hard to learn. Other repeated transformations can produce exploding gradients. LSTM (long short-term memory) and GRU (gated recurrent unit) use learned gates to control state updates and help preserve useful signals; they do not make every long dependency easy.

### The same word can appear in different situations

Read “I go to school by bus” and “The bus is late because it broke down.” The pronoun it needs context to identify its referent, the bus. This example illustrates contextual interpretation of it. A model that processes each token independently cannot use the sentence to resolve that relationship.

The word order also matters. “The boy follows the bus” and “The bus follows the boy” contain the same words but describe different events. A representation based only on which words are present loses this distinction.

We now need a mechanism that transforms starting token vectors into representations that depend on other positions. This is the problem attention will address. First, examine simpler ways of supplying context.

### A fixed window sees only part of the sentence

A window model might predict the next token from the last two tokens. For “I go to school by,” it sees only school by. This can be useful, but information earlier in the sentence disappears when it falls outside the chosen window.

Increasing the window adds context but also changes the input size and parameters of some simple architectures. A sentence with a dependency farther away can still exceed the window.

This is not a proof that every fixed-window model performs poorly. It identifies a structural choice and its limitation. We want to understand what information an architecture makes available before debating benchmark results.

### A recurrent model carries a state

A recurrent neural network processes one token at a time. A simplified recurrence is h_t=f(Wx_t+Uh_(t-1)+b). The new state combines the current token vector with the previous state.

Imagine reading I, then go, then to. The state after to can carry some information about all three words. The sequence has a natural processing order because the next state depends on the preceding one.

That state has finite width and must carry useful information through repeated updates. Learning long dependencies can be difficult, and training involves sequential dependencies across time. Gated recurrent architectures address some problems but do not remove every tradeoff. We introduce them to understand the problem, not to claim that recurrence is incapable of language modeling.

### A simple state update illustrates information loss

Take a scalar recurrence h_t=0.5h_(t-1)+x_t, starting at zero. If the input values are [1,0,0,0], the states are [1,0.5,0.25,0.125]. The effect of the first input decays.

This is a designed arithmetic example, not a claim that a trained RNN always uses a decay of 0.5. It shows how repeated transformations can change the influence of earlier information.

If the task needs the first word exactly after many steps, a compressed state must preserve that useful detail. Attention will offer another access pattern: compare the current representation directly with representations at available positions.

### Reading a source and producing a target

Translation gives a concrete context problem. “I go to school by bus” can be an input sequence, while a translated sentence is a different output sequence. An encoder reads the source and constructs representations. A decoder produces the target under a generation rule.

A single fixed vector could summarize the whole source, but important details may be hard to preserve as sentences grow. An attention mechanism can let each target position consult different source positions.

This source-target example motivates cross-attention. Self-attention, which we study first, compares positions within the same sequence. The distinction concerns where the vectors come from, not whether the method is “thinking about itself.”

### What the current position is allowed to see

For next-token generation, the prediction from “I go to school by” must not use the answer bus before it has generated it. If a training computation accidentally reads future tokens, it solves an easier problem than the inference task.

For a sentence encoder used to represent a fully observed input, reading words on both sides of a position can be appropriate. The task defines the allowed information. There is no universal rule that every language model must use the same mask.

We will separate architecture from visibility. A causal decoder uses a left-to-right visibility pattern; an encoder commonly uses a bidirectional pattern over valid input positions.

### The bridge to attention

Suppose you are filling the final word in a sentence. You might consult different earlier clues rather than relying on one compressed note. Attention turns that idea into a learned numerical mixture of value vectors.

The first explanation in week 6 will use visible weights that we choose by hand. Week 7 will show how learned projections produce the scores. Week 8 will add scaling and causal masks carefully.

This ordering lets us inspect the mixture before introducing every matrix in the final formula. A beginner should be able to calculate the output of a tiny attention example before memorizing its compact equation.

### Worked practice and a readiness check

For the recurrence h_t=0.5h_(t-1)+x_t, compute the states for [0,0,0,1]. Compare the final state with the previous example. Order changes the result because earlier inputs undergo more transformations.

Write an example where a two-token window loses useful context. Then identify whether a translation decoder is consulting the source sequence or its generated target prefix in each of two proposed attention operations.

You are ready when context, order, recurrence, encoder, decoder, self-attention, and cross-attention are recognizable ideas. You do not yet need to implement a translation system or use an orchestration framework.

### Context access as a diagram you can test

Write “I go to school by bus” as six boxes. For the representation at school, draw connections to the information permitted by each model. A two-token window, a recurrent state, and full valid-input attention offer different paths.

For an autoregressive prediction from school, cross out by and bus because they are future input positions. For an encoder of the complete sentence, those words may remain available. The same sentence can therefore support different legitimate computations under different tasks.

Avoid explaining the difference only by saying that one model “reads better.” The diagram identifies actual dependencies. A property test can then change an unavailable token and check that it has no effect where access is forbidden. This turns a verbal rule into a measurable implementation condition.

## Week 6 Attention begins as a weighted mixture

### A few notes can contribute by different amounts

Imagine three notes about a trip: where you are going, how you travel, and the weather. A question about transport should combine those notes differently from a question about rain. Attention supplies weights that determine how much each available value contributes.

For the sentence “I go to school by bus,” the representation at one position can incorporate information from earlier words. We should not assume that a particular word must receive a particular attention weight in every trained model. Our first example uses invented values so the arithmetic is visible.

The operation is a mixture of vectors. It does not necessarily select one word, return a database row, or output an explanation.

### A weighted average in one dimension

Start with values [2,8,5] and weights [0.5,0.3,0.2]. The result is 0.5×2+0.3×8+0.2×5=4.4. Because the weights are nonnegative and sum to one, the result lies between the smallest and largest values.

If the weights become [1,0,0], the result is 2. If they become [0,1,0], it is 8. A soft mixture allows several inputs to contribute rather than making a hard selection.

These scalar values have no physical unit in our example. Do not read 8 as a literal “bus meaning score.” We use arbitrary features to understand the numerical operation.

### The same operation works on vectors

Let the value vectors be v1=[2,0], v2=[0,4], and v3=[2,2]. Use weights [0.5,0.3,0.2]. The first output coordinate is 0.5×2+0.3×0+0.2×2=1.4. The second is 0.5×0+0.3×4+0.2×2=1.6.

The output is [1.4,1.6]. The same weight applies to all coordinates of a given value vector. We do not independently choose a different source for each coordinate in this basic attention operation.

With weights arranged as a row [1,3] and values as a matrix [3,2], their matrix product has shape [1,2]. The matrix notation describes the same arithmetic we just performed coordinate by coordinate.

### One query has one distribution over keys

The weights depend on a query and a set of keys. Think of the query as the representation asking what information is useful, and each key as the representation used to compare an available position with that query.

A score tells us how strongly the query matches a key under a chosen operation. Softmax turns the scores across keys into mixture weights. This is the softmax from week 4, but the axis has changed: there we normalized vocabulary candidates; here we normalize source positions.

That distinction prevents a common confusion. Attention probabilities over positions are not the model's final probabilities over next words. The transformer performs more computation before producing vocabulary logits.

### From scores to the mixture

Suppose three scores are [ln5,ln3,ln2]. Exponentiating gives [5,3,2], so softmax gives [0.5,0.3,0.2]. Multiplying those weights by the value matrix produces the [1.4,1.6] output.

We have separated two stages: computing weights and using them to combine values. A future projection can change both the comparison features and the information being mixed.

Attention can be differentiable through the scores and values. A training loss can therefore teach parameters which mixtures improve the prediction task. We will introduce the learned Q, K, and V projections next week.

### Several query positions produce a matrix

If a sentence has six tokens and each is a query, we get six rows of weights. Each row sums to one across its visible keys. With six value vectors of width d_value, the full output has shape [6,d_value].

Row i answers “How does query position i combine available values?” Column j tracks how value position j contributes to different query outputs. Swapping row and column interpretations changes the meaning of the operation.

At this stage, assume every source position is available. Week 8 will impose a causal mask so a next-token model cannot use future positions.

### A small attention heatmap you can read

Here is a complete invented weight matrix for the three tokens go, school, and bus. Each row is one query and each column is a key/value position. Darker cells in the illustration mean larger weights; the numbers are the exact accessible version of the same picture. All three positions are available in this example, before introducing causal masking in week 8.

| Query / key | go | school | bus |
|---|---|---|---|
| go | 0.5 | 0.3 | 0.2 |
| school | 0.1 | 0.8 | 0.1 |
| bus | 0.2 | 0.2 | 0.6 |

The school row has a bright 0.8 cell but still assigns 0.1 to each other position. With value vectors go=[2,0], school=[0,4], and bus=[2,2], that row produces 0.1[2,0]+0.8[0,4]+0.1[2,2]=[0.4,3.4]. The smaller cells contribute [0.4,0.2] in total; they are not absent.

Two uses of the word weight must stay separate. Projection matrices such as Wq and Wk are learned parameters saved in the model. The attention weights in this picture are computed from the current input and can change from sentence to sentence. A bright cell shows how this row mixes its values; it does not label a permanent connection strength or explain the whole final answer.

### Why the mixture is useful but not a complete model

An average alone cannot represent every relationship we want. Learned projections, multiple heads, position information, nonlinear layers, and residual paths will expand the computation.

Attention weights also do not tell the whole causal story of a final answer. Values can carry different information, and later operations can transform or override it. A visually strong attention edge is evidence about that mixture, not a complete human-readable explanation of the model.

The point of beginning with a weighted average is to give the compact attention equation a concrete interpretation before we place it inside a transformer.

### Worked practice and a readiness check

Recalculate the vector output with weights [0.2,0.5,0.3]. The first coordinate becomes 1.0 and the second becomes 2.6. Check that each output lies within the corresponding coordinate range of the inputs.

Then explain what happens if all three value vectors are identical. Changing the weights cannot change the mixture as long as they sum to one. This is a useful sanity check for a small implementation.

You should be able to read a weight row, identify its normalization axis, multiply it by a value matrix, and distinguish source-position weights from vocabulary probabilities. That is a substantial part of attention already.

### Uniform attention and a hard choice

With three vectors, equal scores produce weights [1/3,1/3,1/3]. For [2,0],[0,4],[2,2], the output is [4/3,2]. A score change can move the mixture toward one source, but softmax usually leaves several nonzero contributions.

A hard argmax would instead select one value vector. That is a different operation with different training behavior. Attention's weighted combination lets gradients express how changing several contributions might help the final loss.

Return to the heatmap above and replace the school value with [0,40]. Its weight stays 0.8, while its contribution becomes [0,32]. The picture of weights alone stays unchanged even though the output changes substantially. Read weights and values together.

## Week 7 Where queries keys and values come from

### Row and column conventions describe the same map

Attention chapters store token vectors as rows: y_row=x_row*W_row. Week 25 uses column vectors to match the common LoRA formula: y_col=W_col*x_col. They are transposes of the same calculation: x_col=x_row transpose and W_col=W_row transpose. A [d_in,d_out] row-convention matrix therefore becomes [d_out,d_in] in column convention. H_kv is reserved for the later grouped-query/cache discussion; ordinary attention here has one K/V set per query head.

### One token can have several computational roles

Last week we chose attention weights by hand. A transformer needs to compute them from representations. Take the six rows for “I go to school by bus.” Each row begins as a token representation, with position information added later in our full model.

For attention, learned linear transformations create a query vector, a key vector, and a value vector from each row. They are different views of the same starting representation, optimized for different roles in the computation.

Query, key, and value are names for roles. They do not mean a human-written question, a word's dictionary definition, and a factual answer. Keeping the names separate from literal natural-language meanings makes the mechanism easier to reason about.

### Linear projection with visible numbers

Let one input row be x=[1,2]. Let Wq be the identity matrix, Wk=[[1,0],[0,0.5]], and Wv=[[2,0],[0,1]]. Using row-vector notation, q=xWq=[1,2], k=xWk=[1,1], and v=xWv=[2,2].

The input row is the same, but the projected vectors differ. In a trained model, these projection matrices are parameters changed by the loss. We chose simple matrices only to make every multiplication easy to inspect.

Changing Wk changes how the position participates in comparisons. Changing Wv changes the information contributed after the weights have been computed. These effects can be studied separately.

### A shared notation for attention dimensions

We use d_model for the token-representation width, d_head for one query/key head width, and d_value for one value-vector width. T counts positions, B counts batch examples, and H counts heads. In ordinary equal-width multi-head attention, d_head=d_value=d_model/H; the single-head shape exercise below deliberately allows a different value width. These symbols name dimensions, not different kinds of vectors.

### Applying projections to the whole sentence

If X has shape [T,d_model], Wq has shape [d_model,d_head], and Wk has shape [d_model,d_head], then Q and K both have shape [T,d_head]. Wv can have shape [d_model,d_value], producing V with shape [T,d_value].

The same projection matrix applies at every token position. We do not train one Wq for the first word and another for the sixth word in ordinary self-attention. Sharing parameters lets the operation work over different sequences.

The number of positions T and the number of features d_model describe different things. Multiplying X by a projection changes feature coordinates; it does not by itself mix token positions.

### Comparing all query key pairs

For one query q_i, dot it with every key k_j. Arranging the results for all i and j gives QKᵀ, a [T,T] score matrix.

Suppose T=6. Entry [4,1] describes query position 4 compared with key position 1 under zero-based indexing. It is not a vocabulary score for word ID 1.

This is the first operation in this attention block that explicitly compares positions with one another. The later weight-times-value multiplication then moves information across positions.

### A complete two-position example

Let Q=[[1,0],[0,1]], K=[[1,0],[0,1]], and V=[[2,0],[0,4]]. The unscaled score matrix is the identity matrix. For the first query, scores [1,0] become softmax weights approximately [0.731,0.269].

Its output is approximately [1.462,1.076]. The second query has the opposite score pattern and output approximately [0.538,2.924].

Both outputs can include both values. The operation does not force each query to choose its matching position exclusively. In week 8, scaling by sqrt(d_head) will change these numbers, and masking may remove some contributions.

### Self attention and cross attention use different sources

In self-attention, Q, K, and V derive from representations of the same sequence. In cross-attention, queries derive from one sequence while keys and values derive from another.

For translation, target-side decoder representations can query source-side encoder representations. If the target has length U and the source has length T, the score matrix has shape [U,T], which need not be square.

The rectangular case is a useful check that you understand the axes. Attention fundamentally relates query positions to key/value positions. It does not require their counts to match.

### What training can change

Gradients can change the input embeddings and each projection matrix. If a comparison repeatedly helps predict appropriate next tokens, training can reinforce the corresponding computation.

The learned coordinates need not line up with a simple story about “the transport head” or “the school key.” Such interpretations require evidence. The small examples in these lectures explain valid computations, not the discovered internals of a pretrained model.

We can still test the implementation precisely: projection shapes, row sums after softmax, output dimensions, and sensitivity to changing a key or a value.

### Worked practice and a readiness check

For X shaped [6,4] and d_head=2,d_value=3, write projection shapes [4,2],[4,2],[4,3], then Q/K/V shapes [6,2],[6,2],[6,3]. The score matrix is [6,6], and the output is [6,3].

For cross-attention with four queries and seven key/value positions, write scores [4,7]. Explain why softmax still runs across the seven keys for each query.

Before continuing, you should be able to say which operations change feature coordinates, which compare positions, and which mix value information. Scaling and masking will now refine this computation without changing that overall structure.

### Changing a key versus changing a value

Keep Q and K fixed in the two-position example, but replace the second value [0,4] with [0,8]. The attention weights stay the same because their computation did not use V. The second coordinate of each mixed output doubles.

Now restore V and change a key instead. The dot-product scores change, so softmax can redistribute the mixture across both value vectors. This distinguishes the comparison role from the information role without requiring any interpretation of natural-language meaning.

For a third experiment, change only one query row. That changes that row's comparisons while leaving other query rows' scores unchanged before later processing. These controlled perturbations are excellent small tests. They explain which tensor participates in which stage more clearly than memorizing the letters Q, K, and V.

## Week 8 Scaling and masking attention correctly

### A prediction must use only available information

During training we have the complete sentence “I go to school by bus.” At the position after by, the model must predict bus using the prefix, even though the training tensor contains the answer farther to the right.

A causal mask prevents a query position from attending to future positions. If indexing starts at zero, query i may use keys j≤i. The diagonal remains visible because the current input token is part of the prefix used to predict the next token.

This is an information-access rule. It is separate from whether we include a position in the loss. A padding mask, causal mask, and loss mask serve different purposes.

### The compact attention equation

The standard single-head expression is softmax(QKᵀ/√d_head + mask)V. Read it as a sequence of operations: compare queries with keys, scale scores, remove forbidden positions, normalize each query row, and mix values.

For T positions, Q/K have shape [T,d_head], scores and weights have [T,T], and V has [T,d_value]. The output has [T,d_value].

Do not memorize the expression as an indivisible symbol. If an implementation is wrong, inspect each intermediate tensor. Tiny inputs reveal errors much more clearly than a large model's final loss.

### A worked scaled example

Take q=[1,0], keys [1,0] and [0,1], and values [2,0] and [0,4]. Here d_head=2, so scores are [1/√2,0], approximately [0.7071,0].

Softmax gives approximately [0.6698,0.3302]. The mixed output is [1.3395,1.3210]. Both positions contribute.

Now suppose the second key is a future position. Set its score to negative infinity before softmax. The weights become [1,0] and the output becomes [2,0]. Masking changes the normalization as well as removing the forbidden contribution.

### Why multiplying probabilities by zero is different

Suppose you compute the unmasked weights [0.6698,0.3302] and then multiply the second weight by zero. You get [0.6698,0], whose sum is not one. The output becomes [1.3395,0], which differs from the correctly masked result.

You could renormalize the surviving probabilities, but masking logits before softmax is the direct standard implementation. The important point is to understand what computation you intend.

If every key in a row is forbidden, softmax has no valid normalization. Design padding and batching so each query being evaluated has an appropriate visible key, or handle invalid rows explicitly.

### Why divide by the square root

Under a simplified assumption of independent, zero-mean, unit-variance query/key coordinates, the variance of their dot product grows with d_head. Large score magnitudes can make softmax very concentrated.

Dividing by √d_head keeps the scale more controlled under that intuition. This does not guarantee that learned scores always have a particular distribution. It explains the motivation for the scaling term.

Try vectors with many random coordinates and compare score spread before and after scaling. Inspect the statistics rather than asserting that a sharper attention map is better.

### Padding introduces another visibility condition

A batch may contain sentences of different lengths. We can pad shorter ones to a common length, but those padding positions should not behave like meaningful source words.

The allowed key positions must satisfy both the causal rule and the validity rule for the sequence. A future token is forbidden even if it is a real word. A padding token is not useful context merely because it lies to the left.

Loss masking then determines which target predictions count toward the objective. A correctly masked attention computation can still have a wrong loss if it trains on padding labels.

### An invariant catches future leakage

Fix the model parameters and disable randomness such as dropout. Run a sequence, then change only its last token. Earlier causal outputs must remain unchanged within a stated numerical tolerance.

This property checks behavior rather than the visual appearance of a triangular matrix. Removing the mask should make the same property fail on a suitable example. That failure is evidence that the test can detect the intended bug.

A lower training loss after removing the mask may indicate answer leakage. In tutorial 08, implement the attention calculation, run the invariance check, and then remove the mask to make the check fail. A [T,T] score matrix stores T² numbers per head; doubling T quadruples that storage before considering batching or multiple heads.

### Worked practice and a readiness check

Draw a six-by-six causal visibility table for our sentence. For query school at index 3, list the visible input tokens I, go, to, school. Explain why by and bus are not available to that query.

Then compute the first query's output in the two-position example with and without masking. State the normalization axis and verify each valid row's weights sum to one.

You are ready to place attention inside larger structures when you can trace Q, K, V, scaling, masking, softmax, and value mixing independently. The next week adds several heads and explicit position information.
