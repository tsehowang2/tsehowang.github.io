# Semester 1 Building and understanding a transformer

## Week 9 Multiple attention heads and position

### One view of a sentence may not be enough

In “I go to school by bus,” several relationships can matter at once. The representation may need information about the destination, the action, and the means of travel. One attention head computes one pattern of comparisons and value mixing for each query.

Multiple heads give the layer several learned projection sets. Each can form a different mixture. We should not assume that one particular head always represents “transport” and another “grammar.” Those are hypotheses to investigate in a trained model, not labels built into the architecture.

First understand multiple heads as parallel numerical computations. Their outputs are concatenated and transformed back into a representation that the next operation can use.

### One notation ledger for this course

Use B for batch size, T for the number of input positions, H for query heads, d_model for the residual-stream width, d_head for each query/key head width, and d_value for each value-head width. In our standard teaching attention, d_value=d_head and H*d_head=d_model. A later grouped-query model may have fewer key/value heads H_kv than query heads H. Vocabulary size V is separate from the value matrix V; the surrounding formula or table identifies which is meant.

### Splitting a representation into head computations

Suppose the model width is d_model=8 and there are H=2 heads of width 4. Each head forms Q, K, and V projections for the same sentence. For T=6 positions, one head's queries have shape [6,4], and its score matrix has shape [6,6].

Each head produces an output [6,4]. Concatenating two outputs gives [6,8]. An output projection of shape [8,8] transforms those concatenated features into the residual stream's width.

The heads do not divide the sentence into separate word groups. Both heads can operate over all allowed positions. The split concerns representation features and learned projections.

### A small concatenation example

For one token, imagine head 1 produces [1,2] and head 2 produces [3,4]. Concatenation gives [1,2,3,4], not [4,6]. If the output projection is the identity matrix, that vector passes through unchanged.

If instead the first output coordinate takes the sum of the first coordinate from each head, its corresponding column can combine 1 and 3. Learned output projections let later features integrate contributions from different heads.

Concatenation and summation are different operations. Draw the feature axis before reshaping tensors. A program can have plausible shapes while joining the wrong axes.

### Order is still a separate requirement

Token lookup plus unmasked self-attention, without position information, has an important symmetry: reordering the token rows reorders the corresponding outputs under the same transformation. The operation does not acquire a general notion of word order merely because we draw rows from left to right.

“The bus follows the boy” and “The boy follows the bus” need different relationships. Position information provides a way for otherwise similar token inventories to produce different representations.

A causal mask already breaks the symmetry of fully unmasked attention: different positions see different prefixes. Causal models with no explicit position encoding, often called NoPE, can learn positional information through this structure. Our teaching model uses explicit learned position embeddings, and many modern decoders use RoPE. This is an architectural choice, not a theorem that every causal decoder requires a separate position vector.

### Learned absolute position embeddings

Our teaching model uses a table of position vectors. At position t, add the token embedding and the position embedding. If both have width d_model, their sum also has width d_model.

The starting representation for bus at position 5 is therefore different from bus at position 1, even before attention. The addition gives the following layers information from both token identity and position.

A learned table has a configured range of positions. Using positions beyond that range needs an explicit strategy. A model trained on short examples is not automatically reliable on much longer ones merely because its code accepts an input.

### Sinusoidal and rotary ideas

Sinusoidal position encodings use functions with different frequencies rather than a learned vector for every position. The original transformer uses this construction. It supplies a structured numerical representation of position.

Rotary position methods rotate pairs of query/key coordinates by position-dependent angles. For a two-dimensional pair, rotation maps [x1,x2] to [x1 cosθ−x2 sinθ, x1 sinθ+x2 cosθ]. Relative positions can then influence dot-product comparisons.

Use different positions to see the important effect. Start with q=k=[1,0]. Rotate q by 30 degrees and k by 90 degrees. Their rotated vectors are approximately [0.8660,0.5000] and [0,1], so the dot product is 0.5. Shift both positions by another 30 degrees: the angles become 60 and 120 degrees, but the dot product remains 0.5. Their relative offset is still 60 degrees. If k instead rotates by 150 degrees while q stays at 30 degrees, the offset becomes 120 degrees and the dot product becomes −0.5. RoPE makes this relative displacement enter the comparison; real head vectors use several coordinate pairs and frequencies.

Source: [RoFormer: rotary position embeddings](https://arxiv.org/abs/2104.09864).

Source: [Causal language models without explicit positional encodings](https://arxiv.org/abs/2203.16634).

### Batch and head axes

When processing B sentences together, an implementation may arrange queries as [B,H,T,d_head]. For B=2,H=2,T=6,d_head=4, this is [2,2,6,4]. Attention scores then have [2,2,6,6].

Softmax runs over the final key axis. It does not normalize across sentences or heads. Each sentence, head, and query has its own distribution over visible keys.

After value mixing, transpose and reshape carefully to return [B,T,d_model]. This is a good place for tests that use distinct values for each axis so accidental swapping becomes visible.

### Worked practice and a readiness check

For d_model=12,H=3,T=6,B=2, compute d_head=4, Q shape [2,3,6,4], scores [2,3,6,6], and merged output [2,6,12]. Explain why adding a head does not necessarily mean increasing total model width.

Trace the starting representation for school at two positions under learned absolute embeddings. Then describe one difference between position vectors and the causal mask.

You are ready when head, token, batch, and feature axes have clear meanings. Next we place multi-head attention inside a transformer block, where residual connections, normalization, and nonlinear transformation complete the picture.

### Position and token additions by hand

Let the token vector for school be [1,2]. Suppose position 1 has vector [0.1,0.2] and position 4 has [-0.2,0.3]. The resulting starting rows are [1.1,2.2] and [0.8,2.3].

They have the same token identity component and different position components. The following learned projections can use their combination. The addition itself has not yet mixed information from a neighboring word.

For a two-head toy layer, give each head a different projection matrix and compare its score rows. The important observation is that separate parameters allow different patterns, not that each head is guaranteed a tidy human label. When explaining a trained head, distinguish a measured pattern on examples from a general claim about every sentence.

## Week 10 The transformer block step by step

### Attention is one operation inside a larger computation

We can now compute contextual mixtures, but a useful model needs more than a single mixture. A transformer block combines attention with a feed-forward network, normalization, and residual connections.

Imagine each token carrying a working vector. Attention adds information from other allowed positions. The feed-forward network transforms the features at that position. Residual paths retain an additive route for the existing representation.

We will use a pre-normalization block. Other ordering choices exist; specify which one you mean before comparing code. Our goal is to trace one concrete architecture correctly.

### The residual stream

Let x be a token representation [1,2]. Suppose an attention sublayer produces [0.5,-0.5]. Residual addition gives [1.5,1.5]. Both terms must have matching shape.

The residual connection means the block adds a learned transformation to the existing representation. It does not force the transformation to be small or guarantee that information is never lost. Later layers and projections can still change behavior substantially.

Across a sentence, the residual stream has shape [T,d_model], or [B,T,d_model] with batching. Its width stays consistent across the additions in this teaching model.

### Normalization before a transformation

Layer normalization computes statistics over the feature coordinates of each token. For a simple row [2,4], the mean is 3 and variance is 1, ignoring the small numerical epsilon. Standardizing gives [-1,1] before learned affine parameters.

This operation does not average different token positions together. It therefore does not itself allow a causal model to read future words. The choice of axis is central to both the mathematics and the implementation.

Real normalization includes epsilon to avoid division problems and usually learned scale and bias. RMSNorm is a related but different operation that uses root-mean-square scaling without subtracting the mean in its basic form.

### The first half of a pre norm block

Write h = x + Attention(LayerNorm(x)). Normalize the residual representation, compute masked multi-head attention, project back to width d_model, then add the result to x.

The query, key, and value projections operate on normalized inputs in this arrangement. The attention output still depends on the appropriate mask and position information.

Read the expression from the inside outward. The layer does not first add x to itself or normalize the entire batch as one vector. When debugging, save the normalized input and sublayer output separately.

### The feed forward network

The second half is y = h + MLP(LayerNorm(h)). The MLP operates independently at each token position with shared weights. A common teaching form expands from d_model to 4*d_model, applies a nonlinear activation, then projects back to d_model.

For d_model=8, a row [1,8] becomes [1,32], then [1,8]. This is a feature transformation, not another direct comparison across token positions.

Why the nonlinearity? Two linear maps without a nonlinearity compose into one linear map. A nonlinear activation permits a richer transformation. Modern models may use gated variants, but the basic separation of attention across positions and feature transformation within a position remains useful.

### Stacking blocks and producing logits

One block outputs another [B,T,d_model] tensor. A stack of blocks repeatedly applies these transformations. The final normalized representations feed a vocabulary output projection.

For our six-token sentence and vocabulary size V, logits have shape [B,6,V]. The logit row at a position predicts the following token under next-token training.

This completes a path from IDs to embeddings, positions, contextual blocks, and vocabulary scores. Softmax over vocabulary happens at a different boundary from softmax inside attention.

### Counting a small block

For the specific teaching block, ignore biases and normalization parameters. Standard MHA with H*d_head=d_model uses 4*d_model² matrix parameters for Q, K, V, and the output projection. A two-matrix MLP with hidden width d_ff=4*d_model uses 2*d_model*d_ff=8*d_model². Their sum is 12*d_model². This formula belongs to that combination of attention and MLP, not to every transformer block.

At d_model=64, the estimate is 49152 matrix parameters per block. Two blocks give 98304. Embeddings, normalization parameters, biases, and the output head add to that count; tied embeddings change it.

Use this estimate to understand where parameters come from, then verify by summing the actual implementation's parameter sizes. A rough formula is not a replacement for inspecting the model.

### GQA and SwiGLU change the parameter count

GQA keeps H query heads but shares H_kv key/value heads. With d_head=d_model/H and matching value widths, the attention matrix count is 2*d_model²+2*d_model*H_kv*d_head: one full-width query projection, smaller key/value projections, and one full-width output projection. For d_model=64, H=8, H_kv=2 and d_head=8, this is 10,240 attention parameters, compared with 16,384 for MHA.

SwiGLU uses three matrices: two project the input to d_ff, one branch is passed through SiLU, their coordinates are multiplied, and the third projects back to d_model. Its matrix count is 3*d_model*d_ff. If d_ff=4*d_model, that is 12*d_model² for the MLP alone. Choosing d_ff approximately (8/3)*d_model gives a count close to the teaching MLP’s 8*d_model²; implementations round widths for efficient kernels. Compare matched budgets instead of silently assuming every MLP expands by four.

Source: [GQA: shared key/value heads](https://arxiv.org/abs/2305.13245).

Source: [GLU variants and SwiGLU](https://arxiv.org/abs/2002.05202).

### Worked practice and a readiness check

Draw the full pre-norm block with two residual additions. Label the tensors before and after each operation. Explain which operations mix positions and which act independently on each token's feature row.

Given a sentence tensor [2,6,64], state why the attention and MLP outputs must return [2,6,64] before their residual additions. Then calculate the MLP's two matrix shapes [64,256] and [256,64].

You are ready to read a small transformer implementation when you can point to every part of this block and explain its role without using “the model understands” as the mechanism.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: Intuition

Our teaching model uses token embeddings plus learned position embeddings. A pre-normalization block is `h = x + Attention(LayerNorm(x))`, followed by `y = h + MLP(LayerNorm(h))`. The MLP expands the channel dimension, applies a nonlinearity, and projects back. Residual paths help gradients and preserve information. Modern models may use RMSNorm, rotary position embeddings, gated MLPs or grouped-query attention; these modifications do not remove the basic information-flow picture.

### Review A: Shapes and parameters

For this standard MHA plus two-matrix MLP, the residual tensor is [B,T,d_model] and the approximate matrix count is 12*d_model². For GQA or a gated MLP, count the actual projection shapes using the formulas above. Embedding and output-head parameters are additional; tying those weights changes their combined count.

For d_model=64 and two blocks, block matrices contain about `2*12*64^2 = 98,304` parameters. A 256-token embedding table adds 16,384. This is a tiny educational model, not an LLM. Counting parameters by summing `p.numel()` is the authoritative implementation check.

### Review A: Position and context

The model outputs one logit vector per input position. During training, the logit at position t predicts the token at t+1. During inference, use the last position's logits to select the next token. For encoder-decoder models, cross-attention additionally reads encoder outputs; our tiny model has no encoder.

### Review A: Experiment

notebook 12 trains a byte-level decoder on ordinary school and travel sentences. Draw the block before running it, count parameters, and overfit a tiny batch as a debugging step. Then restore a held-out sequence split and report validation loss. Compare removing attention versus removing the MLP while keeping the training budget fixed. A larger model trained for more steps is not a clean architectural ablation.

**Failure to recognize:** generating plausible fragments from a tiny repeated corpus is not evidence of general documentation understanding. It demonstrates that the model and training loop run. **Reading:** R04 model architecture; optional R01 architectures lecture. **Tutorial:** 10.

## Week 11 Encoders decoders and complete model architectures

### A numerical scaling-law planning example

In the Chinchilla study, the 70-billion-parameter model used about 1.4 trillion training tokens: roughly 20 tokens per parameter. For an illustrative dense model with N=100 million parameters, that ratio suggests D=2 billion tokens. The rough training-compute estimate C≈6ND then gives 1.2×10^18 FLOPs. Here N is parameter count and D is training-token count, not d_model. These are historical compute-optimal planning approximations under the study assumptions; deployment cost, data quality and inference demands can favor other ratios.

### A block becomes part of a task specific arrangement

The transformer is a family of architectures built from related components. An encoder, a causal decoder, and an encoder-decoder arrangement differ in visibility and information flow.

Use three ordinary tasks. Represent the complete sentence “I go to school by bus.” Continue the prefix “I go to school by.” Translate a complete source sentence into another language. The available input and required output differ across these tasks.

The word decoder does not simply mean “something that converts IDs back into strings.” In model architecture it names a neural sequence-processing arrangement. Tokenizer decoding is a separate operation.

### An encoder reads a complete input

For an encoder representing a fully observed sentence, valid positions can commonly attend to both earlier and later valid positions. The representation of school can use bus to its right.

That can help tasks such as labeling tokens or comparing complete inputs. A masked-language objective can hide a token and ask the model to predict it using the available surrounding text.

If we hide bus in “I go to school by [MASK],” the model's input contains a special masking situation. The training objective and input construction differ from ordinary left-to-right continuation.

### A causal decoder predicts continuations

A decoder-only language model uses causal self-attention over the input prefix. At a training position, it may read the current and earlier input tokens, but not the future target token.

For “I go to school by,” the last representation produces vocabulary logits for the next token. After selecting bus, the model appends it and continues.

Many familiar text-generating LLMs use this arrangement. The architecture explains the next-token computation; later post-training shapes conversational behavior.

### An encoder decoder connects two sequences

An encoder-decoder system first represents a source sequence. Its decoder then generates a target sequence while consulting both its target prefix and source representations.

The decoder's self-attention is causal over the target prefix. Its cross-attention takes queries from the decoder and keys/values from encoder outputs. Source positions need not obey the target's left-to-right order.

If the source has seven tokens and the target currently has four positions, cross-attention scores can have shape [4,7]. This rectangular matrix is the shape distinction we introduced in week 7.

### A visibility table clarifies the difference

For a four-token complete input, encoder self-attention can allow all four key positions in each valid query row. For a causal decoder, row 0 sees only 0, row 1 sees 0 and 1, and so on.

Cross-attention visibility additionally depends on valid source positions and task constraints. Padding still needs handling. “Encoder sees everything” is shorthand for permitted valid input positions, not permission to ignore arbitrary constraints.

Draw the three cases instead of memorizing model-name lists. The diagrams describe what information a position can use, which is often more useful than knowing a marketing label.

### Training time parallelism does not remove causality

During training, the full target sequence is available as data. A masked transformer can compute representations for many positions in parallel because the mask constrains their dependencies.

During ordinary autoregressive generation, the next generated token changes the next prefix. The model therefore proceeds sequentially across output-token decisions, even though each forward pass uses parallel numerical operations internally.

This distinguishes parallel computation within a known sequence from sequential dependence across newly generated tokens. Both can be true at the same time.

### Choosing the architecture for the learning exercise

Our tiny model will be a causal decoder with learned absolute positions, two blocks, and a vocabulary output head. This keeps the path close to the sentence-completion task we began with.

We are not claiming that this is the only useful architecture. We choose it because its labels, masks, and output selection can be inspected end to end.

When you later load a pretrained model, identify its architecture and tokenizer before applying assumptions from the teaching model. Different normalization, attention-head sharing, position methods, and training objectives can change important details.

### Attention variants keep different amounts of state

Imagine eight students asking questions about the same handbook. MHA gives every question head its own K/V projections. MQA gives all query heads one shared K/V head. GQA shares K/V within groups. In an H=8 layer with the same head widths, H_kv values of 8, 1, and 2 respectively make the cached K/V element counts proportional to 8, 1, and 2. Sharing reduces cache storage and bandwidth, while the trained model must learn to work with that sharing.

Multi-head latent attention, or MLA, compresses key/value information into a lower-dimensional latent state and uses learned projections to recover the information needed by attention. It is another way to reduce cached state, with a more involved projection and position-encoding design. Do not estimate its cache by copying the ordinary MHA formula; inspect what its implementation actually retains.

Sliding-window attention limits a position to a recent window, for example the last four allowed tokens in a teaching sequence. One layer then cannot directly read a fact ten positions earlier. Stacked layers, occasional global-attention layers, or another memory mechanism can enlarge access. Long-context techniques also include position-method changes and training on longer sequences. A configured context limit states accepted input length; task evaluation establishes whether distant evidence is used well.

### MoE and state-space models change different parts

A mixture-of-experts, or MoE, commonly replaces a dense MLP with several expert MLPs and a learned router. If there are eight experts but each token selects two, the model stores all eight while executing the selected experts for that token. Active parameter count and total parameter count therefore differ. Routing adds load-balancing and communication issues; MoE is not a promise that a large model fits in the memory needed by only two experts.

A state-space sequence model updates a compact recurrent state while reading the sequence. Think of carrying forward a changing numerical notebook rather than keeping every past K/V row available for a new query. Selective state-space models such as Mamba make parts of the update depend on the input. This offers different computation and memory behavior; retrieving an exact old detail and maintaining a compact state are different demands. Hybrid models combine attention and state-space layers.

### Scaling laws connect model size, data, and compute

Suppose you can afford a fixed number of training operations. Spending all of it on a larger model leaves fewer operations for reading training tokens. Spending it on more tokens with an extremely small model limits capacity. Scaling-law studies fit empirical relationships between validation loss, model size, training tokens, and compute. Compute-optimal training balances these quantities for the studied setup; a training-optimal choice can differ from the cheapest model to serve many times.

Source: [DeepSeek-V2: MLA and MoE](https://arxiv.org/abs/2405.04434).

Source: [Mamba: selective state-space models](https://arxiv.org/abs/2312.00752).

Source: [Training compute-optimal language models](https://arxiv.org/abs/2203.15556).

### Worked practice and a readiness check

For each task, identify the model arrangement and allowed context: filling a hidden word in a complete sentence, continuing an unfinished sentence, and generating a translation from a complete source.

Explain why a causal decoder cannot use the answer bus at the by position during training. Then explain why a complete-input encoder may legitimately use a word to the right of school.

You are ready when encoder, decoder, self-attention, cross-attention, training parallelism, and autoregressive generation refer to distinct operations and constraints in your explanation.

### Three tasks with the same words

Task A gives the complete sentence and asks which word refers to the vehicle. A complete-input representation may use both sides of a position. Task B gives “I go to school by” and asks for a continuation. It must not read an answer that has not been generated. Task C gives a source sentence and asks for a target-language sentence, requiring a relationship between two sequences.

Write separate masks and tensor shapes for these cases. If Task C has six source tokens and eight target positions, cross-attention scores have shape [8,6]. Causal target self-attention has [8,8]. The two matrices answer different information-flow questions.

This exercise prevents architecture names from becoming disconnected labels. Once you know the available inputs, the output task, and the attention sources, you can explain why a particular arrangement is appropriate and where leakage would occur.

## Week 12 Training a small transformer

### One sentence supplies several supervised predictions

Take the tokens [I,go,to,school,by,bus]. Build inputs [I,go,to,school,by] and targets [go,to,school,by,bus]. At each input position, the model predicts the next token.

This shift is easy to state and easy to implement incorrectly. If the target equals the token at the same position, a model may learn a different, much easier copying task. Low loss would then answer the wrong question.

Use a printed example of IDs and decoded tokens before beginning a long training run. Check the first and last supervised positions explicitly.

### The forward pass produces one vocabulary row per position

For batch size B, sequence length T, and vocabulary size V, logits have shape [B,T,V]. Targets have shape [B,T]. Cross entropy compares each valid row with the corresponding target ID.

The causal mask prevents future input leakage. The loss mask removes padding or other unsupervised target positions from the average. They work at different boundaries.

Flattening logits to [B×T,V] and targets to [B×T] is one implementation convenience. It should preserve the original pairing between each row and target.

### A training step is a sequence of operations

Choose a batch, run the model, calculate loss, clear old gradients, backpropagate, optionally clip gradients, and update parameters using the optimizer. Repeat with more data.

An optimizer such as AdamW maintains additional state and follows a specific update rule. You do not need to derive it again to inspect whether gradients reach the embedding table and attention projections.

Save a small record at intervals: step, number of valid tokens, training loss, validation loss, learning rate, and any numerical errors. A single final loss hides the path that produced it.

### Debugging before judging quality

A one-batch overfit experiment asks whether the model and training loop can fit a tiny fixed batch. It is a useful implementation diagnostic, not a generalization result.

Then restore a separate validation set. Disable dropout and gradient tracking for validation, and return to training mode afterward. Accidentally leaving a model in the wrong mode can change subsequent behavior.

Check finite losses and nonzero gradients. A plotting library cannot repair unshifted targets or an attention mask that exposes the answer.

### Learning patterns versus memorizing sentences

A tiny collection of school/travel sentences makes every example understandable, but repeated strings make memorization easy. Split complete examples before generating overlapping training windows.

Include a few held-out sentence patterns and report exactly what they test. A tiny model producing “I go to school by bus” does not establish broad reasoning or documentation expertise.

More data, model capacity, and training steps can change results, but changing all of them at once makes diagnosis difficult. Start with a controlled small configuration.

### Loss and generation tell different stories

A model can reduce average next-token loss while still generating a weak continuation under a particular decoding choice. Generation compounds decisions and can visit prefixes unlike those seen during training.

Conversely, one attractive generated sentence can come from a model with poor average performance. Evaluate several inputs and save raw outputs rather than selecting only the best demonstration.

For matched tokenization, perplexity is the exponential of average negative log probability. Keep the tokenizer and valid-token counting consistent when comparing runs.

### Batch size and accumulated gradients

If microbatch size is 2 and you accumulate across 4 equally sized microbatches, the effective example batch is 8 on one device. Divide each microbatch loss by 4 before backward if you want the average of those means, and update only after the accumulation group.

Different sequence lengths complicate exact token-weighted equivalence. Four means over different valid-token counts do not automatically equal a single global token mean.

We will study GPU memory and scaling later. For this week, a small float32 CPU run can establish correctness without requiring a large accelerator.

### A learning-rate schedule controls step size over time

The learning rate is the step-size multiplier in the optimizer update. Warmup starts with a smaller rate and increases it over early steps. A later cosine decay gradually reduces the rate. For a 100-step teaching run, choose a peak of 0.001, warm up for 10 steps, and decay to 0.0001 by step 100. At step 5 the linear warmup gives 0.0005; at step 10 the rate is 0.001; halfway through the decay, step 55, it is 0.00055. Plot this schedule before training so the intended changes are visible.

AdamW keeps moving estimates of gradient moments and applies decoupled weight decay. With learning rate η and decay λ, the decay contribution shrinks a selected weight by the factor 1−ηλ before considering its adaptive-gradient contribution. For weight 2, η=0.01 and λ=0.1, the decay-only result is 1.998. This is separate from choosing a smaller learning rate. Parameter groups commonly exclude biases and normalization weights from decay; record the actual grouping rather than assuming it.

Gradient clipping limits an update’s input gradient norm rather than repairing wrong labels. If a gradient vector has norm 10 and the maximum norm is 2, scale that vector by 0.2. Log the unclipped norm so repeated clipping remains visible. Mixed precision uses lower-precision arithmetic for supported operations while retaining higher precision where needed. FP16 training often uses gradient scaling to avoid underflow; BF16 has a wider exponent range but still requires suitable hardware and kernels. Keep labels, masks, and loss computation correct before interpreting a speedup.

### Data mixture and contamination change the experiment

A data mixture states how training examples are sampled. If 90% of the school corpus is bus sentences and 10% is library sentences, validation behavior may favor transport language. Record sampling weights, deduplication, document sources, and any oversampling. A held-out question, its answer, or a near-duplicate in training can contaminate an evaluation. Split meaningful document or problem families first, then generate paraphrases inside each split; retain a final set that never controls training or prompt choices.

Source: [AdamW update rule](https://docs.pytorch.org/docs/stable/generated/torch.optim.AdamW.html).

Source: [PyTorch automatic mixed precision recipe](https://docs.pytorch.org/tutorials/recipes/recipes/amp_recipe.html).

### Worked practice and a readiness check

Write the shifted targets for [3,8,2,5]. Then calculate average loss if valid target probabilities are [0.5,0.25,0.25]. Identify which positions should be excluded if one target is padding.

Train the tiny teaching model, save the configuration and loss history, and inspect at least three generated prefixes. Explain one failure using data, capacity, or implementation evidence.

You are ready when you can reproduce a run, show the actual input-target pairing, and distinguish a debugging overfit test from a held-out evaluation.

### A deeper pass after the worked introduction

The following reference treatment is for a second pass. First explain the ordinary example above, then use the equations and implementation details below to make the explanation more precise.

### Review A: From prediction to loss

Given token IDs `x[0:T+1]`, the input is `x[0:T]` and the target is `x[1:T+1]`. For logits z at a position, cross entropy is `-log softmax(z)[target]`. The language-model loss averages over valid target positions. If the model assigns probability 0.25 to each correct token, loss is `-log(0.25)=1.3863` nats and perplexity is 4. Perplexity is comparable only under appropriate matching tokenization and evaluation conditions.

Padding targets should be ignored. In SFT later, prompt positions may also be ignored while answer positions receive loss. Confusing an attention mask with a loss mask is a common bug: one controls information access, the other controls which predictions are supervised.

### Review A: Data quality is an engineering problem

Pretraining data pipelines filter, deduplicate, segment and tokenize. Duplicated or near-duplicated documents crossing train/test boundaries can create inflated evaluations. Split at a meaningful group boundary before producing overlapping chunks. For documentation, a page family or API topic may be a stronger group than an arbitrary text span. Keep version, license, origin, time and transformation metadata.

Gradient descent reduces training loss but does not guarantee the desired application behavior. Use training and validation curves to separate underfitting, overfitting and implementation bugs. Validate with dropout disabled and gradients off, without accidentally leaving the model in evaluation mode for the next training batch.

### Review A: Worked optimization example

If the microbatch size is 2 and you accumulate gradients across 8 microbatches on one device, the effective example batch is 16, provided each microbatch is equally sized. Divide each microbatch's loss by 8 before backpropagation, step the optimizer once, and clear gradients afterward. If sequence lengths vary, equal averaging of microbatch means may not equal a global valid-token average. Account for token counts when exact equivalence matters.

Adam-style optimizers maintain moment estimates, adding substantial memory. Learning-rate warmup and clipping can stabilize some settings, but first verify labels, masks and data. A scheduler cannot repair training on the wrong target. Save optimizer state, random states, tokenizer identity and current step if you want faithful resume behavior.

### Review A: Experiment

In notebook 12, compare train/dev losses for one fixed configuration over time. Intentionally train with unshifted labels once and explain why the task changes. Try a one-batch overfit test, then an actual grouped split. The starter's tiny corpus is too small for strong statistical conclusions; your report should say so.

**Exit criterion:** implement shifted labels, explain perplexity and list the artifacts needed to resume a training run. **Reading:** R01 data and optimization lecture headings. **Tutorial:** 12.

## Week 13 Generation decoding and the KV cache

### The model gives options before it gives a sentence

Return to “I go to school by.” A trained model produces a score for each vocabulary token. A decoding rule turns those scores into the next selected token.

Greedy decoding takes the largest score. Sampling chooses according to a distribution, possibly modified by temperature or filtering. These can generate different continuations from the same model.

The decoder is a decision procedure over predictions. It does not check whether the selected sentence is a true report of someone's commute.

### A small sampling distribution

Suppose bus, train, bicycle, and boat have probabilities [0.5,0.3,0.15,0.05]. Greedy selects bus. Repeated sampling may choose all four with frequencies approaching these probabilities under ideal repeated independent draws.

With top-k=2, retain bus and train and renormalize to [0.625,0.375]. With top-p=0.8 under a convention including the token that reaches the threshold, the same two tokens remain.

Boundary and tie conventions depend on the implementation. State them when comparing a hand calculation with a library.

### Generation changes the next input

After choosing bus, the next prefix includes bus. The model may predict a period. After choosing train, subsequent words may differ.

Generation is therefore not a list of independent classifications. Earlier selections change later conditions. A locally most probable token need not form the globally most probable complete sequence.

Beam search keeps several partial sequences according to a scoring rule, but its usefulness depends on the task and decoding objectives. It is not a universal replacement for sampling in open-ended generation.

### Reusing keys and values

In a causal transformer, earlier positions do not depend on future tokens. Their computed key/value states can be retained when appending a new token.

Without caching, a naive generation loop repeatedly processes the entire prefix. With a KV cache, the new token can query cached keys/values plus its own new states, subject to the model's architecture.

The cache stores intermediate representations, not a list of answers. It speeds repeated computation but does not improve the underlying evidence or factual reliability.

### A three-token cache trace

Imagine the prefix I go to. For each layer, cached keys and values exist for these three positions. To append school, compute the new position's representations and let its query attend to the four available key positions.

The old cached tensors remain associated with the exact earlier prefix. Change I to You, alter model weights, or change earlier role tokens, and reusing the old cache would generally be incorrect.

We will calculate cache memory in week 22. The important idea now is the validity condition that permits reuse.

### A cache ledger for prefill and decode

The following ledger uses one word per teaching token. At every layer, write K(word) and V(word) for the cached projected states. Prefill processes all known prompt positions; decode then processes a newly supplied token using the retained past states. The first generated token is selected from the last prompt position’s logits before that generated token itself has been processed into the cache.

| Operation | Input processed now | Cache after processing, per layer | Next-token choice |
|---|---|---|---|
| Prefill | I go to | K/V(I), K/V(go), K/V(to) | school |
| Decode | school | K/V(I), K/V(go), K/V(to), K/V(school) | by |
| Decode | by | K/V(I), K/V(go), K/V(to), K/V(school), K/V(by) | bus |

At the end of the final row, bus has been chosen but its own K/V row is not yet present. Process bus on the next decode step to cache it and predict what follows. Each cached position has a key and value vector for each retained K/V head at each layer. This ledger separates choosing a token from processing that token on the next forward pass.

### Text models and chat formatting

A conversational model still receives a serialized token sequence. Its tokenizer may include a chat template that marks roles and message boundaries.

Writing the visible text “system:” is not automatically equivalent to the template's special tokens. Inspect a short rendered example and count tokens with the actual tokenizer.

We introduce this interface after the basic generation loop so role formatting is another input construction choice you can explain. It should not hide the next-token mechanism underneath.

### Min-p and repetition penalties modify selection

Min-p retains tokens whose probability is at least a fraction of the most probable token. For [0.5,0.3,0.15,0.05] and min_p=0.2, the cutoff is 0.2×0.5=0.1, so bus, train, and bicycle remain, then renormalize by 0.95. If the top probability changes, the cutoff changes with it. This differs from top-p, which accumulates probability mass, and top-k, which keeps a fixed count.

A repetition penalty discourages tokens already present in the chosen scope. One common implementation divides a previously used positive logit by a factor greater than one and multiplies a negative logit by that factor, reducing it in both cases. Other systems use frequency or presence penalties instead. Repeating an API identifier or a word such as “school” can be correct, so inspect both excessive repetition and damaged necessary repetition.

### Speculative decoding checks a draft with the target model

A cheaper draft model proposes several next tokens, for example “school by bus”. The target model scores those proposed positions together and a verification rule accepts a prefix of them, then corrects where needed. Exact speculative sampling uses an acceptance-and-correction construction that preserves the target sampling distribution under its assumptions; simply accepting any plausible draft is a different, approximate procedure. The gain depends on draft cost, accepted-token rate, batching, and hardware. This changes how computation is scheduled, not what a token means.

Source: [Transformers generation parameters](https://huggingface.co/docs/transformers/main_classes/text_generation).

Source: [Exact speculative sampling](https://arxiv.org/abs/2302.01318).

### Stopping and evaluating a continuation

Generation needs a stopping condition: an end token, a specified maximum number of new tokens, or another explicit rule. Maximum length prevents an unbounded continuation but can also truncate a response.

Distinguish input tokens from newly generated tokens when decoding an output tensor. Returning the complete prompt as if it were generated text creates a misleading evaluation.

For our simple examples, inspect whether the continuation is grammatical and consistent with the supplied context. Later tasks will require independent factual and task checks.

### Worked practice and a readiness check

Apply top-k=3 to [0.5,0.3,0.15,0.05] and renormalize by 0.95. Then explain the difference between temperature adjustment and deleting candidates outside top-k.

Draw cache contents before and after appending one token. Explain why changing an earlier token invalidates reuse, even if the length stays the same.

You are ready when you can trace a complete generation step from prefix IDs through logits, token selection, append, cache update, and termination.

### The cached computation and a changed prefix

Consider generating after “I go.” Cached keys and values represent those exact two input positions under the chosen model. Appending the token “to” can reuse those earlier states in a causal model because future inputs do not change their past computation.

Replace the prefix with “You go.” Its length is still two, but the first token embedding and all dependent earlier states can differ. A cache indexed only by prefix length would return the wrong computation.

Now change the system instruction of a chat prompt while leaving the visible user sentence identical. The full token prefix has changed again. Cache identity must reflect the actual preceding tokens and relevant model configuration, not just the human-visible last question.

This example connects a numerical optimization to correctness. Saving computation is useful only when the reused state belongs to the computation you intend to perform.

## Week 14 From pretraining to instruction following and reasoning

### Completing text and following a request

A pretrained language model learns patterns from prediction tasks. A request such as “Complete this sentence with one transport word” asks for a particular style of behavior.

The model may have acquired some useful behavior during pretraining, but supervised examples can make desired formats and responses more consistent. We distinguish the model's general prediction training from later adaptation.

Keep using simple tasks. Given “I go to school by ___,” one desired response is bus. Given “Name two possible completions,” a desired response could be bus and train. The task instruction changes what a satisfactory response looks like.

### Pretraining learns from broad text

Next-token pretraining uses text to create many shifted prediction targets. The data and objective do not guarantee that every generated claim will be correct.

The model learns parameters that support predictions across its training distribution. It does not store every sentence as an ordinary searchable row, although memorization can occur.

An embedding table, attention projections, MLP weights, and output head all participate in this parameterized computation. The full path from the earlier lectures remains present after training.

### Supervised fine tuning supplies desired responses

An SFT example pairs an input with a target output. For a single-turn teaching example, the input might contain an instruction and sentence prefix, and the target might be the desired completion.

Training may calculate loss only on assistant-response tokens while keeping prompt tokens available as context. This is loss masking, separate from causal attention masking.

This week establishes the idea. We will construct datasets, adapters, and controlled fine-tuning experiments in weeks 24–26 after studying evaluation and compute resources.

### Preferences compare candidate responses

A preference example contains a prompt and two possible responses, with one preferred under a stated rubric. A correct, concise completion can be preferred to an unrelated answer.

RLHF often uses preference-derived reward information in a reinforcement-learning procedure. DPO uses a direct preference objective relative to a reference model. The details will come later; both require thoughtful data and evaluation.

Preference is a signal about judged behavior. A reward for pleasant wording alone can favor fluent but incorrect responses. The rubric matters as much as the algorithm's name.

### Reasoning as intermediate computation

Consider “A bus ticket costs 4 dollars. I buy three tickets. What is the total?” The checkable result is 12 dollars. A response may show the concise calculation 3×4=12.

Chain-of-thought prompting uses intermediate steps or examples to help some models with some tasks. A generated rationale can still accompany a wrong final answer. It is not guaranteed to reveal the model's actual internal causal process.

Reasoning-trained models may use extra inference computation. We should evaluate final correctness and resource use rather than judging ability by the length of a displayed explanation.

### A multi-step answer can fail at a specific boundary

Use this problem: “A school buys 8 adult tickets at 6 dollars and 12 student tickets at 4 dollars. A 25% discount applies only to the student tickets. What is the total?” The adult subtotal is 8×6=48. The student subtotal is 12×4=48, discounted to 36. The correct total is 84. A fluent but wrong solution discounts the whole 96-dollar bill and returns 72. The failure is the scope of “only”, not multiplication.

Compare a direct answer with a prompt asking for adult subtotal, eligible student subtotal, discount, and final total. Record the final correctness and whether the discount was applied to the correct group. Do not claim this prompt helped until the same comparison has been run over several independently checked problems. A displayed sequence of steps makes an error easier for a reader to inspect; it is not proof that the sequence faithfully describes all internal computation.

### Test-time compute spends work after training

A fixed model can spend more inference work by generating a longer intermediate computation, sampling several candidates, searching alternatives, or using a verifier. For the ticket problem, sample three candidates and check the two subtotals and discount scope. Report all generated tokens and verification calls, including rejected candidates. More test-time compute buys opportunities to find or check a solution; the selection rule determines whether those opportunities improve the final answer.

### PPO, GRPO, RLVR, and constitutional feedback

In reinforcement-learning post-training, the language model is a policy that assigns probabilities to response tokens. A reward scores a sampled response. PPO compares new and old policy probabilities and clips the training objective to discourage overly large updates; common RLHF setups also control drift from a reference model. Its value estimator helps estimate how much better a response was than expected. This is parameter training, unlike asking a fixed model to show steps.

GRPO samples a group of responses for the same problem and compares their rewards within the group. A typical form subtracts the group mean and divides by a stabilized group standard deviation to form relative advantages, avoiding a separate learned value model in that setup. If every candidate receives the same reward, the group offers little or no relative learning signal. Implementations differ in normalization, clipping, and reference-policy penalties, so identify the actual objective used.

RLVR means reinforcement learning with verifiable rewards. A checker might test the final ticket total, run a unit test, or verify a mathematical result. It supplies a more directly checkable signal than “sounds convincing”, but a weak checker can still reward shortcuts. Checking only whether the final string is “84” does not prove that every displayed step is correct.

Constitutional methods use written principles to guide critique, revision, or preference judgments. For example, ask a model to critique an answer against a principle requiring evidence-based claims, then revise it; AI feedback may also help form training preferences. The principles and reviewer become part of the learning process and require evaluation for bias and errors. Constitutional feedback, human preferences, verifiable rewards, and SFT labels are different sources of supervision that a training recipe can combine.

Source: [Proximal Policy Optimization](https://arxiv.org/abs/1707.06347).

Source: [DeepSeekMath: Group Relative Policy Optimization](https://arxiv.org/abs/2402.03300).

Source: [Constitutional AI](https://arxiv.org/abs/2212.08073).

### A fair small reasoning experiment

Prepare arithmetic examples with independent answers. Compare direct responses with concise step-based prompts using the same model, task set, and decoding settings where appropriate.

Count all generated candidates and verification calls. If one method samples five answers before selecting one, its cost includes all five.

For a simple sentence completion, extra reasoning may add no value. For arithmetic, a calculator can provide an independently checked result. We will introduce executable tools only after the underlying model and later application task are clear.

### In context learning and weight changes

Providing examples in the prompt can influence the current output without changing model weights. Fine-tuning changes trainable parameters using an optimizer.

Suppose the prompt gives two examples of answering with a single word. That is contextual instruction or demonstration. Saving an adapter after gradient updates is a different intervention.

This distinction will matter when diagnosing whether a failure needs a better prompt, better evidence, or a learned change. For now, identify which information lives in the input and which lives in parameters.

### Worked practice and a readiness check

Write two SFT examples for sentence completion and one preference pair where the preferred output follows a one-word instruction. Identify prompt tokens and answer tokens for the loss.

For the ticket problem, write the correct answer and an attractive but incorrect explanation. Explain why scoring only explanation fluency would fail.

You are ready when pretraining, SFT, preferences, in-context examples, and reasoning prompts have different meanings in your explanation. We will return to their harder objectives and experiments in semester two.

### A response can follow format and still be wrong

The instruction asks for one word completing “I go to school by ___.” A target bus teaches a format as well as an association. If every example insists on bus regardless of evidence, the model can learn a narrow pattern that fails when the context says the speaker walks.

Use a contrasting example: “The bus service is closed today. I go to school by ___.” The desired completion may now depend on additional information, and several answers may remain plausible. A dataset that pretends there is always one uniquely correct answer can encode unwarranted certainty.

For instruction-following evaluations, separate compliance with “one word” from whether the content fits the supplied facts. For reasoning, separate a correct final amount from a convincing-looking calculation. These distinctions will guide our later adaptation experiments and prevent a lower loss from becoming an automatic claim of better behavior.

## Week 15 Generative AI beyond text

### Generation means modeling possible outputs

Our text model generates a sequence by repeatedly predicting a token. Generative AI also includes images, sound, and other outputs. The common idea is learning a distribution or generation process; the mechanisms need not all be next-word prediction.

Imagine a collection of handwritten pictures of buses. A classifier might predict whether an image contains a bus. A generator aims to produce new samples with relevant structure.

A generated image can look plausible without reproducing a particular training image. It can also contain errors. As with language, plausibility and task correctness need separate evaluation.

### A latent representation and a decoder

An autoencoder maps an input into a compressed representation and reconstructs it. A variational autoencoder adds a probabilistic latent formulation and regularization that encourages a useful latent distribution.

Think of a small vector controlling several aspects of a drawing, but do not assume each coordinate automatically has a clean human label. The network learns a representation under its objective.

A basic VAE objective balances reconstruction with a term relating an approximate latent posterior to a chosen prior. The model can then sample a latent and decode it. A bottleneck picture explains the roles before the full variational derivation.

### Adversarial learning

A GAN trains a generator against a discriminator. The discriminator learns to distinguish relevant training examples from generated examples under the training setup; the generator tries to produce outputs that challenge it.

The two objectives interact. A strong-looking sample alone does not show that the learned distribution covers all important cases. Training instability and limited diversity are issues to investigate.

We study the arrangement to distinguish it from token likelihood training, not to build a production image generator during this course.

### Diffusion starts from corruption

Take a simple eight-by-eight pattern representing a letter. Add controlled Gaussian noise to make increasingly corrupted versions. A diffusion model learns a denoising-related prediction across noise levels.

The forward formula can be written x_t=√ᾱ_t x_0+√(1−ᾱ_t) ε, where ε is standard Gaussian noise. The coefficients determine the relative signal and noise.

At ᾱ=1, the sample is the original signal. At ᾱ=0, the formula gives noise. Intermediate values are mixtures. A slider illustrating this forward formula does not itself implement a learned reverse model.

### A concrete scalar diffusion calculation

Let x0=2, ε=-1, and ᾱ=0.64. Then √ᾱ=0.8 and √(1−ᾱ)=0.6, giving x_t=0.8×2+0.6×(-1)=1.

This arithmetic is the same for each element of a simple tensor under the noising expression. A learned model predicts noise or a related target, and sampling uses a reverse procedure with a schedule.

Moving a display slider backward can reveal less noisy versions because the original signal remains known to the visualization. That is different from learning to generate a new sample starting from unknown noise.

### What the denoiser learns and how generation runs backward

During training we know a clean example x_0. Sample a noise level t and Gaussian noise ε, construct x_t with the forward formula, and ask a network ε_θ(x_t,t) to predict that noise. A common simplified loss is the mean squared error between ε and ε_θ. For the scalar example above, if the actual ε is −1 and the prediction is −0.8, squared error is 0.04. The network must learn across many clean examples and noise levels.

Generation starts with a new noise sample, not the original image. At each scheduled step, the denoiser predicts noise or another trained target, and a sampler uses that prediction to form a less noisy state. In the DDPM parameterization, its reverse mean is μ_θ(x_t,t)=(x_t−β_t ε_θ(x_t,t)/√(1−ᾱ_t))/√α_t, where α_t=1−β_t and ᾱ_t is the accumulated product. A reverse step may add scheduled random noise as well. This is a learned transition; sliding backward through stored corruptions is only a visualization.

| Stage | Known or supplied | Operation |
|---|---|---|
| Training | x_0, t, ε | Create x_t; predict ε; calculate prediction error. |
| Sampling start | A fresh noise sample and optional condition. | Start at the noisiest scheduled state. |
| Reverse steps | x_t, t, condition | Predict a denoising target and update the state using a sampler. |

### Latent diffusion and DiT move the same idea to different representations

Latent diffusion first uses an image autoencoder to represent a clean image by a smaller latent tensor. Diffusion training and sampling operate in that latent space; an image decoder converts the final latent back to pixels. This reduces the spatial size of repeated denoising work while making the autoencoder’s reconstruction quality part of the system.

A Diffusion Transformer, or DiT, uses transformer blocks as the denoising backbone, often on patches of image latents. Image-patch tokens carry spatial information and noise-level conditioning rather than ordinary word meanings. Replacing a U-Net with a transformer changes the predictor architecture; it does not turn diffusion into left-to-right word prediction.

### Classifier-free guidance combines conditional and unconditional predictions

For a prompt such as “a red school bus”, train a conditional denoiser while sometimes dropping the condition. At sampling, obtain predictions ε_cond with the prompt and ε_uncond without it. One common convention combines them as ε_guided=ε_uncond+w(ε_cond−ε_uncond). Here w=1 gives the conditional prediction and w>1 strengthens its difference from the unconditional prediction. If ε_uncond=0.2, ε_cond=0.5, and w=2, the combined scalar prediction is 0.8. Larger guidance can improve adherence while changing diversity or producing artifacts; report the convention because APIs may parameterize guidance differently.

### Flow matching learns a direction of transport

A simple flow-matching example joins a noise point x_noise=−1 to a data point x_data=2 by x_t=(1−t)x_noise+t*x_data. The target velocity along this chosen straight path is 3. At t=0.4 the point is 0.2. A neural network learns a velocity field from many such training paths; an ODE solver follows the learned field from noise toward data. Actual model designs choose paths and parameterizations carefully. This example distinguishes a learned transport direction from DDPM’s noise-prediction target.

### A vision-language model reads an image and produces language

A common VLM connects an image encoder, a projection or connector, and a language model. For a school-bus photograph, the image encoder produces visual features; the connector maps them into representations the language model can use alongside text tokens. The model then generates an answer to “What color is the bus?” Training may align image-text pairs and later use image-conditioned instructions. A VLM can still misread small text, count incorrectly, or infer unseen details, so evaluate visual evidence and answer accuracy separately.

Source: [Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239).

Source: [Latent diffusion models](https://arxiv.org/abs/2112.10752).

Source: [Diffusion Transformers](https://arxiv.org/abs/2212.09748).

Source: [Classifier-free diffusion guidance](https://arxiv.org/abs/2207.12598).

Source: [Flow matching](https://arxiv.org/abs/2210.02747).

Source: [Visual instruction tuning](https://arxiv.org/abs/2304.08485).

### Flow ideas and multimodal tokens

Normalizing flows use invertible transformations with a tractable change-of-variables formulation. Flow matching learns a vector field transporting between distributions. They are related to generative modeling but should not be treated as synonyms for every diffusion implementation.

Some multimodal systems represent images or audio using patches, features, or discrete tokens and connect them to transformer components. The representation and objective define what the model predicts.

A language-model vocabulary and an image-patch representation have different semantics. “The model uses tokens” does not mean the tokens correspond to ordinary words.

### Comparing families by the question each answers

For autoregressive text, ask which next-token conditional is modeled and how generation proceeds. For a VAE, ask about latent variables, reconstruction, and prior matching. For a GAN, ask about the generator-discriminator training game. For diffusion, ask about forward corruption and the learned reverse-related predictions.

These questions are more informative than memorizing a list of names. A system may combine components from several families.

Keep the scope clear: our deep implementation path remains the text transformer. The other families receive conceptual and numerical introductions with optional deeper readings.

### Worked practice and a readiness check

Calculate the forward-noising formula at ᾱ=0 and ᾱ=1 for the scalar example. Then explain why an image classifier and image generator have different output tasks.

Draw the roles in a VAE and a GAN without claiming that every latent coordinate has a fixed interpretation. Write one sentence describing what diffusion learns beyond displaying noisy pictures.

You are ready when generative AI is broader than LLMs in your mental model and you can compare mechanisms without collapsing them into a single buzzword.

### Different kinds of uncertainty

A text prefix may have several sensible next words. An image prompt may admit many valid pictures. A spoken sentence may be delivered with different voices and timing. Generative modeling must accommodate variation rather than assume there is always one exact output.

Evaluation therefore depends on the task. A bus fare calculation has a checkable numerical answer. A new bus illustration has many acceptable appearances, but it can still fail an instruction such as “show exactly two wheels.” A sample can be diverse yet wrong, or accurate to a narrow instruction yet repetitive across a collection.

This helps explain why a classification accuracy, a text likelihood, and a human preference score cannot be substituted for one another without a task definition. The modeling family, training objective, and evaluation each answer a different question.

## Week 16 A complete transformer walkthrough and first semester review

### An end-to-end numeric transformer trace

Take two input tokens with IDs [0,1], one head and d_model=2. Q/K/V and attention output projections are identity matrices. Both MLP matrices are identity, with ReLU between them. Each normalization uses population variance, epsilon=0.00001, scale=1 and bias=0. The vocabulary head is [[1,0,-1],[0,1,0]] in row-vector convention. These fixed weights illustrate computation, not a trained language model.

| Stage | Numeric value |
|---|---|
| IDs | [0,1] |
| token embeddings | [[1,0],[0,1]] |
| position additions | [[0,0],[0.1,-0.1]] |
| input X | [[1.0, 0.0], [0.1, 0.9]] |
| Norm(X)=Q=K=V | [[1.0, -1.0], [-1.0, 1.0]] |
| causal attention weights | [[1.0, 0.0], [0.0558, 0.9442]] |
| attention output | [[1.0, -1.0], [-0.8883, 0.8883]] |
| first residual | [[2.0, -1.0], [-0.7883, 1.7883]] |
| ReLU MLP output | [[1.0, 0.0], [0.0, 1.0]] |
| second residual | [[3.0, -1.0], [-0.7883, 2.7883]] |
| final normalized state | [[1.0, -1.0], [-1.0, 1.0]] |
| vocabulary logits | [[1.0, -1.0, -1.0], [-1.0, 1.0, 1.0]] |
| next-token probabilities | [[0.787, 0.1065, 0.1065], [0.0634, 0.4683, 0.4683]] |

The last row supplies the distribution for the next token. Select a vocabulary ID, append it, and run the next causal step. For training, a target for each position would instead select one probability for cross-entropy. The two residual additions and final normalization are included in the trace.

### The semester returns to one sentence

We began with “I go to school by ___.” We can now trace a causal transformer that predicts a continuation. The goal of this lecture is to connect the components you have already studied, rather than introducing an application framework.

Use a small vocabulary and a two-block teaching model. Keep token IDs, representation width, head count, and sequence length visible in your diagram.

This model is intentionally small enough to inspect. The architecture shares important ideas with much larger systems, while its performance and resources remain very different.

### Stage one text becomes representations

Tokenize the prefix into [I,go,to,school,by] and convert it to IDs. Select one vector per ID from the embedding table.

Add the position vector for each location. With five tokens and width d_model=8, the representation matrix is [5,8].

An ID does not itself encode order or semantic distance. The embedding lookup and position representation supply separate information that later transformations can use.

### Stage two each block mixes and transforms

Normalize each row, form Q/K/V, split the appropriate head axes, calculate scaled pairwise scores, apply causal visibility, and softmax over keys. Multiply by values, merge heads, and project back to width 8.

Add that sublayer output through the residual path. Normalize again, apply the position-wise MLP, and perform the second residual addition.

Repeat for the next block. The output retains one contextual row per position. At no causal query may the computation use an unavailable future input.

### Stage three vocabulary predictions

The final output head transforms each contextual row into V vocabulary logits. The last prefix position, by, supplies the logits used to choose the next token.

Suppose bus=2, train=1, bicycle=0 and all other candidates are excluded for this small arithmetic example. Softmax gives approximately [0.665,0.245,0.090].

A real vocabulary includes many other candidates, so the denominator would include their scores too. Restricting the arithmetic example must be stated; it is not the full output distribution of a real model.

### Stage four training and generation use the result differently

During training on the complete sentence, the expected target bus supplies a cross-entropy loss. Its gradient changes the parameters through the computation you traced.

During inference, there is no given bus target to backpropagate. A decoding rule selects a next token, appends it, updates or reuses cached states as appropriate, and continues until a stopping condition.

This distinction explains why the same network can produce logits during both training and use, while the surrounding procedure differs.

### Diagnosing mistakes at the correct boundary

If IDs decode to the wrong words, inspect the tokenizer/vocabulary pairing. If future perturbations change earlier outputs, inspect visibility. If output width differs from the vocabulary size, inspect the output head.

If training loss falls but the held-out task remains weak, inspect data, capacity, optimization, and evaluation before concluding that the block is implemented incorrectly.

A systematic debugging explanation names the boundary, a concrete observation, and a test that distinguishes possible causes. “The AI is confused” does not provide that information.

### Reading the original architecture with preparation

Open the original transformer paper's model diagram and attention equation. Identify which components you have implemented and which belong to the encoder-decoder translation architecture rather than our decoder-only exercise.

Write tensor shapes beside one equation. Locate the residual connections and the MLP. Note that our pre-norm teaching block differs from the original architecture's normalization arrangement.

This is a useful point to read a paper: you now have operations and examples with which to interpret the compact presentation.

### First semester assessment and the next step

Take the first semester exam. It asks about tokenization, probabilities, attention, masks, block shapes, architecture visibility, shifted training, and generation. It does not require a vector database, RAG service, or agent implementation.

Complete the tiny-model experiment and keep an honest account of its limitations. Your first semester artifact is an explained and tested model mechanism, not a prematurely assembled application.

Semester two will introduce search and external evidence using the representations and evaluation ideas you now understand. Before moving on, explain the complete school sentence trace aloud without skipping from token IDs directly to “the model answers.”

### A final shape ledger

For B=2,T=5,d_model=8,H=2 and vocabulary size V=20, token IDs have [2,5], starting rows have [2,5,8], per-head queries have [2,2,5,4], and attention scores have [2,2,5,5]. Merged contextual output returns [2,5,8], and vocabulary logits have [2,5,20].

The last input position of each sequence contributes a twenty-way next-token distribution during ordinary continuation. During training, all valid positions can contribute losses against shifted targets. In both cases, the causal constraint limits each query's visible keys.

Explain each axis in words before writing a reshape. Then construct a small tensor with deliberately distinct numbers for batch, head, position, and feature indices. A mistaken transpose becomes visible. This small experiment turns a shape ledger into an implementation check rather than decorative notation.
