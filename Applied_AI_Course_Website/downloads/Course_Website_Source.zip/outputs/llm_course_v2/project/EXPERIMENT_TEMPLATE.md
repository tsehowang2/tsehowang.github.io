# Experiment record

Question and hypothesis:

Observed failure motivating this experiment:

Changed variable and unchanged controls:

Task split and group policy:

Source/model/tokenizer/index/prompt/tool/code revisions and hashes:

Device, precision, Python/package versions, seed:

Commands and setup steps:

Raw output path and metric definitions including denominators:

| Metric | Baseline measured | Candidate measured | Paired difference and uncertainty |
|---|---|---|---|
| Primary task metric | Fill after running | Fill after running | Fill after running |
| Failure or safety metric | Fill after running | Fill after running | Fill after running |
| Latency and resource metric | Fill after running | Fill after running | Fill after running |

Per-slice findings and examples of corrected/new errors:

Validity threats and limitations:

Release decision and reason:

Next experiment:

Leave unmeasured cells unmeasured; do not substitute hypothetical values.
