# A technical-documentation assistant
## Before the capstone
Weeks 1–16 concentrate on understanding and training a small transformer. There is no application-delivery milestone in semester one. Keep a learning notebook with shapes, calculations and a tiny-model experiment.

## The application question
From week 17, build an assistant for a small public technical-documentation collection. It should cite supported answers, distinguish versions, acknowledge missing evidence and use executable tools when needed. Begin with the fictional Atlas fixture, then choose public documentation with clear reuse terms.

One request might ask for a version-2 timeout and a total retry delay. Retrieval supplies the documented setting; a calculator supplies arithmetic. Preserve the version and cite the source.

## Milestones
- Week 17: task charter, permitted corpus, question families and success criteria; lexical versus semantic search.
- Week 18: persistent vectors, metadata, updates, deletion and version filtering. Understand exact search before ANN.
- Week 19: retrieve, pack, generate and cite, starting with a school-handbook example.
- Week 20: one controlled chunking or hybrid-retrieval experiment under fixed context budget.
- Week 21: development protocol and separate held-out questions; retrieval and answer errors recorded independently.
- Weeks 22–23: resource budget and measured profiling experiment.
- Week 24: diagnose whether errors need better evidence, prompting or supervised examples; audit targets.
- Weeks 25–26: LoRA pilot and base/prompt/adapter comparison; a negative result is acceptable.
- Week 27: calculator plus one documentation/configuration tool, typed arguments and bounded authority.
- Week 28: fixed workflow versus bounded model planner, with complete traces and failures preserved.
- Week 29: API and coherent release manifest.
- Week 30: regression checks, observability, hostile inputs and rollback rehearsal.
- Week 31: integrated evaluation and supported/absent/wrong-version/tool/failure demonstrations.
- Week 32: defend the chosen release and reproduce it from a clean directory.

## Evaluation design
The supplied 12 Atlas cases are smoke-test examples, not a completed project evaluation. Author and manually check at least 28 additional cases from your chosen documentation; do not count automatic paraphrases as independent evidence. Save the full set as runs/project_cases.json with unique id, question, expected facts, source IDs, group, version and checked=true. Create at least 40 independently checked cases with paraphrases, version conflicts, missing answers and tool requests. This is a practical exercise minimum, not a statistically conclusive benchmark. Group related variants to prevent near-duplicate leakage. Permit access to the reference corpus while withholding final questions and labels from tuning.

Measure evidence recall, answer correctness, citation support, version mistakes, refusals, tool arguments, latency, tokens and failures. Save per-task outputs and compare the same tasks. Separate simulations from actual model measurements. Report uncertainty and task-set limitations.

## Deliverables and rubric
Submit source, setup instructions, corpus manifest, dataset card, experiment records, raw evaluation outputs, release manifest, demo and report. Score task/data definition 15, baseline/retrieval 20, evaluation/error analysis 25, tools/controller 15, reproducibility/operations 15, interpretation/limits 10.

An honest portfolio claim describes an independently built prototype with measured results on a stated task set. Do not invent production users or deployment. Explain why retrieval, adapters and agents were included or excluded.
