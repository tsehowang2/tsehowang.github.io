# Release and incident rehearsal

Before release, identify the immutable manifest, corpus/index compatibility, model/tokenizer/adapter, prompt, tools and environment. Run deterministic tests, integration checks and the planned task evaluation. Inspect wrong-version evidence, citations, unknown requests, malicious document content, invalid tool arguments, loop exhaustion and failure responses. Check raw outputs and numerical denominators. Record pass/fail for every hard gate.

Measure warm/cold end-to-end latency on specified lengths/concurrency; include failures. Verify API limits, caller access as applicable, no secrets in logs, source/update/deletion propagation and scope-aware cache behavior if caching exists. Save the previous qualifying manifest and a tested restoration procedure.

During the drill, deliberately point to a wrong corpus hash or incompatible index. Observe controlled rejection, restore the previous version and run smoke requests. Do not modify the read-only source corpus to simulate this; change a copied manifest or temporary test fixture.

Incident report fields: trigger/time; user impact; affected version; detection signal; diagnostic evidence; mitigation; root cause; contributing factors; one regression test; one measurable prevention action; owner and follow-up condition. A failed drill is a finding to repair, not a result to hide.

## Submitted release audit

Save runs/release_manifest.json, project_cases.json, project_results.json, manual_grades.json, environment.txt and limitations.md alongside the notebook artifacts. The release audit lists missing or invalid submissions and requires 40 checked cases. Mark unused components as not_used. A passing artifact audit still requires human review of task quality and evidence.
