# Applied AI, second edition
Start with week 1. The first sixteen weeks build a language model and a transformer from ordinary sentences. Application engineering begins in week 17.

Each week has HTML lecture slides, a longer lecture reader, a guided Python notebook, an independent exercise, and three questions with worked solutions. Read the introduction, predict the worked result, then examine the deeper explanation. Run code after you can explain its inputs and expected output.

Budget ten hours: three for lecture and slides, one for hand calculations, two for the guided tutorial, two for independent experiments, and two for the test and corrections. Examination weeks replace the normal independent experiment and review with a two-hour examination and corrections. The final defense replaces the normal tutorial experiment.

No browser editor is required. Download the full course pack for local or Colab execution. Extract it so coursekit, data, notebooks and tests are siblings. Run from its root or notebooks directory. A lone notebook needs these support files.

The tiny transformer is the first-semester learning project. The documentation assistant is the second-semester portfolio project. Keep actual results, including failed experiments.
