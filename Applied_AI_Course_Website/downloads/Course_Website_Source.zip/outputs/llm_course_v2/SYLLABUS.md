# Syllabus: build the model before the application

Two 16-week semesters, ten hours per week. English throughout. Every new topic starts with an ordinary example before its mechanism and deeper treatment.

## Weekly rhythm

Lecture/slides 3h; hand calculations 1h; guided notebook 2h; independent experiment 2h; test/corrections 2h. Exam and defense weeks replace ordinary tasks. Optional deeper sections can be deferred when the ten-hour budget is reached.

## Semester 1: language models and transformers

- Week 1: What a language model is trying to learn. Tutorial 01; weekly questions 01.
- Week 2: From text to tokens and numerical IDs. Tutorial 02; weekly questions 02.
- Week 3: What word vectors can represent. Tutorial 03; weekly questions 03.
- Week 4: From scores to probabilities and learning signals. Tutorial 04; weekly questions 04.
- Week 5: Why language needs context and order. Tutorial 05; weekly questions 05.
- Week 6: Attention begins as a weighted mixture. Tutorial 06; weekly questions 06.
- Week 7: Where queries keys and values come from. Tutorial 07; weekly questions 07.
- Week 8: Scaling and masking attention correctly. Tutorial 08; weekly questions 08.
- Week 9: Multiple attention heads and position. Tutorial 09; weekly questions 09.
- Week 10: The transformer block step by step. Tutorial 10; weekly questions 10.
- Week 11: Encoders decoders and complete model architectures. Tutorial 11; weekly questions 11.
- Week 12: Training a small transformer. Tutorial 12; weekly questions 12.
- Week 13: Generation decoding and the KV cache. Tutorial 13; weekly questions 13.
- Week 14: From pretraining to instruction following and reasoning. Tutorial 14; weekly questions 14.
- Week 15: Generative AI beyond text. Tutorial 15; weekly questions 15.
- Week 16: A complete transformer walkthrough and first semester review. Tutorial 16; weekly questions 16.

## Semester 2: retrieval, adaptation and delivery

- Week 17: From word vectors to semantic search. Tutorial 17; weekly questions 17.
- Week 18: A vector database from a list of vectors. Tutorial 18; weekly questions 18.
- Week 19: RAG as an open book question. Tutorial 19; weekly questions 19.
- Week 20: Improving RAG without losing the basic task. Tutorial 20; weekly questions 20.
- Week 21: Evaluating retrieval answers and uncertainty. Tutorial 21; weekly questions 21.
- Week 22: CPU GPU memory and model resource accounting. Tutorial 22; weekly questions 22.
- Week 23: CUDA kernels and profiling. Tutorial 23; weekly questions 23.
- Week 24: Fine tuning starts with a teaching dataset. Tutorial 24; weekly questions 24.
- Week 25: LoRA and QLoRA from a small matrix. Tutorial 25; weekly questions 25.
- Week 26: Fine tuning experiments preferences and distillation. Tutorial 26; weekly questions 26.
- Week 27: Tools functions workflows and agents. Tutorial 27; weekly questions 27.
- Week 28: Harnesses planning memory and bounded execution. Tutorial 28; weekly questions 28.
- Week 29: From a notebook to MLOps and inference serving. Tutorial 29; weekly questions 29.
- Week 30: Monitoring security regression tests and rollback. Tutorial 30; weekly questions 30.
- Week 31: Integrating the documentation assistant and advanced extensions. Tutorial 31; weekly questions 31.
- Week 32: Review defense and a continuing learning plan. Tutorial 32; weekly questions 32.

## Assessment and pacing
After weeks 4 and 8, diagnostic checkpoints identify missing prerequisites. Repeat weeks 6–8 if you cannot yet calculate a weighted mixture and apply a causal mask. The week-16 exam covers language models and transformers and requires no RAG or deployment knowledge.

Weekly questions are 10 points each. Self-grade and correct your reasoning. Tutorial reports use a 10-point rubric: procedure 3, reproduced result 2, controlled variation 2, interpretation 2, reproducibility 1. Semester examinations are 100 points each. Scores are feedback, not certification.

First-semester project: explain and train a tiny causal transformer; submit a shape trace, leakage check, learning curve and architecture ablation. Second-semester project: a documentation assistant measured against a baseline. The final defense asks what helped and which components you chose to release.
