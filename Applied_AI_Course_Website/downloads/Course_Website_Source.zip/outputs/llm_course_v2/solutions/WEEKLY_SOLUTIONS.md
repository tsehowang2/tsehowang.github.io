# Weekly worked solutions

Use the 3 3 4 allocation. Award partial credit for the correct mechanism with a small arithmetic error. For design questions, require a concrete enforcement or measurement point.

## Week 1

1. The prefix is available input such as “I go to school by.” A next-token distribution assigns a probability to each allowed next token; those probabilities sum to one. Training changes counts/parameters from examples. Inference uses the trained model to predict/select a continuation.

2. There are seven examples. Bus=3/7, train=3/7, bicycle=1/7. These estimate this collection, not real-world commuting frequencies.

3. Likelihood reflects learned patterns, not verified personal facts. Exact-prefix counting cannot automatically share evidence between related but unseen prefixes such as school and work.

## Week 2

1. Text is the original string; the tokenizer defines pieces; vocabulary IDs label those pieces; each ID selects a learned numerical row. ID magnitude is not semantic magnitude.

2. The table contains 100×16=1600 parameters. Seven lookups give [7,16], before batch or context processing.

3. The model associates ID 5 with a particular learned row and output label. An inconsistent reassignment changes the computation/interpretation. A consistent joint relabeling is different from swapping the tokenizer alone.

## Week 3

1. Norm=5, unit vector=[0.6,0.8], cosine=0.6.

2. Dot products are .8 and 3, so b wins. Norms are 1 and 5; cosines are .8 and .6, so a wins. Magnitude changes the dot-product ranking.

3. Addition/averaging is invariant to row permutation. Initial lookup uses token identity; a contextual representation also depends on permitted other positions. Position and contextual processing can distinguish ordered sentences.

## Week 4

1. Logits are real scores. Softmax converts them into positive normalized probabilities. Equal logits give [1/3,1/3,1/3].

2. Exponentials are [e²,e,1]≈[7.3891,2.7183,1], sum≈11.1073. Thus p≈[.66524,.24473,.09003]. Cross-entropy is −ln(.24473)≈1.4076 nats. Subtract target one-hot [0,1,0]: gradient≈[.66524,−.75527,.09003].

3. A common exponential factor cancels in numerator/denominator. Subtraction improves stability. The gradient is p minus the target one-hot vector.

## Week 5

1. A fixed window exposes a limited set of positions; recurrence carries a compressed evolving state; attention compares queries with accessible key/value positions. Describe actual dependencies rather than a universal ranking of quality.

2. First states=[1,.5,.25,.125]. Second=[0,0,0,1]. The order changes how many transformations each input undergoes.

3. The task determines available information. The encoder receives a complete input. A next-token prediction cannot use its unavailable future target without leakage.

## Week 6

1. It sums over visible key/value positions for one query, not vocabulary entries or different batch items. Valid softmax rows sum to one.

2. First output=[1.4,1.6]. Second=[1.0,2.6]. Each weight applies to every coordinate of its value vector.

3. A normalized mixture stays v. Weights alone do not determine the informational effect; values and subsequent operations matter.

## Week 7

1. They are learned projected representations serving comparison/query, comparison/key, and mixture-information roles. Their names describe computation.

2. Wq/Wk=[4,2], Wv=[4,3]; Q/K=[6,2], V=[6,3], scores=[6,6], output=[6,3].

3. Changing V changes contributed content with unchanged weights. Changing K changes scores and weights, potentially redistributing several value contributions.

## Week 8

1. I, go, to, school are visible. The representation at school predicts the next token and cannot use future by/bus input positions.

2. Scores≈[.7071,0], weights≈[.66976,.33024], output≈[1.33952,1.32095]. Correct pre-softmax masking gives weights [1,0], output [2,0].

3. Without renormalization the surviving weights sum to less than one and shrink the mixture. For a nonempty allowed set, zeroing forbidden softmax probabilities and renormalizing the survivors is mathematically equivalent to assigning forbidden logits −infinity before softmax, up to numerical error. Perturb a future token with fixed eval-mode computation: earlier outputs must remain equal within tolerance. Verify that an unmasked control changes.

## Week 9

1. No. Heads use different learned projections over the allowed positions, usually partitioning feature computation while each may access all visible keys.

2. d_head=4; Q=[2,3,6,4]; scores=[2,3,6,6]; merged=[2,6,12].

3. Position addition modifies starting features by location. Rotary methods apply position-dependent rotations to query/key coordinate pairs. A causal mask specifies visibility. They address different parts of computation.

## Week 10

1. h=x+Attention(LN(x)); y=h+MLP(LN(h)). Attention mixes positions; the MLP transforms features per position with shared weights.

2. For the specified standard MHA and two-matrix MLP, shapes are [64,256] and [256,64]; MLP parameters=32768 and attention parameters=16384, total=49152. GQA reduces the K/V projection count. A gated MLP with the same d_ff has three matrices and 49152 MLP parameters alone; its width may be adjusted in a real architecture.

3. Addition needs compatible [B,T,d_model] tensors. Without a nonlinearity the maps compose into one linear map.

## Week 11

1. Encoder for a complete-input representation; causal decoder for continuation; encoder-decoder is a common translation arrangement with causal target self-attention and source cross-attention.

2. Scores=[4,7]. Softmax runs over seven source keys for each query. Causal target self-attention instead has [4,4].

3. Training already has the sequence and uses visibility constraints. During generation a selected new token changes the next prefix, so output decisions depend on earlier selections.

## Week 12

1. Input=[3,8,2], targets=[8,2,5]. Causal mask controls information access; loss mask controls supervised prediction positions.

2. Average=(ln2+ln4+ln4)/3≈1.15525; perplexity≈3.1748. Comparisons require compatible tokenization/protocol.

3. Use fixed small data to test implementation, then separate grouped validation examples. Split before overlapping windows and deduplicate near copies. Check shifts and future masking. Overfit success is not generalization.

## Week 13

1. Produce next-token logits from the prefix, select, append, and repeat. Cache earlier layer keys/values when valid under the exact causal prefix/model.

2. For k=2 divide by .8: [.625,.375]. For k=3 divide by .95: approximately [.52632,.31579,.15789].

3. Earlier representations depend on the actual token sequence and model configuration. Length alone does not identify the cached computation. Chat-template or weight changes can invalidate it too.

## Week 14

1. Pretraining learns broad prediction patterns; SFT optimizes desired target responses; prompt demonstrations affect current context without gradient updates; preference methods learn from judged alternatives.

2. Correct total=3*(4+3)-2=19 dollars. Subtracting the 2-dollar voucher from every passenger gives 15 dollars and applies the once-only discount three times. Check the operation and scope, not the fluency of the rationale.

3. Displayed steps are generated text. A correct final answer can accompany an incorrect rationale, and a plausible rationale can be written after an answer was selected. Therefore the text alone does not establish that these steps caused the model output. Faithfulness concerns whether the explanation reflects the actual causal computation; correctness concerns whether its claims and answer are right. Verify the answer independently and use controlled interventions if investigating causality.

## Week 15

1. Autoregression predicts sequential conditionals; VAE learns a probabilistic latent/reconstruction formulation; GAN uses a generator-discriminator game; diffusion learns denoising-related predictions across a corruption schedule.

2. xt=.8×2+.6×(-1)=1. At 0 it is -1 (noise); at 1 it is 2 (signal).

3. The visualization knows the original signal and re-evaluates mixtures. A trained reverse process must generate/denoise from appropriate states using learned predictions; it cannot simply reveal a known source.

## Week 16

1. IDs→token/position representations→normalization/QKV/masked attention/head merge/residual→normalization/MLP/residual, repeated→final normalization/output vocabulary logits.

2. IDs=[2,5]; Q=[2,2,5,4]; scores=[2,2,5,5]; logits=[2,5,20].

3. It may exploit future targets or learn same-token copying. Print input/targets, test causal perturbation, evaluate proper held-out next-token loss and generation. Lower loss on the wrong task is not improvement.

## Week 17

1. Lookup row represents token identity; contextual row depends on permitted context; a sentence embedding uses a representation/pooling objective suited to whole-input comparison.

Marking: token lookup (1); context dependence (1); retrieval objective/pooling (1).

2. The returned IDs intersect gold={H2,H3} in {H2}, so there is one hit. Hit@3=1 because the intersection is nonempty. Recall@3=1 retrieved relevant item / 2 gold items=1/2. A related passage need not provide every required fact.

Marking: one relevant hit (1); Hit@3=1 (1); Recall@3=1/2 (1).

3. Exact API/error names can favor lexical matching; paraphrases can favor semantic representations. Use same-subject wrong-version or bus-departure versus school-opening distractors. Measure actual outcomes.

Marking: lexical case (1); semantic paraphrase (1); hard negative (1); measured comparison (1).

## Week 18

1. Stable IDs, payload/source references, scope/version and content lineage. Mislabeling survives even a correct nearest-neighbor computation.

Marking: stable identity (1); metadata (1); lineage/scope consequence (1).

2. 1,000,000×384=384,000,000 scalar elements. Float32 uses four bytes each, so storage=384,000,000×4=1,536,000,000 bytes, before graph, payloads, IDs, replicas, text, and overhead.

Marking: 1e6×384 elements (1); four bytes/element (1); 1,536,000,000 bytes excluding overhead (1).

3. Build compatible re-embedded collection, verify/benchmark, switch with rollback. Unfiltered top-k may omit eligible relevant points before invalid candidates are removed.

Marking: compatible re-embedding (1); verification (1); switch/rollback (1); post-filter candidate loss (1).

## Week 19

1. Find supporting passages; choose/label what fits; generate a response conditioned on question and evidence. Each boundary can fail independently.

Marking: retrieval (1); selection/budget (1); generation (1).

2. State the supported time and missing fare, or explicitly say the complete question lacks sufficient evidence. Do not fabricate fare or cite time evidence for it.

Marking: time supported (1); fare absent (1); partial answer or insufficiency (1).

3. Enforce eligible sources; verify cited IDs; audit whether each claim follows from them; verify required facts are all addressed. Valid JSON/IDs alone cannot prove grounding.

Marking: scope (1); citation IDs (1); semantic support (1); completeness (1).

## Week 20

1. It sees only its candidate pool; absent necessary evidence cannot be restored by reordering.

Marking: candidate-pool limit (1); missing evidence example (1); retrieval versus ranking distinction (1).

2. A=1/(60+1)+1/(60+10)=1/61+1/70≈.030679. B=1/62+1/62≈.032258. B wins because its summed reciprocal ranks are larger. Scores are rank-derived, not truth probabilities.

Marking: A=1/61+1/70≈.030679 (1); B=2/62≈.032258 (1); B wins (1).

3. Hold corpus/chunks/tasks/filters/generator/budgets/evaluator fixed. Measure candidate recall and final claims, latency, calls and failures; tune on dev only.

Marking: fixed inputs (1); candidate recall (1); answer quality (1); costs and dev-only tuning (1).

## Week 21

1. Correct facts may be incomplete; supported claims must follow from sources; coverage is fraction answered; refusals must match actual absence. Give task-based examples.

Marking: correctness/support distinction (1); completeness (1); coverage/refusal example (1).

2. Selective accuracy=12/15=.8=80%. Coverage=15/20=.75=75%. The denominator differs because selective accuracy conditions on answered tasks. Refusal labels are needed for overall decision correctness.

Marking: 12/15 (1); 15/20 (1); 80% and 75% with correct labels (1).

3. Observed gap=5 points. Inspect fixes/new errors, resample matched tasks with correlation caveats, calibrate judge rubric against reviewed labels and retain failures.

Marking: paired units (1); fixes/regressions (1); uncertainty/correlation (1); judge calibration (1).

## Week 22

1. Weights, gradients, moments, optional master weights, activations/buffers; generation additionally has context-dependent KV state. Device/allocator behavior matters.

Marking: parameters/gradients (1); optimizer/activations (1); generation cache (1).

2. There are two tensors, K and V. Each stores L×B×T×H_kv×d_head elements. Bytes=2×24×1×2048×8×64×2=100,663,296. Divide by 2²⁰ to obtain 96 MiB. This excludes weights and other runtime allocations.

Marking: K and V factor (1); substitution/product (1); 96 MiB (1).

3. Accumulation shrinks microbatch needs but not all persistent state or a single sequence minimum. Checkpointing trades recomputation for some activation storage. Identify the actual component.

Marking: persistent state (1); single sequence limit (1); recomputation tradeoff (1); diagnose component (1).

## Week 23

1. i=blockIdx.x×blockDim.x+threadIdx.x; two blocks give 512 threads; only i<257 accesses arrays.

Marking: index (1); bounds check (1); two blocks/512 threads (1).

2. Unaffected time=20−3=17 ms. The optimized kernel takes3/2=1.5 ms. New total=17+1.5=18.5 ms; speedup=20/18.5≈1.081.

Marking: kernel now 1.5 ms (1); total18.5 ms (1); speedup≈1.081 (1).

3. CPU reference/tolerances and awkward sizes, warmup, synchronization/events, repeated timings/spread, transfer boundary, actual device/software metadata and saved workload/trace.

Marking: correctness (1); warmup and synchronization (1); repeats/spread (1); device/workload/transfer metadata (1).

## Week 24

1. Improve ingestion/retrieval, prompt/schema or targeted SFT for persistent format gaps, and a checked narrow tool for arithmetic. Diagnose before training.

Marking: retrieval intervention (1); format intervention (1); calculator tool (1).

2. Keep prompt as context with ignored labels, supervise answer under the library shift convention, ensure nonzero valid target count and compatible template prefix.

Marking: prompt ignored (1); answer and ending supervised (1); shift/truncation check (1).

3. Split families before paraphrases, review source-backed targets, retain provenance, audit uncertainty/absence and wrong versions, reserve final tasks from tuning/adaptation.

Marking: grouped split (1); reviewed targets/provenance (1); absence/version cases (1); independent evaluation (1).

## Week 25

1. A=[8,4096], B=[4096,8]; 65536 parameters versus 16777216 dense, .390625%.

Marking: factor shapes (1); 65,536 adapter parameters (1); 16,777,216 dense comparison (1).

2. BA=[[.1,.2],[.2,.4]]. Multiplying by the [2,1] column x gives [[.3],[.6]]. Scale alpha/r=2, so the adapter output is [[.6],[1.2]]. These are update-path outputs, before adding frozen Wx.

Marking: BA (1); column output (1); alpha/r scaled output (1).

3. Standard initialization uses random A and zero B. The first gradient can update B; A starts learning after B becomes nonzero. Both factors zero blocks both initial gradients. Frozen-base storage and activations remain. QLoRA adds NF4 base storage, double quantization of quantization constants, and paged optimizers while retaining suitable higher-precision compute and adapter state.

Marking: zero B/random A (1); first gradients (1); remaining memory (1); QLoRA distinctions (1).

## Week 26

1. It measures fit to provided targets. Independent correctness, refusals, semantic arguments and regressions determine release quality.

Marking: fit to targets (1); independent task quality (1); regression example (1).

2. Relative margin=0.4−0.1=0.3. Scaled margin=0.1×0.3=0.03. Sigmoid(0.03)≈0.507499; loss=−ln(0.507499)≈0.67826. Both given values are log-ratios against the reference model, not raw probabilities.

Marking: relative margin (1); scaled margin (1); sigmoid/loss (1).

3. Pin base/data/templates/decoding, control prompt changes, retain paired outputs and failures, save/reload exact artifacts and smoke/evaluate them. Release the stronger qualifying baseline if no gain.

Marking: controlled comparison (1); paired outputs/failures (1); reload equality (1); baseline release if no gain (1).

## Week 27

1. Tool exposes a contracted capability; workflow largely fixes action order; agent lets model outputs influence next actions while controller retains enforcement.

Marking: tool contract (1); fixed workflow (1); adaptive agent (1).

2. Expression 2*4+1*2 is proposed; validated calculator returns 10; final response must match and use correct price evidence.

Marking: expression (1); observation 10 (1); price evidence/final answer (1).

3. Reject unknown tools, extra keys, booleans as strict integers, unsupported AST nodes, numeric/size violations and wrong scope. Domain-invalid config differs from invalid call schema; never eval model code.

Marking: schema/name (1); strict types/scope (1); AST/numeric bounds (1); negative tests (1).

## Week 28

1. Execution runs controlled state/actions; evaluation checks tasks. History, structured current task state, and persistent memory have different provenance/retention/trust.

Marking: execution/evaluation (1); task state/history (1); persistent memory (1).

2. Stop with budget_exhausted after at most the allowed proposals. A step cap alone does not interrupt blocking calls or bound all time/memory/token use.

Marking: at most cap (1); budget_exhausted (1); blocking/resource limits (1).

3. Same tasks/tools/budgets; independent state/result predicates; call/scope failures, forbidden actions, costs and termination. Audit traces, including accidental-looking final success and unnecessary actions.

Marking: fixed comparison (1); independent predicates (1); forbidden actions/termination (1); cost and traces (1).

## Week 29

1. Corpus/chunker, embeddings/index, tokenizer/adapter, prompt, tools, environment, evaluation records and configs; identify changed-dependency effects.

Marking: data/index (1); model/tokenizer/adapter (1); prompt/tools/environment/evaluation (1).

2. Average=6 under stable matching boundaries. This does not specify worker count, p95, or saturation behavior.

Marking: L=lambda×W (1); six average in flight (1); stability and boundary (1).

3. Pin each version’s artifacts and test request schema, scope, invalid inputs and timeouts. Measure the LLM path with recorded prompt/output lengths, concurrency, warm/cold state and raw timings. Excerpt-return timings measure retrieval and API overhead; they do not measure LLM prefill/decode or predict its tail latency. Reproduce both configurations in a clean environment.

Marking: API controls (1); LLM workload protocol (1); timing distinction (1); clean reproduction (1).

## Week 30

1. Latency/errors/queues; evidence/answer/refusal measures; event logs; connected per-request spans. Interpret traffic/corpus changes and protect logged content.

Marking: operational signals (1); quality signals (1); logs versus spans (1).

2. The source/index/context/cache dependencies can remain malicious. Restore a coherent release or remove/rebuild/invalidate affected artifacts and verify.

Marking: source/index persists (1); cache/context persists (1); coherent restoration and verification (1).

3. Authorize/validate outside text, scope caches and source fetches, enforce typed tools, run invariant and quality gates, retain compatible rollback and meaningful incident regression tests.

Marking: authorization outside text (1); cache/source scope (1); tool validation (1); gates/rollback regression (1).

## Week 31

1. Preserve scope, retrieve both required rules, pack sources, perform validated tool work if needed, form claims, validate/audit support and task success.

Marking: scope/evidence (1); context and execution (1); checked response (1).

2. 1/(.3+.7/4)=2.1053 before communication/coordination overhead.

Marking: serial=.3 (1); 1/(.3+.7/4) (1); 2.11 ideal (1).

3. Use the stronger qualifying retrieval/base/workflow configuration; retain measured experimental branches, report uncertainty and limits, choose a focused next experiment rather than inventing gains.

Marking: qualifying baseline (1); paired evidence (1); cost and uncertainty (1); limits/next experiment (1).

## Week 32

1. Tokenize the prefix, look up embeddings, add position information, run causally masked transformer blocks, normalize and project to vocabulary logits, then softmax/select the next token. A RAG application separately retrieves “[H2] The bus leaves at 07:30,” packs it with the question and asks the generator to cite H2. Model token prediction and external evidence selection are distinct boundaries.

Marking: token-to-logit mechanism (1); external evidence path (1); distinction between prediction and support (1).

2. A=12/20=60%; B=16/20=80%. Net gain=(7−3)/20=20 percentage points, consistent with four additional successes. B fails the stated gate because it produces a wrong-version answer, even though average success is higher.

Marking: rates60%/80% (1); net20 percentage points (1); reject B under the stated gate (1).

3. Model defense: choose the qualifying hybrid retriever, base generator and fixed workflow. Demonstrate a supported departure answer with its source, an absent fare with an honest insufficiency response, and a wrong-version tool proposal rejected before execution. Supply pinned component identities, setup commands, checked task labels, paired raw outputs and traces from a clean reproduction. Retain the adapter/agent negative results. Next, test whether reranking fixes the observed paraphrase misses under the same context and latency budgets; record candidate recall and final support separately. This is an example defense, not a claim that these results were measured for the learner.

Marking: justified configuration (1); three concrete cases (1); reproduction/evidence (1); focused controlled next experiment (1).

