# Examination solutions
Give partial credit for a correct method with a minor arithmetic mistake. Open questions admit multiple justified answers.

## Checkpoint calculations
A1: [.6,.2,.2]. A2: one vocabulary is I=0, go=1, to=2, school=3, by=4, bus=5; inputs [0,1,2,3,4], targets [1,2,3,4,5]. A3: dot products 2 and 1; cosines 1 and 1/sqrt(2). A4: [.5,.5], loss ln(2)=.6931. B1: [.5,3]. B2: Q/K/V [8,16], scores [8,8], output [8,16]. B3: future positions must get zero probability after normalization; post-softmax deletion without renormalization breaks the mixture. B4: keep model fixed in eval mode, change a future token, compare earlier outputs within numerical tolerance.

## Semester exam 1
**Q1 (15).** Inputs I/go/to/school/by, targets go/to/school/by/bus. Each prefix predicts the following token (5). IDs are arbitrary row indices; vectors are learned representations. Renumbering IDs with corresponding table-row permutation must preserve meaning (5). -ln(.2)=1.6094 nats. Lower loss means more probability on the observed target, not proof of factual truth (5).

**Q2 (20).** Divide by sqrt(4)=2: [1,0]. Stable exponents [1,.367879], normalized [.731059,.268941]. Output [1.462118,1.075764]. Scaling 2, weights 4, output 4 (10 total). Masked scores [1,-infinity], probabilities [1,0], output [2,0] (6). Q asks what is needed, K is scored for compatibility, V supplies the mixed payload; distinct projections enable the roles (4).

**Q3 (20).** Q/K/V [2,8,128,32], scores [2,8,128,128], head output [2,8,128,32], merged [2,128,256] (8). 262144 elements times four =1048576 bytes=1 MiB (4). x becomes x+Attention(LN(x)), then x+MLP(LN(x)); MLP acts per position and residual preserves a direct path (4). Position supplies order/location; masking prevents future leakage. Neither generally replaces the other (4).

**Q4 (20).** Shift batches; forward with causal mask; flatten position/vocabulary logits against aligned target IDs; cross entropy; zero gradients; backward; optional clipping; optimizer step (8). Future perturbation must preserve earlier logits with fixed parameters/eval mode; a tiny one-batch dataset should be overfittable as a wiring diagnostic (6). Split source groups before making overlapping windows. Memorization and leakage can lower training loss without useful generalization (6).

**Q5 (15).** Greedy selects the maximum; sampling draws from a distribution. Divide logits by positive temperature: lower sharpens, higher flattens. Neither guarantees a globally best sequence (5). The cache stores prior keys/values, avoiding recomputation; parameters remain fixed (4). Pretraining learns continuation; instruction SFT updates parameters from desired responses, commonly applying loss to response tokens (3). A rationale is generated text; verify answers independently with controlled comparisons (3).

**Q6 (10).** Autoregression predicts discrete image tokens sequentially; diffusion learns a reverse/denoising process with a noise schedule (4). One investigation: move a synthetic dependency to increasing distances, holding architecture, data count and training budget fixed. Report held-out accuracy, context constraints and limits of a tiny synthetic task. Limitation 2, controls/design 3, interpretation 1 (6).

## Semester exam 2

**Q1 (20).** A=[16,4096], B=[2048,16]. Adapter=16×(4096+2048)=98,304; dense=2048×4096=8,388,608; ratio=.01171875=1.171875% (8). Random A and zero B yield zero initial delta. B can receive the first gradient; A starts learning after B changes. Both zero block both initial factor gradients (4). LoRA trains factors on frozen base; QLoRA additionally quantizes frozen base, retaining higher-precision compute/state where required (4). Base/tokenizer revision, adapter config/weights, target modules, environment, training data/config and eval metadata; four distinct dependencies (4).

**Q2 (15).** Same model/base/context/tasks/decoding/tool validator, separate prompt control, per-task valid JSON and semantic argument correctness, invalid/forbidden actions and budgets; reject if incorrect actions violate gate even though syntax improved (8). Dataset may reward valid format with wrong arguments, omit negative/refusal cases, include wrong-version labels or have leaked paraphrases; two diagnosed causes (4). Loss is fit to labels, and biased/wrong labels can be learned successfully (3).

**Q3 (20).** Initialize scope/state/budgets; for finite steps call planner with controlled context; parse and validate proposal; final validates citations/contract then terminates; tool action validates name/schema/authority/limits, executes with per-call enforcement, records normalized result; catches typed failures; exhausts explicitly. Six meaningful controls/branches at 2 points each (12). A blocking call can exceed wall time before loop checks; real client timeout/process enforcement needed (4). Reject IDs not authorized/observed; existing IDs still do not prove semantic entailment (4).

**Q4 (20).** Incompatible coordinate systems make old vectors unsuitable; missing tenant cache scope can expose restricted answers (6). Manifest embeds model/index/source compatibility, rebuild versioned index, benchmark/switch/rollback; scope-aware cache keys, permission enforcement and invalidation (8). Tests deliberately mismatch embedding manifest and cross tenant requests; roll back coherent prompt/model/adapter/index/tool/corpus config, not weights alone (6).

**Q5 (15).** L=1.5×4=6 average in system, assuming stable averages and correct boundary (4). TTFT until first output token; end-to-end until response finishes including all application stages (3). 1/(.2+.8/4)=2.5 ideal speedup (4). Tail latency depends on variance/load/queueing and distributed work has communication/coordination; no p95 prediction from these means (4).

**Q6 (10).** Prefer qualifying retriever plus fixed workflow/base generator if agent/adapter add no demonstrated value; retain experimental branches and raw comparisons, report budget/quality/safety and actual negative results (6). Limits could be task-set size, small model capability, lack of real users or untested high concurrency. Next experiment must target an observed failure with a control and metric, e.g. reranking the paraphrase misses under a fixed context budget (4).
