# Examination solutions
Give partial credit for a correct method with a minor arithmetic mistake. Open questions admit multiple justified answers.

## Checkpoint calculations
A1: [.6,.2,.2]. A2: I→go(1); I go→to(2); I go to→school(3); I go to school→by(4); I go to school by→bus(5). A3: dot products 2 and 1; cosines 1 and 1/sqrt(2). A4: [.5,.5], loss ln(2)=.6931. B1: [.5,3]. B2: Q/K/V [8,16], scores [8,8], output [8,16]. B3: pre-softmax masking gives zero probability to forbidden positions. Post-softmax zeroing without renormalization shrinks total mass; zeroing then renormalizing is equivalent for a nonempty allowed set, up to numerical error. B4: keep model fixed in eval mode, change a future token, compare earlier outputs within numerical tolerance.

## Semester exam 1
**Q1 (15).** Inputs I/go/to/school/by, targets go/to/school/by/bus. Each prefix predicts the following token (5). IDs index learned rows (1). Norm([3,4])=5, cosine=3/5=.6, a direction comparison (2). Mean NLL=(ln2+ln4)/2≈1.03972, perplexity=exp(1.03972)≈2.82843 (2). -ln(.2)=1.6094 nats. Lower loss means more probability on the observed target, not proof of factual truth (5).

**Q2 (20).** Divide by sqrt(4)=2: [1,0]. Stable exponents [1,.367879], normalized [.731059,.268941]. Output [1.462118,1.075764]. Scaling 2, weights 4, output 4 (10 total). Masked scores [1,-infinity], probabilities [1,0], output [2,0] (6). Q asks what is needed, K is scored for compatibility, V supplies the mixed payload; distinct projections enable the roles (4).

**Q3 (20).** Q/K/V [2,8,128,32], scores [2,8,128,128], head output [2,8,128,32], merged [2,128,256] (8). 262144 elements times four =1048576 bytes=1 MiB (4). x becomes x+Attention(LN(x)), then x+MLP(LN(x)); MLP acts per position and residual preserves a direct path (4). Attention matrices=4×64²=16,384; MLP=2×64×256=32,768; total49,152. GQA changes K/V count or a gated MLP adds a matrix (4).

**Q4 (20).** Shift batches; forward with causal mask; flatten position/vocabulary logits against aligned target IDs; cross entropy; zero gradients; backward; optional clipping; optimizer step (8). Future perturbation must preserve earlier logits with fixed parameters/eval mode; a tiny one-batch dataset should be overfittable as a wiring diagnostic (6). Split source groups before making overlapping windows. Memorization and leakage can lower training loss without useful generalization (6).

**Q5 (15).** Greedy selects the maximum; sampling draws from probabilities; lower temperature sharpens (2). Top-k=2 retains .5,.3, divides by .8 and gives [.625,.375,0,0]. Top-p=.7 reaches the threshold with the same two entries and gives the same distribution (3). The cache stores prior keys/values, avoiding recomputation; parameters remain fixed (4). Pretraining learns continuation; instruction SFT updates parameters from desired responses, commonly applying loss to response tokens (3). A rationale is generated text; verify answers independently with controlled comparisons (3).

**Q6 (10).** Autoregression predicts image tokens; diffusion learns a reverse/noise-prediction process (3). Recurrence updates a compressed state; repeated Jacobians can shrink gradients; LSTM/GRU gates regulate information flow (3). Encoder self-attention sees the whole input; decoder self-attention sees the prefix; encoder-decoder adds target queries over source K/V (4).

## Semester exam 2

**Q1 (20).** A=[16,4096], B=[2048,16]. Adapter=16×(4096+2048)=98,304; dense=2048×4096=8,388,608; ratio=.01171875=1.171875% (8). Random A and zero B yield zero initial delta. B can receive the first gradient; A starts learning after B changes. Both zero block both initial factor gradients (4). LoRA trains factors on frozen base; QLoRA additionally quantizes frozen base, retaining higher-precision compute/state where required (4). Base/tokenizer revision, adapter config/weights, target modules, environment, training data/config and eval metadata; four distinct dependencies (4).

**Q2 (15).** Same model/base/context/tasks/decoding/tool validator, separate prompt control, per-task valid JSON and semantic argument correctness, invalid/forbidden actions and budgets; reject if incorrect actions violate gate even though syntax improved (8). DPO relative margin=.4−.1=.3, scaled=.03; loss=log(1+exp(−.03))≈.67826 (4). Soft-target distillation learns the teacher distribution across classes, including relative alternatives; hard-label SFT supervises one target. Teacher errors can transfer and require independent evaluation (3).

**Q3 (20).** Initialize scope/state/budgets; for finite steps call planner with controlled context; parse and validate proposal; final validates citations/contract then terminates; tool action validates name/schema/authority/limits, executes with per-call enforcement, records normalized result; catches typed failures; exhausts explicitly. Six meaningful controls/branches at 2 points each (12). A blocking call can exceed wall time before loop checks; real client timeout/process enforcement needed (4). Reject IDs not authorized/observed; existing IDs still do not prove semantic entailment (4).

**Q4 (20).** Incompatible coordinate systems make old vectors unsuitable; missing tenant cache scope can expose restricted answers (6). Manifest embeds model/index/source compatibility, rebuild versioned index, benchmark/switch/rollback; scope-aware cache keys, permission enforcement and invalidation (8). Tests deliberately mismatch embedding manifest and cross tenant requests; roll back coherent prompt/model/adapter/index/tool/corpus config, not weights alone (6).

**Q5 (15).** K and V give factor2; 2×24×1×2048×8×64×2=100,663,296 bytes=96 MiB (4). CUDA i=blockIdx.x*blockDim.x+threadIdx.x; ceil(257/256)=2 blocks; access only if i<257 (3). Amdahl=1/(.2+.8/4)=2.5; ignores communication and cannot predict queueing/tail latency (4). Recall=1/2; first relevant rank2 gives reciprocal rank1/2. B is absent from the candidate pool, so a reranker cannot add it (4).

**Q6 (10).** Prefer qualifying retriever plus fixed workflow/base generator if agent/adapter add no demonstrated value; retain experimental branches and raw comparisons, report budget/quality/safety and actual negative results (6). RRF(A)=1/61+1/70≈.030679; RRF(B)=2/62≈.032258, so B wins (4).
