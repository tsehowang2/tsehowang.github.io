// Compile with nvcc -O2 vector_add.cu -o vector_add
#include <cuda_runtime.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess) { \
  std::fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); std::exit(1); }} while(0)
__global__ void add(const float* a,const float* b,float* c,int n) {
  int i=blockIdx.x*blockDim.x+threadIdx.x;
  if(i<n) c[i]=a[i]+b[i];
}
int main(int argc,char** argv) {
  int n=argc>1?std::atoi(argv[1]):1048576;
  if(n<1||n>16777216) return 2;
  std::vector<float>a(n),b(n),c(n);
  for(int i=0;i<n;i++){a[i]=i*0.001f;b[i]=1.0f;}
  float *da,*db,*dc;size_t bytes=n*sizeof(float);
  CHECK(cudaMalloc((void**)&da,bytes));CHECK(cudaMalloc((void**)&db,bytes));CHECK(cudaMalloc((void**)&dc,bytes));
  CHECK(cudaMemcpy(da,a.data(),bytes,cudaMemcpyHostToDevice));
  CHECK(cudaMemcpy(db,b.data(),bytes,cudaMemcpyHostToDevice));
  int blocks=(n+255)/256;
  for(int j=0;j<10;j++) add<<<blocks,256>>>(da,db,dc,n);
  CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());
  cudaEvent_t start,stop;CHECK(cudaEventCreate(&start));CHECK(cudaEventCreate(&stop));
  CHECK(cudaEventRecord(start));
  for(int j=0;j<100;j++) add<<<blocks,256>>>(da,db,dc,n);
  CHECK(cudaGetLastError());CHECK(cudaEventRecord(stop));CHECK(cudaEventSynchronize(stop));
  float ms;CHECK(cudaEventElapsedTime(&ms,start,stop));
  CHECK(cudaMemcpy(c.data(),dc,bytes,cudaMemcpyDeviceToHost));
  float worst=0;for(int i=0;i<n;i++) worst=std::fmax(worst,std::fabs(c[i]-(a[i]+b[i])));
  std::printf("n=%d mean_kernel_ms=%.6f max_absolute_error=%.8f transfers_excluded=1\n",n,ms/100,worst);
  CHECK(cudaEventDestroy(start));CHECK(cudaEventDestroy(stop));
  CHECK(cudaFree(da));CHECK(cudaFree(db));CHECK(cudaFree(dc));
  return worst<1e-4f?0:3;
}
