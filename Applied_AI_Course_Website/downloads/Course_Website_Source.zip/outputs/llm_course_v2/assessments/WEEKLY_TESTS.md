# Weekly practice

Each week has three questions from introductory explanation to calculation and deeper reasoning. Attempt them before opening solutions. Q1 is 3 points, Q2 3 points, and Q3 4 points. Explain assumptions and units.

## Week 1

1. Explain a prefix, a next-token distribution, training, and inference using “I go to school by bus.”
2. Five matching examples contain bus three times, train once, and bicycle once. Add two train examples. Calculate the new probabilities.
3. Explain why a likely completion is not evidence of a particular person’s actual commute. Name a limitation of exact-prefix counting.

## Week 2

1. Distinguish text, tokens, token IDs, and embedding rows.
2. A vocabulary has 100 entries and width 16. Count embedding parameters and give the representation shape for seven tokens.
3. Explain why changing which token ID 5 represents without updating the trained model breaks compatibility.

## Week 3

1. For [3,4], calculate norm, unit vector, and cosine with [1,0].
2. Compare q=[1,0] with a=[0.8,0.6] and b=[3,4] under raw dot product and cosine.
3. Explain why averaging token rows loses word order, and distinguish initial from contextual representations.

## Week 4

1. What is the difference between logits and probabilities? Compute softmax([0,0,0]).
2. For logits [2,1,0] and target train at index 1, estimate probability and cross entropy.
3. Explain why subtracting the largest logit preserves softmax, and give the cross-entropy logit-gradient rule.

## Week 5

1. Compare a fixed window, a recurrent state, and attention as ways to supply context.
2. Starting at zero, compute h_t=.5h_(t-1)+x_t for [1,0,0,0] and [0,0,0,1].
3. Why can a complete-input encoder use words to the right while a next-token decoder must constrain access?

## Week 6

1. What does a row of attention weights sum over?
2. Mix [2,0],[0,4],[2,2] with weights [.5,.3,.2], then [.2,.5,.3].
3. If all value vectors equal v, what happens when weights change? What does this show about attention explanations?

## Week 7

1. Explain query, key, and value without treating them as literal human questions and answers.
2. X has [6,4], d_head=2, d_value=3. Give projection, Q/K/V, score, and output shapes.
3. Keep Q/K fixed and double one V vector. Then instead change one K row. Explain the difference.

## Week 8

1. For a causal query at school in “I go to school by bus,” list visible tokens.
2. Compute scaled attention for q=[1,0], K=[[1,0],[0,1]], V=[[2,0],[0,4]], d_head=2. Then mask key 2.
3. Why is zeroing a probability after softmax insufficient? Specify a causal property test.

## Week 9

1. Do multiple heads split words into independent sentence segments?
2. For B=2,T=6,d_model=12,H=3, give head width, Q shape, score shape, and merged output shape.
3. Distinguish learned position addition, rotary position ideas, and a causal mask.

## Week 10

1. Name the two pre-norm block sublayers and residual additions.
2. For standard MHA with d_model=64 and a two-matrix MLP with d_ff=4*d_model, give MLP matrix shapes and the matrix-only block parameter count. State why that count changes for GQA or a three-matrix gated MLP.
3. Explain why residual outputs must match shape, and why two linear MLP maps need a nonlinearity for richer transformation.

## Week 11

1. Choose an architecture for complete-input representation, continuation, and translation.
2. For four target positions and seven source positions, give cross-attention score shape and normalization axis.
3. Why can masked training compute many target positions together while generation still selects outputs sequentially?

## Week 12

1. Shift input and target IDs from [3,8,2,5]. Distinguish causal and loss masks.
2. Compute average NLL and perplexity for correct-token probabilities [.5,.25,.25].
3. Design a one-batch overfit diagnostic followed by a valid evaluation, identifying two leakage risks.

## Week 13

1. Describe one autoregressive step and what the KV cache retains.
2. Renormalize probabilities [.5,.3,.15,.05] under top-k=2 and top-k=3.
3. Why does changing an earlier token invalidate cached state even if prefix length stays identical?

## Week 14

1. Distinguish pretraining, SFT, in-context examples, and preference learning.
2. Three passengers each need a 4-dollar outbound ticket and a 3-dollar return ticket. A group voucher removes 2 dollars once. Calculate the total and describe a fluent but wrong solution.
3. Why are displayed reasoning steps neither proof of correctness nor a faithful guaranteed account of internal causality?

## Week 15

1. Compare autoregression, VAE, GAN, and diffusion by their generation/training roles.
2. For x0=2, epsilon=-1, alpha_bar=.64 compute xt and the endpoints alpha_bar=0 and 1.
3. Why does moving a forward-noising slider backward not demonstrate learned image generation?

## Week 16

1. Trace the sentence prefix through a complete causal transformer without skipping embedding, position, block, or output stages.
2. For B=2,T=5,d_model=8,H=2,V=20, give IDs, head-Q, scores, and final-logit shapes.
3. A model improves loss after unmasking and training unshifted labels. Explain why that is inconclusive and propose checks.

## Week 17

1. Distinguish a token embedding, contextual representation, and retrieval sentence embedding.
2. Gold={H2,H3}; results=[H1,H2,H4]. Compute Hit@3 and Recall@3.
3. Design one lexical-friendly and one dense-friendly question, plus a hard negative.

## Week 18

1. Name what a database stores beyond vectors and why metadata matters.
2. Calculate raw storage for one million 384-dimensional float32 vectors.
3. Explain an embedding migration and why post-filtering a short top-k may fail.

## Week 19

1. Explain the roles of retrieval, context selection, and generation with the school handbook.
2. A time-and-fare question has only a departure passage available. What answer behavior is justified?
3. Specify checks for scope, citation structure, semantic support, and completeness.

## Week 20

1. Why can reranking fail even with an excellent relevance model?
2. With c=60, compare RRF for A ranks (1,10) and B ranks (2,2).
3. Design a controlled lexical/dense/hybrid/reranked comparison.

## Week 21

1. Distinguish correctness, support, completeness, coverage, and appropriate refusal.
2. A answers 15/20, with 12 correct answers. Calculate selective accuracy and coverage.
3. Two systems solve 32 and 34 of the same 40 tasks. Explain paired comparison and judge calibration.

## Week 22

1. List major training and generation memory components.
2. Compute KV bytes for L24,B1,T2048,H_kv8,d_head=64,b2.
3. Why can accumulation fail to fix OOM? Compare it with checkpointing.

## Week 23

1. Give the one-dimensional CUDA index and bounds check for n=257 with 256 threads/block.
2. A 20 ms task contains a 3 ms kernel. Halve the kernel time and calculate total/speedup.
3. Specify a defensible GPU benchmark.

## Week 24

1. Choose likely interventions for missing evidence, format failure, and calculation error.
2. Describe answer-only loss labels and a truncation check.
3. Design a grouped SFT dataset with refusal cases and an independent evaluation.

## Week 25

1. For W[4096,4096], rank8, give A/B shapes and trainable count.
2. For A=[.1,.2] and B=[[1],[2]], compute BA and BA×[1,1].
3. Explain initialization, remaining memory, and QLoRA differences.

## Week 26

1. Why does decreasing SFT loss not establish an application improvement?
2. Preferred/reference log change=.4; rejected=.1; beta=.1. Calculate DPO scaled margin and loss.
3. Design a base/adapter comparison including a negative result and a reload check.

## Week 27

1. Distinguish a tool, workflow, and agent.
2. Calculate two 4-dollar tickets plus one 2-dollar ticket. Identify proposal and observation.
3. Name validation and safety tests for a bounded calculator/config tool.

## Week 28

1. Distinguish execution and evaluation harnesses and three memory lifetimes.
2. An endless planner has a three-proposal cap. What must happen, and what remains unbounded without other controls?
3. Design trace-level agent evaluation against a fixed workflow.

## Week 29

1. List release dependencies beyond model weights.
2. At 2 requests/s and 3 seconds average time in system, estimate in-flight work and limitations.
3. Design an API/load/reproduction check that distinguishes extraction baseline timings from real LLM service results.

## Week 30

1. Distinguish operational metrics, quality signals, logs, and traces.
2. Why does model-only rollback fail after malicious source ingestion?
3. Design enforcement against retrieved instructions, cache leakage, and regression release failures.

## Week 31

1. Explain one complete version-aware documentation task from question to checked response.
2. With 70% scalable and 30% serial work, calculate ideal four-way speedup.
3. Design a capstone release choice when agent and adapter add cost without reliable quality improvement.

## Week 32

1. Connect a sentence-completion transformer with a RAG/tool application while distinguishing their boundaries.
2. List artifacts and observations supporting an honest personal-project delivery claim.
3. Give a defense and continuing-learning plan based on the project’s actual weaknesses.
