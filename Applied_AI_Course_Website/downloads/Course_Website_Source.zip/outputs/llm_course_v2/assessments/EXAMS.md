# Examinations
Two hours per semester exam, 100 points. Closed notes; a calculator and blank Python interpreter are permitted. No LLM or internet. Show reasoning, assumptions and units. Checkpoints are diagnostic.

## Checkpoint A after week 4
Twenty minutes. (1) Estimate next-word probabilities from three bus, one train and one bicycle sentences. (2) Use vocabulary I=0, go=1, to=2, school=3, by=4, bus=5. For each prefix of “I go to school by bus” ending before bus, give its next-token target ID. (3) Compare dot product and cosine of [1,0] with [2,0] and [1,1]. (4) Compute softmax and target negative log likelihood for two equal logits. Repair missing concepts before week 5.

## Checkpoint B after week 8
Twenty minutes. (1) Mix [2,0] and [0,4] with weights .25 and .75. (2) Give Q/K/V and score shapes for T=8,d_model=32,d_head=16. (3) Compare masking scores before softmax with zeroing probabilities after softmax, with and without renormalization. (4) Describe a future-token perturbation check. Repair missing concepts before week 9.

## Semester exam 1

### Question 1 Language modeling and representations 15 points
Using “I go to school by bus,” explain next-token training and give shifted inputs/targets (5). Distinguish token IDs from embeddings; calculate cosine([3,4],[1,0]) and interpret it (3). For correct-token probabilities [.5,.25], calculate mean NLL and perplexity (2). For label order [bus, train, bicycle] and probabilities [.6,.2,.2], calculate negative log likelihood when train is the target and interpret lower loss (5).

### Question 2 Attention by hand 20 points
A query produces unscaled scores [2,0] with d_head=4 and values [2,0] and [0,4]. Calculate scaled scores, stable softmax and the mixed output (10). Mask the second key as a future position and recalculate (6). Explain the different roles of Q, K and V even when they come from the same input (4).

### Question 3 Transformer architecture 20 points
For B=2,T=128,d_model=256,H=8 give split Q/K/V, score, per-head output and merged output shapes (8). Compute explicitly stored float32 score memory in bytes and MiB (4). Explain residual, normalization and positionwise MLP paths in a pre-normalized block (4). Count attention-plus-MLP matrices for standard MHA d_model=64 and a two-matrix MLP of width256, excluding biases/norms; state one variant that changes this (4).

### Question 4 Training a tiny transformer 20 points
Give training-loop pseudocode with shifted labels, causal masking, cross entropy, backward pass and optimizer update (8). Describe a future-token perturbation check and a one-batch overfit diagnostic (6). Explain grouped train/dev splitting and why lower training loss does not prove generalization (6).

### Question 5 Generation and instruction following 15 points
Compare greedy and sampling with temperature (2). For [.5,.3,.15,.05], calculate top-k=2 and top-p=.7 distributions using the smallest sorted prefix reaching the threshold (3). Explain what a KV cache stores and why it speeds decoding without learning new facts (4). Distinguish pretraining from instruction SFT (3). Explain why fluent chain-of-thought text does not establish correctness (3).

### Question 6 Beyond text and experimental reasoning 10 points
Compare autoregressive image-token generation with diffusion (3). Explain recurrent state, vanishing gradients, and the purpose of LSTM/GRU gates (3). Contrast encoder-only, decoder-only and encoder-decoder visibility (4).

## Semester exam 2

### Question 1 Adaptation 20 points

For W shaped [2048,4096] and LoRA rank 16, give A/B shapes and parameter counts, dense count and adapter/dense ratio (8). Explain zero-update initialization (4). Contrast LoRA and QLoRA without assuming four-bit activations (4). Name saved dependencies for adapter reproduction (4).

### Question 2 Fine-tuning study 15 points

A new adapter improves exact tool JSON from 75% to 95% but increases incorrect tool arguments from 5% to 20%. Design a controlled evaluation and release decision (8), calculate DPO loss for preferred/reference log-ratio .4, rejected/reference log-ratio .1 and beta=.1 (4), and explain soft-target distillation versus SFT on a hard label (3).

### Question 3 Agent controller 20 points

Write pseudocode for a bounded model/tool loop with typed proposals, schema checks, scope checks, observations and terminal statuses (12). Explain why a step cap is not a call timeout (4). Explain how an invented but valid-looking citation must be handled and what checking its ID cannot establish (4).

### Question 4 MLOps and security 20 points

After changing the embedding model, developers reuse the old vectors and omit tenant scope from answer-cache keys. Explain both failures (6), propose manifest/index migration and cache controls (8), and define regression tests and rollback unit (6).

### Question 5 Performance and scaling 15 points

Calculate KV-cache MiB for L=24 layers, B=1 batch, T=2048 tokens, H_kv=8 K/V heads, d_head=64 and 2-byte elements, explaining the K/V factor (4). For n=257 and 256 threads/block, give CUDA index, block count and bounds check (3). Calculate ideal four-way speedup for 80% scalable work and state why it does not predict p95 (4). For gold={A,B}, results=[C,A,D], calculate Recall@3 and reciprocal rank; explain why reranking cannot recover B (4).

### Question 6 Capstone defense 10 points

Your agent is more expensive than the fixed workflow, your adapter shows no reliable improvement, and your retriever measurably improves paraphrase questions. Choose a default release and justify it with the evidence you would present (6). With c=60 compare RRF for A at ranks(1,10) and B at ranks(2,2), and choose the higher fused result (4).
