# Validation and limits

All 32 notebooks and companion scripts passed syntax checks. In this revision, 13 CPU-safe complete tutorial paths and a separate DPO arithmetic check passed. The tutorial-30 run also passed all 23 support contract tests. Optional model-download blocks were disabled for these CPU checks. Hand calculations for attention, RoPE, parameter counts, contrastive loss, nDCG, McNemar, memory, bandwidth, DPO and energy were independently recomputed.

Model downloads, actual transformer/adapter training, Qdrant model execution, CUDA compilation/profiling, production serving and actual model-agent runs were not executed in this revision environment. Their updated recipes are syntax checked. Hardware, package and model compatibility must still be verified in the runtime used for the exercise. Fixture results and paper calculations are labeled separately from trained-model measurements. Notebook outputs are distributed empty.
