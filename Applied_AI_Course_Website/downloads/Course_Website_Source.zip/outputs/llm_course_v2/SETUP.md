# Setup and compute

## Read first

The website uses static HTML, CSS and JavaScript. Reading, slides, search, worked solutions, diagrams and progress tracking require no Python installation or paid service. Code runs separately on your computer or Colab.

## Choose a supported Python environment

For a new course environment, start with Python 3.12 or 3.13 in a virtual environment. Python 3.11 remains a supported fallback for a dependency that needs it. Python 3.10 reached end of life on 1 October 2026, so it is no longer the recommendation for a new installation [R31].

Python 3.14 is supported by the current PyTorch installation documentation. Check that NumPy, Transformers, Sentence Transformers, PEFT, Qdrant and any accelerator package used by the selected lab all provide compatible versions before choosing it. Python 3.15 is a newer Python release, but a language release does not itself establish compatibility with a machine-learning environment [R31, R32].

Install NumPy for numerical lessons. Use the PyTorch installation selector for your operating system and CPU or CUDA runtime, then run a small tensor operation and check torch.cuda.is_available() when using a GPU. A successful import is the first environment check; the lab result is a separate check. Colab normally includes NumPy and PyTorch, but record the versions in the assigned session [R32].

Extract the full course ZIP. Its root contains coursekit, data, notebooks and tests. From that root run python -m unittest discover -s tests -v. In Colab, upload the ZIP, unzip it into /content/llm_course, and run the bootstrap cell. The cell also searches for an extracted llm_course_v2 folder. A lone notebook still needs its support files.

## Models for English and Hong Kong Chinese examples

The default bilingual retrieval route uses intfloat/multilingual-e5-small: 384-dimensional vectors and an input limit of 512 tokens. Prefix retrieval questions with “query: ” and passages with “passage: ”, including Chinese text, then normalize embeddings for cosine or equivalent dot-product ranking. These prefixes belong to this model, not to every embedding model. Include English, Traditional Chinese and cross-language question-passage pairs in your own evaluation [R33].

The newer small generator route uses Qwen/Qwen3-0.6B. It requires Transformers 4.51.0 or later. For the ordinary answer and JSON-tool exercises, pass enable_thinking=False to apply_chat_template, because this model otherwise enables thinking by default. Keep the model ID, model revision and chat-template settings together in the run record [R34].

| Model route | Role and limit |
|---|---|
| intfloat/multilingual-e5-small | Bilingual retrieval default; 384 dimensions; at most 512 input tokens; model-specific query and passage prefixes. |
| Qwen/Qwen3-0.6B | Small generator; explicit non-thinking mode for the ordinary tool and answer route. |
| sentence-transformers/all-MiniLM-L6-v2 | Legacy English baseline; 384 dimensions; default truncation beyond 256 word pieces. |
| Qwen/Qwen2.5-0.5B-Instruct | Legacy small-generator baseline retained for reproducing earlier course runs. |

The legacy models remain useful controls: age alone does not invalidate a baseline. They are labeled explicitly so a bilingual experiment is not accidentally judged only with an English embedding model. A model change normally requires new embeddings, a compatible index and a fresh evaluation; it is not a filename substitution [R22, R23, R33, R34].

## Match the lab to available hardware

Use CPU for hand-calculation checks, metric arithmetic, small vector searches and controller tests. For model inference, start with a short input, a small output limit and one request. An entry-level GPU with about 4 GiB of VRAM may support short small-model inference; free cloud GPUs with more VRAM can support larger experiments. These are planning routes, not memory guarantees: measure the model, cache, activations and temporary allocations used by your actual configuration.

Free Colab GPU availability varies. Inspect the assigned device and free VRAM with nvidia-smi, and save checkpoints and reports outside the temporary runtime. Select a supported dtype: float32 is a useful CPU correctness starting point; float16, bfloat16 and quantized kernels depend on the hardware and software. Week 23 CUDA compilation needs nvcc. If it is absent, complete the numerical and code-reading parts and record that runtime limitation.

## FlashAttention versions and generative-model references

The original FlashAttention paper explains IO-aware exact attention. FlashAttention-2 improves work partitioning and parallelism; FlashAttention-3 targets Hopper execution, including asynchronous scheduling and low-precision paths. They are related implementation generations, not different probability definitions. Read the algorithm pictures in weeks 22–23 before considering an installation [R26, R35, R36].

Kernel support is hardware-specific. The standard CUDA FlashAttention-2 path targets Ampere, Ada and Hopper GPUs; FlashAttention-3 targets Hopper GPUs such as H100/H800. The official implementation lists current requirements and newer kernels. The course does not require a FlashAttention package to learn or test ordinary attention; use the supported backend available in your environment [R37].

DDPM remains a foundational description of diffusion rather than a current model recommendation. Week 15 connects it to learned reverse denoising, latent diffusion and flow matching, so the forward-noising formula is not presented as the whole generation process [R21, R38, R39].

## Reproduce the environment you actually ran

Package ranges in notebooks are starting constraints, not lockfiles. In particular, the Qwen3 route needs the newer Transformers lower bound; an older saved environment may still be needed to reproduce a legacy run. Record resolved Python, torch, transformers, sentence-transformers, PEFT and accelerator versions, model/tokenizer commits, data hashes, seeds and configuration. Save a lockfile after the selected lab works.

The source and numerical checks reported with the course are separate from model-download, GPU-training and kernel checks. A model card or successful syntax check is not evidence that the complete workload ran on your device. Keep the execution status with every report.

## Outputs

The bootstrap creates a runs directory. Use run IDs and keep actual outputs. The fictional teaching fixtures are deliberately small, so report them as teaching examples rather than production benchmarks.

