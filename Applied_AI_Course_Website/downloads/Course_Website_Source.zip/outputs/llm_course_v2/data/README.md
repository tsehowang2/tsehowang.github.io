# Teaching fixtures

Atlas SDK and all bundled documentation are invented for this course. They are not instructions for a real product. All text was authored for these exercises. `unsafe-v2` deliberately contains an adversarial instruction; it is data for controller and prompt-injection experiments.

`queries.json` is a visible development fixture, not a hidden test benchmark. Group labels help demonstrate leakage-aware splitting. It is too small and too exposed to support general performance claims. Create independent questions and version-pinned public documents for your project. `facts` are hints for manual grading, not a sufficient substring-based factuality checker.
