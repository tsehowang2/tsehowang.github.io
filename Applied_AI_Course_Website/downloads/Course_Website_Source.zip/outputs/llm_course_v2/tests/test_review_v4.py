import unittest
import json
from coursekit.core import run_agent, calculate, ToolError

class ReviewRegressionTests(unittest.TestCase):
    def test_invalid_json_is_recorded(self):
        def planner(state):
            return json.loads('{')
        result=run_agent('test',planner)
        self.assertEqual(result['status'],'planner_error')
        self.assertEqual(result['trace'][-1]['event'],'invalid_json')

    def test_calculator_rejects_unsafe_inputs(self):
        for expression in ['1/0', '2**100', "__import__('os')", 'True+1']:
            with self.subTest(expression=expression), self.assertRaises(ToolError):
                calculate(expression)
