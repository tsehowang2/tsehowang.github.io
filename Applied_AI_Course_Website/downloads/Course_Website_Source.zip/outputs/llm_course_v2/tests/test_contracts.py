import unittest
from coursekit.core import (LexicalIndex, load_docs, retrieval_metrics, rrf, paired_bootstrap,
                            calculate, ToolError, validate_config, run_agent, make_manifest, verify_manifest)


class RetrievalTests(unittest.TestCase):
    def setUp(self):
        self.index = LexicalIndex(load_docs())

    def test_version_filter_prevents_cross_version_evidence(self):
        for version in ('1', '2'):
            hits = self.index.search('default request timeout', version)
            self.assertTrue(hits)
            self.assertTrue(all(d['version'] == version for d in hits))

    def test_comparison_can_retrieve_both_versions(self):
        ids = {d['id'] for d in self.index.search('default request timeout', 'all', 5)}
        self.assertTrue({'timeout-v1', 'timeout-v2'} <= ids)

    def test_no_matching_term_has_no_evidence(self):
        self.assertEqual(self.index.search('zzzzzzzzzz', '2'), [])

    def test_duplicate_ids_rejected(self):
        with self.assertRaises(ValueError):
            LexicalIndex([load_docs()[0], load_docs()[0]])

    def test_recall_differs_from_hit(self):
        m = retrieval_metrics(['C', 'A', 'D'], ['A', 'B'], 3)
        self.assertEqual(m, {'recall': .5, 'hit': 1, 'rr': .5})

    def test_duplicate_ranks_do_not_inflate_recall(self):
        self.assertEqual(retrieval_metrics(['A', 'A'], ['A', 'B'], 2)['recall'], .5)

    def test_unanswerable_recall_is_not_defined(self):
        self.assertIsNone(retrieval_metrics(['A'], [], 1)['recall'])

    def test_rrf_can_favor_consensus(self):
        left = ['A', 'B']
        right = ['C', 'B'] + ['x'+str(i) for i in range(7)] + ['A']
        self.assertEqual(rrf([left, right])[0][0], 'B')

    def test_bootstrap_uses_paired_difference(self):
        r = paired_bootstrap([0, 1, 0, 1], [1, 1, 1, 1], repeats=100)
        self.assertEqual(r['difference'], .5)
        self.assertLessEqual(r['ci95'][0], r['difference'])
        self.assertGreaterEqual(r['ci95'][1], r['difference'])


class ToolTests(unittest.TestCase):
    def test_arithmetic(self):
        self.assertEqual(calculate('100+200+400'), 700)
        self.assertEqual(calculate('-(3+1)/2'), -2)

    def test_code_execution_syntax_rejected(self):
        for text in ["__import__('os')", 'x+1', 'True+1', '2**10', '[1][0]']:
            with self.subTest(text=text), self.assertRaises(ToolError):
                calculate(text)

    def test_division_zero_and_numeric_bounds(self):
        for text in ['1/0', '1e100', '999999999*999999999']:
            with self.subTest(text=text), self.assertRaises(ToolError):
                calculate(text)

    def test_complexity_bound(self):
        with self.assertRaises(ToolError):
            calculate('+'.join(['1'] * 30))

    def test_config_types_and_boundaries(self):
        self.assertTrue(validate_config({'timeout_ms': 1, 'retries': 0})['valid'])
        self.assertTrue(validate_config({'timeout_ms': 120000, 'retries': 5})['valid'])
        self.assertFalse(validate_config({'timeout_ms': True, 'retries': 0})['valid'])
        self.assertFalse(validate_config({'timeout_ms': 0, 'retries': 6})['valid'])

    def test_extra_fields_rejected(self):
        with self.assertRaises(ToolError):
            validate_config({'timeout_ms': 100, 'retries': 1, 'command': 'anything'})


class ControllerTests(unittest.TestCase):
    def test_unending_planner_terminates(self):
        p = lambda s: {'type': 'tool', 'name': 'calculate', 'arguments': {'expression': '1+1'}}
        r = run_agent('test', p, max_steps=3)
        self.assertEqual(r['status'], 'budget_exhausted')
        self.assertEqual(len(r['trace']), 3)

    def test_unknown_tool_never_executes(self):
        r = run_agent('test', lambda s: {'type': 'tool', 'name': 'export_secrets', 'arguments': {}})
        self.assertEqual(r['status'], 'invalid_action')
        self.assertEqual(r['trace'], [])

    def test_version_scope_is_enforced_by_code(self):
        p = lambda s: {'type': 'tool', 'name': 'lookup', 'arguments': {'query': 'timeout', 'version': '1'}}
        self.assertEqual(run_agent('test', p, version='2')['status'], 'invalid_action')

    def test_unobserved_citation_rejected(self):
        p = lambda s: {'type': 'final', 'answer': 'answer', 'citations': ['timeout-v2']}
        self.assertEqual(run_agent('test', p)['status'], 'invalid_action')

    def test_lookup_then_final(self):
        def planner(s):
            if not s['observations']:
                return {'type': 'tool', 'name': 'lookup', 'arguments': {'query': 'default request timeout', 'version': s['version']}}
            return {'type': 'final', 'answer': 'The cited fixture contains the default.', 'citations': ['timeout-v2']}
        r = run_agent('default request timeout', planner)
        self.assertEqual(r['status'], 'completed')
        self.assertFalse(r['grounding_verified'])

    def test_malformed_planner_output(self):
        self.assertEqual(run_agent('test', lambda s: 'not an object')['status'], 'invalid_action')

    def test_planner_exception_is_controlled(self):
        def planner(s):
            raise RuntimeError('failure')
        self.assertEqual(run_agent('test', planner)['status'], 'planner_error')

    def test_corpus_manifest_rejects_mismatch(self):
        m = make_manifest()
        self.assertTrue(verify_manifest(m))
        m['corpus_sha256'] = 'bad'
        with self.assertRaises(ValueError):
            verify_manifest(m)


if __name__ == '__main__':
    unittest.main()
