# Primary references

Links checked on 20 October 2026. Course pages are references for teaching structure and optional study; the written chapters and exercises are original. Software documentation changes: save the versions you actually run. Read the named section, not the whole source, unless marked optional.

| ID | Primary source | Use |
|---|---|---|
| R01 | [Stanford CS336 Language Modeling from Scratch](https://cs336.stanford.edu/) | Architecture, resource accounting, data, alignment; optional deeper assignments |
| R02 | [Stanford CS329S Machine Learning Systems Design](https://stanford-cs329s.github.io/) | Lifecycle, stakeholder requirements, deployment and monitoring |
| R03 | [Hung-yi Lee Introduction to GenAI and ML 2025](https://speech.ee.ntu.edu.tw/~hylee/GenAI-ML/2025-fall.php) | Optional intuition-first videos: context engineering, model internals, evaluation, post-training |
| R04 | [Vaswani et al. Attention Is All You Need](https://arxiv.org/abs/1706.03762) | Scaled dot-product attention and multi-head architecture |
| R05 | [Google Colab FAQ](https://research.google.com/colaboratory/faq.html) | Resource availability, session limits and persistence |
| R06 | [Lewis et al. Retrieval Augmented Generation](https://arxiv.org/abs/2005.11401) | Parametric and retrieved information; historical RAG formulation |
| R07 | [Sentence Transformers semantic similarity](https://www.sbert.net/docs/sentence_transformer/usage/semantic_textual_similarity.html) | Embedding encoding and similarity |
| R08 | [Qdrant local quickstart](https://qdrant.tech/documentation/quickstart/) | Collections, points and payloads |
| R09 | [Hugging Face Transformers chat templates](https://huggingface.co/docs/transformers/chat_templating) | Message serialization and generation prompts |
| R10 | [Wei et al. Chain of Thought Prompting](https://arxiv.org/abs/2201.11903) | Intermediate-step prompting and task-dependent evaluation |
| R11 | [Yao et al. ReAct](https://arxiv.org/abs/2210.03629) | Interleaving observations and actions |
| R12 | [Hu et al. LoRA](https://arxiv.org/abs/2106.09685) | Low-rank trainable updates |
| R13 | [Dettmers et al. QLoRA](https://arxiv.org/abs/2305.14314) | Quantized frozen base plus adapters |
| R14 | [Hugging Face PEFT LoRA guide](https://huggingface.co/docs/peft/main/en/conceptual_guides/lora) | Configurations and adapter operations; select installed version in docs |
| R15 | [Rafailov et al. Direct Preference Optimization](https://arxiv.org/abs/2305.18290) | Preference learning objective |
| R16 | [NVIDIA CUDA programming guide](https://docs.nvidia.com/cuda/cuda-programming-guide/) | Thread hierarchy, memory and synchronization |
| R17 | [NVIDIA CUDA introduction](https://developer.nvidia.com/blog/easy-introduction-cuda-c-and-c/) | A minimal CUDA C++ program |
| R18 | [PyTorch automatic mixed precision recipe](https://docs.pytorch.org/tutorials/recipes/recipes/amp_recipe.html) | Autocast and gradient scaling |
| R19 | [PyTorch profiler recipe](https://docs.pytorch.org/tutorials/recipes/recipes/profiler_recipe.html) | CPU/GPU activity, operator timing and memory |
| R20 | [MLflow experiment tracking](https://mlflow.org/docs/latest/ml/tracking/) | Runs, parameters, metrics and artifacts |
| R21 | [Ho et al. Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239) | Foundational forward and learned reverse diffusion; connect with latent diffusion and flow matching |
| R22 | [MiniLM L6 legacy English model card](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) | Historical English baseline; default 256-word-piece truncation |
| R23 | [Qwen2.5 0.5B Instruct legacy model card](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct) | Historical generator baseline for reproducible comparisons |
| R24 | [Malkov and Yashunin HNSW](https://arxiv.org/abs/1603.09320) | Hierarchical approximate nearest-neighbor graph |
| R25 | [Robertson and Zaragoza Probabilistic Relevance Framework](https://doi.org/10.1561/1500000019) | BM25 term saturation and length normalization |
| R26 | [Dao et al. FlashAttention](https://arxiv.org/abs/2205.14135) | Foundational IO-aware exact attention; compare later implementation generations |
| R27 | [Sentence Transformers contrastive losses](https://sbert.net/docs/package_reference/sentence_transformer/losses.html) | Contrastive training and assumptions about negative pairs |
| R28 | [Sentence Transformers retrieve and rerank](https://sbert.net/examples/sentence_transformer/applications/retrieve_rerank/README.html) | Bi-encoder and cross-encoder roles |
| R29 | [Model Context Protocol architecture](https://modelcontextprotocol.io/docs/learn/architecture) | Host, client, server, tools, resources and prompts |
| R30 | [Model Context Protocol tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools) | Tool discovery and tool calls; conceptual reference |
| R31 | [Python version status](https://devguide.python.org/versions/) | Supported releases and Python 3.10 end of life |
| R32 | [PyTorch installation selector](https://pytorch.org/get-started/locally/) | Match Python, operating system and accelerator installation |
| R33 | [Multilingual E5 small model card](https://huggingface.co/intfloat/multilingual-e5-small) | Bilingual retrieval route; 384 dimensions, 512 tokens and query/passage prefixes |
| R34 | [Qwen3 0.6B model card](https://huggingface.co/Qwen/Qwen3-0.6B) | Newer small generator; Transformers requirement and thinking-mode control |
| R35 | [Dao FlashAttention-2](https://arxiv.org/abs/2307.08691) | Work partitioning and parallelism |
| R36 | [Shah et al. FlashAttention-3](https://arxiv.org/abs/2407.08608) | Hopper-oriented asynchronous and low-precision execution |
| R37 | [Official FlashAttention implementation](https://github.com/Dao-AILab/flash-attention) | Current kernel and hardware support |
| R38 | [Rombach et al. Latent Diffusion Models](https://arxiv.org/abs/2112.10752) | Generation in an autoencoder latent space |
| R39 | [Lipman et al. Flow Matching](https://arxiv.org/abs/2210.02747) | Learning a vector field for generative modeling |
| R40 | [PEFT LoRA documentation](https://huggingface.co/docs/peft/package_reference/lora) | A random/B zero initialization and runtime configuration |
| R41 | [DoRA: Weight-Decomposed Low-Rank Adaptation](https://arxiv.org/abs/2402.09353) | Magnitude and direction parameterization |
| R42 | [A Rank Stabilization Scaling Factor for Fine-Tuning with LoRA](https://arxiv.org/abs/2312.03732) | alpha/sqrt(r) scaling |
| R43 | [TRL DPO Trainer](https://huggingface.co/docs/trl/dpo_trainer) | beta default 0.1 and configuration-specific choice |
| R44 | [Hugging Face Transformers tool use](https://huggingface.co/docs/transformers/chat_extras) | Model/template-dependent native tool calling |
| R45 | [SWE-bench official benchmark](https://www.swebench.com/) | Issue, patch, environment and test-based task success |
| R46 | [vLLM quickstart](https://docs.vllm.ai/en/stable/getting_started/quickstart/) | Local serving command and supported installation |
| R47 | [llama.cpp server](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md) | GGUF serving command shape |
| R48 | [PagedAttention](https://arxiv.org/abs/2309.06180) | Logical KV blocks and physical allocation |
| R49 | [OWASP 2025 LLM Top 10](https://genai.owasp.org/llm-top-10/) | Current risk categories mapped to course controls |
| R50 | [PCPD Six Data Protection Principles](https://www.pcpd.org.hk/english/data_privacy_law/6_data_protection_principles/principles.html) | Hong Kong PDPO basic design questions |
| R51 | [PCPD AI Model Personal Data Protection Framework](https://www.pcpd.org.hk/english/resources_centre/publications/files/ai_protection_framework.pdf) | AI governance, data protection and applicability review |
| R52 | [Hong Kong Intellectual Property Department copyright](https://www.ipd.gov.hk/en/copyright/index.html) | Copyright applicability and rights checks |
| R53 | [European Commission AI Act](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai) | Roles, risk-based regulation and phased obligations |
| R54 | [Hugging Face BPE tokenization](https://huggingface.co/learn/llm-course/en/chapter6/5) | BPE frequency counting, byte alphabet and saved merge order |
| R55 | [Hugging Face WordPiece tokenization](https://huggingface.co/learn/llm-course/en/chapter6/6) | WordPiece distinction |
| R56 | [Hugging Face Unigram tokenization](https://huggingface.co/learn/llm-course/en/chapter6/7) | Unigram vocabulary and probabilistic segmentation |
| R57 | [SentencePiece](https://arxiv.org/abs/1808.06226) | Tokenizer toolkit, raw text and BPE/Unigram distinction |
| R58 | [How Contextual are Contextualized Word Representations?](https://arxiv.org/abs/1909.00512) | Contextual geometry and anisotropy |
| R59 | [PyTorch log_softmax](https://docs.pytorch.org/docs/2.14/generated/torch.nn.functional.log_softmax.html) | Stable log probability computation |
| R60 | [PyTorch CrossEntropyLoss](https://docs.pytorch.org/docs/2.14/generated/torch.nn.CrossEntropyLoss.html) | Raw logits, class labels and log_softmax equivalence |
| R61 | [Perplexity of fixed-length models](https://huggingface.co/docs/transformers/perplexity) | Exponentiated mean negative log likelihood and tokenizer dependence |
| R62 | [RoFormer](https://arxiv.org/abs/2104.09864) | Position-dependent rotations and relative offsets |
| R63 | [NoPE causal language models](https://arxiv.org/abs/2203.16634) | Qualify explicit-position necessity |
| R64 | [GQA](https://arxiv.org/abs/2305.13245) | Shared key/value heads |
| R65 | [GLU variants](https://arxiv.org/abs/2002.05202) | Three-matrix SwiGLU count |
| R66 | [DeepSeek-V2](https://arxiv.org/abs/2405.04434) | MLA and MoE |
| R67 | [Mamba](https://arxiv.org/abs/2312.00752) | Selective state-space model |
| R68 | [Compute-optimal language models](https://arxiv.org/abs/2203.15556) | Scaling laws |
| R69 | [AdamW](https://docs.pytorch.org/docs/stable/generated/torch.optim.AdamW.html) | Decoupled weight decay |
| R70 | [Transformers generation parameters](https://huggingface.co/docs/transformers/main_classes/text_generation) | Min-p and repetition penalties |
| R71 | [Speculative sampling](https://arxiv.org/abs/2302.01318) | Distribution-preserving verification |
| R72 | [PPO](https://arxiv.org/abs/1707.06347) | Policy update clipping |
| R73 | [DeepSeekMath](https://arxiv.org/abs/2402.03300) | GRPO |
| R74 | [Constitutional AI](https://arxiv.org/abs/2212.08073) | Principle-based feedback |
| R75 | [DiT](https://arxiv.org/abs/2212.09748) | Transformer denoising backbone |
| R76 | [Classifier-free guidance](https://arxiv.org/abs/2207.12598) | Conditional/unconditional combination |
| R77 | [Visual instruction tuning](https://arxiv.org/abs/2304.08485) | Image-language connector |
| R78 | [Sentence Transformers pretrained models](https://sbert.net/docs/sentence_transformer/pretrained_models.html) | Model-specific similarity and input recipes |
| R79 | [Matryoshka Representation Learning](https://arxiv.org/abs/2205.13147) | Nested vector prefixes require training |
| R80 | [ColBERT](https://arxiv.org/abs/2004.12832) | Contextual token vectors and late interaction |
| R81 | [SPLADE](https://arxiv.org/abs/2107.05720) | Learned sparse term representations |
| R82 | [HNSW parameters](https://github.com/nmslib/hnswlib/blob/master/ALGO_PARAMS.md) | M, construction breadth, query ef |
| R83 | [Faiss indexes](https://github.com/facebookresearch/faiss/wiki/Faiss-indexes) | IVF and scalar/product quantization |
| R84 | [DiskANN](https://github.com/microsoft/DiskANN) | SSD-aware graph vector search |
| R85 | [Triton vector addition](https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html) | Masked block indexing |
| R86 | [torch.compile introduction](https://docs.pytorch.org/tutorials/intermediate/torch_compile_tutorial.html) | Graph capture, optimization, timing |
| R87 | [FSDP tutorial](https://docs.pytorch.org/tutorials/intermediate/FSDP1_tutorial.html) | Sharding and temporary gathers |
| R88 | [DeepSpeed ZeRO tutorial](https://www.deepspeed.ai/tutorials/zero/) | State sharding stages |

## Readings by phase

Read the explanation and worked example in the course first. Source links at the point of use let you inspect the original definition or the exact software behavior. Research papers and full external courses are optional references, not additional assignments.

Weeks 1–5 use the notes and tokenization/model-card examples; weeks 6–11 connect attention and architecture to the original transformer and modern variants. Weeks 12–16 connect training, chat templates, reasoning and generative families. Weeks 17–21 use retrieval, embedding and evaluation documentation. Weeks 22–23 use memory, kernels and profiling sources. Weeks 24–26 use adaptation and preference-learning sources. Weeks 27–32 use tool, protocol, serving, safety and lifecycle documentation. Follow the named lesson section rather than reading every linked source in full.

## Historical foundations and current tools

A foundational paper is not obsolete merely because its publication year is old. Keep the original definition for attention, diffusion or low-rank adaptation, and use current implementation documentation when installing a tool. The legacy models are controls for reproducibility; the multilingual embedding and newer small-generator routes are the recommended starting points for the revised model labs.

