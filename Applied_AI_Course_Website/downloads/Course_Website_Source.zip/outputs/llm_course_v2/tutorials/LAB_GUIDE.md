# Weekly tutorial guide

Each tutorial has one week of prerequisites, a guided path and independent work. Read code on the website; execute it in a notebook or local script. Install NumPy for numerical tutorials. Explicit model/CUDA installation cells require suitable compute and network access.

## Lab 01 What a language model is trying to learn

**Compute:** CPU; no downloads. Read lecture 01 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Add two train sentences by hand. Predict the new denominator before running.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Change the prefix to I go to work by. Explain why no observations is different from evidence that every completion is impossible.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 02 From text to tokens and numerical IDs

**Compute:** CPU; no downloads. Read lecture 02 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Write which word is the target at each position. Why does the final bus not appear in the input for this single training pair?

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Compare school and school. in the whitespace vocabulary. Add punctuation handling, then explain how changing a tokenizer requires keeping the embedding table consistent.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 03 What word vectors can represent

**Compute:** CPU; standard library and NumPy. Read lecture 03 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Predict what happens to dot product and cosine when train is multiplied by five.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Create a random vocabulary table and look up bus by row ID. Permute the vocabulary IDs and table rows together; demonstrate that the retrieved vector stays the same. Explain why independently trained embedding spaces cannot be mixed.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 04 From scores to probabilities and learning signals

**Compute:** CPU; standard library and NumPy. Read lecture 04 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Before running, decide whether the train score should increase or decrease.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Compare temperature .5, 1 and 2 on fixed logits. Report entropy and target loss separately. Explain why a sharper distribution can increase the loss for a non-maximal target.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 05 Why language needs context and order

**Compute:** CPU; standard library and NumPy. Read lecture 05 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Trace the first and second state updates by hand. Which part carries earlier information?

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Move one informative token farther from the final position and record its effect on the final state. Compare recurrence coefficients .1 and .9. Explain why this untrained example cannot establish a general performance claim.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 06 Attention begins as a weighted mixture

**Compute:** CPU; standard library and NumPy. Read lecture 06 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Calculate the two output coordinates separately. Do not treat the values as probabilities.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Hold values fixed and sweep the first weight while sharing the remaining mass equally. Plot or tabulate the output. Explain what changes when weights do not sum to one.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 07 Where queries keys and values come from

**Compute:** CPU; standard library and NumPy. Read lecture 07 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Calculate one projection and one dot product by hand before checking the arrays.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Change Wv while leaving Wq and Wk fixed. Show that the weights stay fixed while the output changes. Then change Wk. Explain why the same operation cannot describe both changes.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 08 Scaling and masking attention correctly

**Compute:** CPU; NumPy. Read lecture 08 first. Allow two hours for the guided path and two for independent work.

**Before execution:** First reproduce one query by hand, including scaling. Then run the causal perturbation check.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Change the sequence length and verify shapes and memory growth. Intentionally remove the mask and show that the behavioral check fails.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 09 Multiple attention heads and position

**Compute:** CPU; standard library and NumPy. Read lecture 09 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Track the location of feature six at position two through the split and merge.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Implement one attention calculation per head, then concatenate. Compare with a single head of dimension eight, using distinct but recorded matrices. Discuss what is an architectural difference and what is merely a layout transformation.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 10 The transformer block step by step

**Compute:** CPU; standard library and NumPy. Read lecture 10 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Draw x + Attention(LN(x)), followed by x + MLP(LN(x)). State the shape at each addition.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Set the MLP output matrix to zero. Verify that this residual sublayer becomes the identity. Replace the toy ReLU with a GELU implementation and explain which property tests should remain unchanged.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 11 Encoders decoders and complete model architectures

**Compute:** CPU; standard library and NumPy. Read lecture 11 first. Allow two hours for the guided path and two for independent work.

**Before execution:** For the third decoder position, list which source and target positions are visible.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Write a shape table for a batch of two with three heads. Explain why changing an encoder source token may change every target output while changing a future decoder token must not change earlier outputs.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 12 Training a small transformer

**Compute:** CPU or Colab; PyTorch. Read lecture 12 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Trace one batch through embedding, position, attention, MLP and logits. Check shifted labels and causal invariance before optimizing.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Evaluate multiple held-out batches, then perform one equal-budget architecture ablation. Keep complete loss histories and record why the synthetic repeated data limits conclusions.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 13 Generation decoding and the KV cache

**Compute:** CPU; standard library and NumPy. Read lecture 13 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Explain why the most likely first token need not lead to the most likely complete sequence.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** For a real-model run, compare greedy and two seeded samples under the same prefix and maximum length. Record model revision, actual tokens and latency. Explain how a KV cache changes computation but not the intended conditional distribution.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 14 From pretraining to instruction following and reasoning

**Compute:** CPU; no downloads for masking exercise. Read lecture 14 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Explain why the first response token is predicted by the last prompt position after shifting.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Make six independently solvable arithmetic questions. Compare direct and concise-step prompts at equal budgets if a model is available. Use a calculator for correctness and preserve wrong rationales. Without a model, submit the test protocol and clearly label it unexecuted.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 15 Generative AI beyond text

**Compute:** CPU; standard library and NumPy. Read lecture 15 first. Allow two hours for the guided path and two for independent work.

**Before execution:** For x0=2, noise=-1, alpha_bar=.64, compute the noisy scalar by hand.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Write what inputs a learned noise predictor receives and what target it sees. Explain why using the exact noise for reconstruction here is different from generating an unseen image. Contrast an autoregressive image-token sequence.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 16 A complete transformer walkthrough and first semester review

**Compute:** CPU worksheet; PyTorch only for the week-12 reproduction. Read lecture 16 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Explain how a six-position input can have six next-token targets when taken from a longer sequence, although a standalone six-token sentence only supplies five adjacent pairs.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Reproduce the week-12 model in a fresh environment and defend one controlled ablation. Complete semester exam 1 instead of the usual independent experiment. Record corrections rather than adding extra hours.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 17 From word vectors to semantic search

**Compute:** CPU; standard library and NumPy. Read lecture 17 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Label the relevant document yourself. Explain why this hand-designed geometry cannot prove that an embedding model understands the query.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Run the optional real embedding cell on six original paraphrases, compare lexical overlap and dense ranking, and report every miss. Record the model revision; do not call the invented vectors model results.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 18 A vector database from a list of vectors

**Compute:** CPU with embedding download and Qdrant client. Read lecture 18 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Predict which versions survive the query filter, including an empty-result failure.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Update and delete records in a separate collection; reopen it and assert both nonempty hits and the requested version.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 19 RAG as an open book question

**Compute:** CPU; no downloads. Read lecture 19 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Write a supported answer manually and attach the source ID. Ask an absent question and explain why the generator must not fill in missing facts.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Add a contradictory older handbook and a version field. Show the exact evidence chosen for each version. Compare failure at retrieval, packing and generation; do not treat a correctly formatted citation as proof of support.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 20 Improving RAG without losing the basic task

**Compute:** CPU baseline; real RAG uses tutorials 13, 17 and 18. Read lecture 20 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Calculate both component rankings and RRF before checking the printed result.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Compare lexical, actual dense, fusion and reranking on the same tasks; show how strict rank-prefix packing differs from skip-to-fit packing.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 21 Evaluating retrieval answers and uncertainty

**Compute:** CPU; no downloads. Read lecture 21 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Identify the denominator for recall, selective accuracy and coverage.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Manually grade support and completeness, retain paired outcomes and report the uncertainty of one controlled comparison.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 22 CPU GPU memory and model resource accounting

**Compute:** CPU; no downloads. Read lecture 22 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Explain the factor of two in the KV formula and what doubling the context length changes.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Inventory the actual CPU/GPU and free memory. Build a small-model budget with explicit precision assumptions and a safety margin. Distinguish measured allocations from estimates; explain what gradient accumulation can and cannot reduce.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 23 CUDA kernels and profiling

**Compute:** Colab GPU; CUDA kernel also requires nvcc. Read lecture 23 first. Allow two hours for the guided path and two for independent work.

**Before execution:** For n=257, predict valid indices, extra threads and required blocks.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Run awkward vector sizes against the CPU reference; save synchronized timings, warmup details and device metadata.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 24 Fine tuning starts with a teaching dataset

**Compute:** CPU; no downloads. Read lecture 24 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Inspect a prompt containing distractors and its concise reviewed answer, including the cross-version record.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Audit every target and citation; expand independent question families and keep missing-answer and comparison cases in grouped splits.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 25 LoRA and QLoRA from a small matrix

**Compute:** CPU; standard library and NumPy. Read lecture 25 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Why is low rank not parameter efficient for every tiny matrix? Check the three-by-four rank-two example.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Compare zero B/random A with both factors zero by deriving the first gradients. Explain how QLoRA changes frozen-base storage and why it does not imply all activations or optimizer states are four-bit.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 26 Fine tuning experiments preferences and distillation

**Compute:** Colab GPU preferred; CPU two-step pilot is slow. Read lecture 26 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Calculate DPO loss and the student distribution after one distillation gradient step.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Run the LoRA pilot, compare paired base/adapter outputs and verify that saved/reloaded logits match under pinned revisions.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 27 Tools functions workflows and agents

**Compute:** CPU; no downloads. Read lecture 27 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Predict the ticket total and which calculator expressions must be rejected.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Add a valid and invalid tool proposal, assert controller statuses and keep proposal, execution result and final answer distinct.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 28 Harnesses planning memory and bounded execution

**Compute:** Model download; GPU preferred. Read lecture 28 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Predict the terminal status and trace event for malformed JSON.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Compare model planner and fixed workflow on checked tasks; retain raw proposals, invalid_json events and budget-exhaustion traces.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 29 From a notebook to MLOps and inference serving

**Compute:** CPU; no downloads. Read lecture 29 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Identify how the child process announces its own free port.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Save 200 local sequential request timings, explain their limited tail-latency meaning, and compare separately with any actual LLM service.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 30 Monitoring security regression tests and rollback

**Compute:** CPU baseline; optional actual-model attack trial. Read lecture 30 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Predict each rejection and test the host allow-list with external images both disabled and enabled.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Run hostile retrieved documentation through the controller; add one incident regression and verify a coherent rollback.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 31 Integrating the documentation assistant and advanced extensions

**Compute:** CPU audit; existing model artifacts for integrated tests. Read lecture 31 first. Allow two hours for the guided path and two for independent work.

**Before execution:** List which submitted artifacts the audit will find and which are incomplete.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Populate a real release manifest, 40 manually checked cases and paired outputs; compare release candidates against the same gates.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.

## Lab 32 Review defense and a continuing learning plan

**Compute:** CPU audit; completed model/GPU artifacts from previous labs. Read lecture 32 first. Allow two hours for the guided path and two for independent work.

**Before execution:** Identify missing model, evaluation and environment evidence before the final audit.

**Guided path:** read one cell, identify the inputs and expected shape or status, and write a prediction. Run it and compare every relevant output with the prediction. If it differs, inspect the smallest intermediate result before changing anything else. Re-run from a clean kernel to check hidden-state dependence.

**Independent work:** Reproduce from a clean directory, complete the artifact audit, and defend the qualifying release with success, absence and failure cases.

**Submit:** a concise notebook/report with your prediction, actual output, controlled comparison, interpretation and one limitation. Include environment details when packages or devices matter. An unexecuted GPU/model path must be labeled unexecuted. Use the ten-point tutorial rubric in the syllabus.
