from pathlib import Path
import sys,json,time,random,hashlib,math
if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
candidates=[Path.cwd(),Path.cwd().parent,Path.cwd()/'llm_course',Path.cwd()/'llm_course_v2',Path('/content/llm_course'),Path('/content/llm_course_v2')]
COURSE=next((p for p in candidates if (p/'coursekit/core.py').exists()),None)
if COURSE is None: raise RuntimeError('Extract the complete course pack; run from its root or notebooks directory.')
if str(COURSE) not in sys.path:sys.path.insert(0,str(COURSE))
RUNS=COURSE/'runs';RUNS.mkdir(exist_ok=True)
from coursekit.core import *
random.seed(7)
print('Course root:',COURSE)


import numpy as np
vectors={'bus':np.array([1.,0.]),'train':np.array([.8,.6]),'banana':np.array([0.,1.])}
q=vectors['bus']
for word,v in vectors.items():
    cosine=q@v/(np.linalg.norm(q)*np.linalg.norm(v))
    print(word,'dot',q@v,'cosine',cosine)
v=5*vectors['train']
assert np.isclose(q@v,4)
assert np.isclose(q@v/(np.linalg.norm(q)*np.linalg.norm(v)),.8)


import math
q=[1.,0.];a=[.8,.6];b=[3.,4.]
def dot(x,y):return sum(u*v for u,v in zip(x,y))
def cosine(x,y):return dot(x,y)/math.sqrt(dot(x,x)*dot(y,y))
assert dot(q,b)>dot(q,a) and cosine(q,a)>cosine(q,b)
print('Dot a,b:',dot(q,a),dot(q,b),'Cosine a,b:',cosine(q,a),cosine(q,b))
