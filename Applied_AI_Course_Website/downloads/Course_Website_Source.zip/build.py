from pathlib import Path
import subprocess,sys,zipfile,json
B=Path(__file__).resolve().parent
for script in ['package_v2.py','build_course_site_v2.py','build_bilingual.py','enhance_course_v3.py']:
    subprocess.run([sys.executable,str(B/'work'/script)],cwd=B,check=True)
site=B/'outputs/ai_course_website_bilingual'
manifest=json.loads((B/'source_manifest.json').read_text(encoding='utf-8'))
archive=site/'downloads/Course_Website_Source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in manifest:
        p=B/name
        if p.is_file():z.write(p,name)
subprocess.run([sys.executable,str(B/'work/validate_site_v3.py')],cwd=B,check=True)
target=B/'Applied_AI_Course_Website.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in site.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(site))
print('Built static site:',site)
print('GitHub Pages archive:',target)
