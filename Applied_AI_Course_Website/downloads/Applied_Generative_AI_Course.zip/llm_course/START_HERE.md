# Applied Generative AI and LLM Systems

An original two-semester self-study course for a working data engineer who already knows Python, probability, calculus, linear algebra, neural networks, and basic PyTorch. The emphasis is on building, measuring, and operating LLM applications. The capstone is a technical-documentation assistant with retrieval and executable tools.

**Workload:** 32 weeks, 10 hours per week, 320 hours total. **Language:** English. **Compute:** CPU for the retrieval, agent, evaluation, and operations baseline; Colab for the model labs. Your GTX 1650 Super is optional. Check actual free memory and supported dtypes instead of assuming a specific Colab GPU. Free GPU access and runtime duration are not guaranteed [R05].

## What you will be able to do

Explain a decoder transformer, debug shifted labels and causal masks, estimate training and inference memory, build and evaluate semantic retrieval, operate a versioned vector index, construct grounded answers with citations, fine-tune a small model with LoRA, implement a bounded tool-using agent, and deploy an observable service with release and rollback criteria. Introductory CUDA means writing and timing a small kernel and understanding memory movement; it does not mean becoming a distributed-training or kernel-performance specialist in this course.

The teaching pattern is intuition, mechanism, worked example, experiment, failure analysis. Readings link to Stanford CS336, Stanford CS329S, Hung-yi Lee's public course, original papers, and official implementation documentation [R01–R04]. This is independent material, not an official course or a reproduction of those instructors' notes. All written instruction is English; optional Hung-yi Lee videos may be in Mandarin.

## Files and how to study

1. Open COURSE_READER.html for the browser-readable textbook and course guide, or read `SYLLABUS.md` and `SETUP.md`.
2. Study the relevant chapter in `lectures/01_foundations.md`, `02_retrieval.md`, `03_adaptation_agents.md`, or `04_operations.md`.
3. Work through the corresponding notebook in `notebooks/`. Open `.ipynb` files in Jupyter or upload them using Colab's File → Upload notebook. CPU labs find the bundled package after you upload and extract this ZIP into the notebook's working directory. Every notebook also has a companion `.py` script.
4. Attempt that week's three questions in `assessments/WEEKLY_TESTS.md` before opening `solutions/WEEKLY_SOLUTIONS.md`.
5. Follow `tutorials/LAB_GUIDE.md` for the experiment, expected observations, submission, and troubleshooting. Running the demonstration alone is not completion.
6. Develop the project using `project/CAPSTONE.md`. Keep your own repository and experiment records; publish only results you actually obtain.

The starter includes a deliberately small invented documentation corpus. Its API names and behavior are fictional and exist to make tests reproducible. Replace it with a version-pinned public documentation corpus for your capstone. The baseline answerer extracts evidence; it is explicitly not an LLM. The model notebook adds a real small instruction model. The agent baseline uses a deterministic planner so controller behavior can be tested independently; the agent notebook adds a model-planner adapter.

The worked supplement adds mechanisms and numerical examples for corrections or optional-reading time.

## A realistic week after work

| Session | Hours | Work |
|---|---:|---|
| Evening 1 | 2 | Read notes, reproduce the worked example, write questions |
| Evening 2 | 2 | Complete the guided notebook and inspect intermediate outputs |
| Weekend block | 4 | Run the prescribed experiment and develop the project |
| Evening 3 | 2 | Test yourself, review mistakes, write the experiment report |

Most two-week labs receive four hours of guided work and eight hours of experiment/project time across the pair. Use the second week to change something, measure it, and explain it. Reading/video time is included in the ten hours; optional readings are not additional requirements. On examination weeks, the exam replaces study sessions as specified in the syllabus. If work becomes busy, reduce experiment sizes and stretch the calendar; keep the evaluation and explanation work.

## Assessment

Weekly tests 15%; 16 lab reports 30%; semester examinations 20% (10% each); capstone 35%. Self-grade with the separate solutions and rubrics. Passing target: 70% overall, both semester exams at least 60%, and all capstone safety/reproducibility gates satisfied. These are personal learning criteria, not accreditation. Two checkpoint quizzes are diagnostic and do not add to the grade.

Write an unaided attempt before consulting an assistant. You may use AI to explain concepts and help debug, but log assistance, verify generated claims, and be able to defend every submitted result. A portfolio project is evidence of independent delivery; it should be described as such, with real users and production claims only when they are true.

## Start today

Allocate 90 minutes to setup and the first half of notebook 01. Open COURSE_READER.html for the browser-readable textbook and course guide, or read week 1, run `python -m unittest discover -s tests -v` from this directory, inspect `data/docs.json`, and write a one-page project charter. Do not start by selecting an orchestration framework. First define which documentation questions the assistant must answer and how you will know it succeeds.

## Validation status

See `VALIDATION.md` for checks actually performed when this package was produced. Local CPU tests and model/GPU experiments are reported separately. Numerical examples in notes are worked examples, not measured capstone performance.
