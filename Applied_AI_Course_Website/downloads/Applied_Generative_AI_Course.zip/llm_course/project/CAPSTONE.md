# Capstone Technical documentation assistant

## Product contract

Build an assistant for a focused, version-pinned public software documentation corpus. It answers implementation questions with source citations, distinguishes versions, admits missing evidence, and executes two narrow tools: deterministic arithmetic and configuration validation. It exposes a local or hosted API and produces traces, evaluation reports and a reproducible release. Public hosting is optional; a reproducible local deployment counts as deployment evidence when described accurately.

Choose documentation with at least two versions or an equivalent meaningful distinction. Pin the source revision and check redistribution terms. Keep a manifest of source URLs, hashes, timestamps, parser/chunker settings and licensing notes. Start with roughly 30–100 substantive pages or sections; adjust to the material. Do not publish third-party documentation copies unless permitted. Retrieval at inference may read the permitted documentation; evaluation questions and labels remain separate from tuning.

## Required user tasks

Single-source lookup; exact API/error identifier lookup; paraphrased intent; cross-version comparison; multi-source troubleshooting; source-backed calculation; configuration validation; unsupported/ambiguous request; hostile instructions inside evidence. Each task record includes ID, requested version/scope, expected evidence, required facts, permitted tools, success predicate and group label. A refusal must be judged against whether the required answer actually exists.

## Milestones

| Due | Deliverable | Acceptance evidence |
|---:|---|---|
| 2 | Charter and source plan | Audience, ten questions, success metrics, provenance |
| 6 | Model-mechanism exercises | Tiny LM run, masks/shift tests, honest limits |
| 12 | Search subsystem | Lexical/dense benchmark, saved/reloaded filtered vector collection |
| 16 | RAG v1 | Citation contract, unsupported behavior, frozen evaluation and exam |
| 18 | Adaptation proposal | Error taxonomy, reviewed dataset, explicit hypothesis |
| 20 | Adaptation pilot | Actual small LoRA checkpoint, base comparison, reload verification |
| 24 | Tool/agent subsystem | Typed tools, bounded harness, workflow/agent task comparison |
| 28 | Operational candidate | API, manifest, latency report, traces, threat model |
| 30 | Release rehearsal | Gates, regression suite, rollback/incident report |
| 32 | Final release | Clean reproduction, full report, demo, defense |

## Data and evaluation plan

Aim for at least 120 manually reviewed question-task records: approximately 60 development, 20 validation/checkpoint and 40 final held-out, with group-aware partitions. Adapt these counts to the corpus and available time; a smaller pilot is acceptable only with explicit uncertainty and a narrower claim. For SFT, create a separate reviewed training set; start with 100–300 narrow examples if feasible. Do not convert final evaluation answers into training targets. The bundled 12 questions are visible software fixtures and cannot serve as your final benchmark.

Balance task slices so easy lookups cannot hide failures on absence, version comparisons or tools. Human-review required facts and source support. Save raw outputs, not only averages. Use retrieval recall/RR on answerable cases, fact completeness/correctness, semantic citation support on a reviewed subset, appropriate refusal, tool task success, invalid/forbidden actions, p50/p95 latency, failures and token/model-call costs. A substring checklist is a smoke test, not a full grounding metric.

Use paired comparisons for the same tasks and explain uncertainty. If final test cases inform further tuning, label the resulting analysis exploratory and reserve new untouched cases for another final claim. Publicly expose development cases, and keep any future held-out labels out of automated tuning.

## Required comparisons

Lexical versus dense retrieval; dense versus hybrid under a fixed budget; base prompt versus evidence-conditioned generation; base versus actual LoRA adapter on its narrow task; fixed workflow versus bounded model planner on tool tasks. A negative result is acceptable. Deploy the strongest qualifying simple configuration, even if an experimental component is left out.

## Architecture and behavior

Ingestion preserves sources and versions. Retrieval enforces requested scope before context is built. The vector collection records embedding identity and dimensions. Context includes source IDs and reserves output tokens. Generation uses the model's chat template. Responses include answer/status/citations and an identifiable release version. Tools validate strict schemas, permitted scope and resource limits. Controllers terminate explicitly. Observability links each step by request ID and identifies artifacts.

For a public corpus, version filters teach scoping; do not claim that they implement multi-tenant authentication. If adding private docs, implement authenticated authorization throughout retrieval, source fetches, caches and tools. Production deployment also needs real call timeouts/cancellation, secret management, access controls and process/container limits as appropriate. Describe which are implemented versus proposed.

## Release gates

Hard: deterministic contract suite passes; no cross-version evidence in scoped tests; no unknown/forbidden tool execution; bounded termination; reproducible artifact compatibility; required source deletions and updates verified. For the core read-only project there are no external side effects.

Quality/latency: choose targets before the evaluation and state why. Example learning targets, not measured claims: >=80% task success on answerable core cases, >=90% appropriate refusal on truly absent cases, no more than a 2-point supported-task regression versus baseline, and a stated p95 limit for your exact hardware/load. Small denominators make percentages uncertain; report counts and intervals. Do not force an arbitrary quality number by selecting easier test questions afterward.

## Final report structure

Problem and users; task/data contract; architecture and artifact lineage; baseline; controlled experiments; quality/cost/latency tables with actual numbers; representative error analysis; security and operations; reproducibility; limitations; next experiment. Suggested length 8–12 pages equivalent, with raw outputs and manifests separate. Include source licenses, model revisions and assistance disclosure. A code repository, five-minute demo recording and reproducibility commands are useful portfolio evidence.

## Rubric out of 100

| Dimension | Points | Full-credit evidence |
|---|---:|---|
| Task and dataset definition | 15 | Reviewed diverse tasks, group-aware split, provenance |
| Retrieval and grounding | 20 | Measured baselines, version controls, claim/source review |
| Adaptation experiment | 10 | Real checkpoint, controlled evaluation, honest conclusion |
| Tools and harness | 15 | Typed bounds, actual model-planner trial, trace-level evaluation |
| Evaluation quality | 15 | Raw paired outputs, failures, slices, uncertainty |
| Delivery and operations | 15 | Runnable API, manifest, telemetry, regression/rollback drill |
| Communication and reproducibility | 10 | Fresh-run instructions, defensible claims, limitations |

Missing a hard safety/reproducibility gate prevents course completion until repaired, even if the point total exceeds 70. If free GPU access delays a required measured training/CUDA task, mark it incomplete and schedule another session; do not label a skipped task completed.
