# Worked supplement and reference sheet

These examples deepen selected mechanisms without adding required study hours. Use them in place of optional reading or when correcting a test. All numbers are illustrative calculations.

## Byte pair encoding by hand

Start with a tiny corpus: low, low, lower. Begin from characters and an end-of-word marker: l o w _, l o w _, l o w e r _. Count adjacent pairs across the corpus. The pairs (l,o) and (o,w) each occur three times, while (w,_) occurs twice. Choose a deterministic tie rule, merge (l,o) into lo, then count again. The pair (lo,w) occurs three times, so merge into low. The resulting vocabulary now includes common pieces learned from counts. Real byte-level BPE starts from a byte vocabulary and has additional implementation details.

Encoding a new word applies the learned merge rules rather than fitting new rules on that word. A tokenizer trained on one corpus may split unfamiliar identifiers into many pieces. The tokenization used for training and serving must match. Changing the merge vocabulary changes the model's input/output ID interpretation, not merely its chunk lengths.

**Exercise:** add lowest twice, repeat three merge steps and explain which count changes. Do not interpret a merge's frequency as semantic importance.

## Softmax stability and cross entropy

For logits z, subtract max(z) before exponentiating: exp(z_i−m)/sum_j exp(z_j−m). This leaves probabilities unchanged because the common factor cancels, while reducing overflow risk. For logits (1000,999), direct exponentiation can overflow; shifted logits (0,−1) give approximately (.7311,.2689).

Cross entropy for target class two is −log(.2689)≈1.3133 nats. Computing a log-softmax or fused cross-entropy is generally more numerically stable than forming tiny probabilities and taking logs manually. A loss close to zero on train data can still reflect memorization or leakage.

## Residuals and normalization

Layer normalization subtracts the per-token feature mean and scales by the square root of feature variance plus epsilon, then applies learned affine parameters. RMS normalization scales by a root-mean-square statistic without subtracting the mean in its basic form. Both are per-token feature operations in this setting; they do not mix future positions. Residual addition requires compatible shapes.

In a pre-norm block, normalization occurs before the attention/MLP transformation and the residual stream remains an additive path. In post-norm, the addition is normalized afterward. These are meaningful architectural differences; our teaching implementation chooses one explicitly rather than claiming it is the only transformer design.

## Rotary position intuition

For a two-dimensional component pair, a rotation by angle theta maps (x1,x2) to (x1 cos theta−x2 sin theta, x1 sin theta+x2 cos theta). Applying position-dependent rotations to query/key component pairs can make their dot product depend on relative displacement. Different pairs use different frequencies. The construction explains a way of encoding position; it does not prove unlimited long-context extrapolation.

**Exercise:** rotate (1,0) by zero and by pi/2 and compute the dot product. Then rotate both vectors by the same angle: the relative dot product is unchanged. Relate this invariance to relative position.

## Query, key and value head counts

Standard multi-head attention uses the same number of query and KV heads. Multi-query attention shares one KV head among multiple query heads; grouped-query attention uses an intermediate number. Cache storage scales with KV heads, not merely query heads. A model can therefore have many query heads without storing separate cached keys/values for all of them.

Always inspect the actual architecture configuration before using a memory formula. Learned projections, head dimensions and number of layers matter. The 96 MiB week-9 example assumes the stated KV count, batch, precision and context length.

## KV-cache correctness

At generation step t, earlier positions' causal key/value states can be reused. Cache identity must include the actual preceding tokens and relevant model configuration. Reusing a cache after changing the system prompt, model weights or token prefix gives the wrong computation. Prefix caching in a server requires correct identity and authorization handling, especially when prompts can contain private content.

Caching accelerates repeated computation but does not improve evidence quality. Longer cached context still occupies memory. Batching and eviction policies can change throughput and tail latency.

## Sampling worked example

Let next-token probabilities be (.50,.30,.15,.05). With top-p=.8 and the convention that includes the token crossing/reaching the threshold, retain the first two tokens, then renormalize to (.625,.375). With top-k=3 retain the first three and renormalize by .95. Implementations may differ on boundary conventions, so inspect the selected library rather than assuming a universal tie rule.

Sampling several candidates multiplies generation work. If five candidates each use 100 output tokens, the generation budget is 500 output tokens before judging or verification. Report all of it.

## Chunking a technical page

Suppose a page contains a heading, a paragraph defining timeout_ms, a code block, an exception note and a version-change table. A fixed-length splitter can separate the exception from its rule or cut a code block in half. A structure-aware splitter first respects headings and code/table boundaries, then divides oversized sections with source offsets. Store parent ID, section path, version, offsets and content hash.

Overlap is a parameter to evaluate, not a requirement to maximize. Excessive overlap duplicates evidence and index storage. Compare chunk sizes with the embedding tokenizer's input limit and the generator context budget. An evidence recall improvement can disappear if useful text is truncated during embedding.

## Claim-level citation audit

Answer: “Version 2 defaults to 30000 ms and permits unlimited retries [timeout-v2].” The first claim is supported by timeout-v2. The second is unsupported and conflicts with the retry/config evidence. The source ID exists, the JSON could be valid and the first clause could be correct, yet the answer is unsafe to trust as a whole.

For a manual audit, split factual clauses, identify supporting passages and label supported, contradicted or not established. Track incomplete answers separately: a fully supported answer can omit a required caveat. For your project, score a reviewed subset at claim level and state the sample size. Do not label every response with a plausible citation “grounded.”

## Calibration and selective prediction

A cosine score of .82 is not an 82% correctness probability. To use a threshold, choose it on development examples under a specified corpus/model distribution. Plot or tabulate the tradeoff between answering more questions and making more unsupported answers. Preserve a held-out check of the selected threshold.

If 9 of 10 answered questions are correct, selective accuracy is 90%. If the system answered only 10 of 100 relevant tasks, coverage is 10%. Both numbers matter. An abstention policy must also distinguish genuine absence from retrieval failure.

## Quantization and resource estimates

An ideal four-bit representation uses .5 bytes per weight, but practical quantized layers also need scales, metadata and compatible kernels. Some tensors stay in higher precision. Activation memory and KV cache need separate accounting. A model that appears to fit by multiplying parameters by .5 can still OOM.

Quantization may alter outputs, so compare actual task behavior before deployment. A smaller file is not proof of lower latency on a device lacking an efficient kernel for that representation.

## Tool result semantics

The call validate_config({timeout_ms:0,retries:3}) can be a valid invocation of the validator while returning valid=false. That is not the same as an invalid tool-call schema containing an unexpected command field. Error taxonomies should distinguish proposal parsing, argument schema, authorization, tool execution, domain-invalid results and final-answer correctness.

Likewise, an agent's completed status means its controller accepted a final response. Your task checker must still verify that the requested calculation or validation occurred and that the response matches the result. Controller acceptance and task success are different metrics.

## A paper-reading routine

Spend ten minutes on the problem, task setup and main claim; ten minutes drawing the mechanism and following one equation's shapes; ten minutes checking the evaluation controls and one limitation. Write a prediction you could test on a smaller system. Read the whole paper later if that question requires it. For optional Stanford or Hung-yi Lee materials, use this routine to connect the source to your current lab rather than accumulating unwatched lectures.
