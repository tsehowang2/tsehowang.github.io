# Semester 1 Foundations of generative AI

## Week 1 From a model to a useful system

### The question

A developer asks, “How do I set a request timeout in version 2?” A fluent answer can still be useless: it might quote version 1, invent a parameter, or omit the relevant source. A useful assistant must choose evidence, respect the requested version, form an answer, and expose enough information for verification. Our unit of engineering is this complete interaction.

An LLM models a conditional distribution over token sequences. An application wraps it in data ingestion, retrieval, prompts, tools, validation, storage and serving. A model upgrade changes one component. It does not automatically repair missing documentation or an authorization bug. Your experience with data pipelines transfers directly to corpus lineage and index freshness, but answer quality introduces a new empirical evaluation problem.

### The mechanism

Represent a system run as `answer = F(question, corpus, model, prompt, tools, config)`. Each input must be identifiable. If the corpus or prompt changes without a version, a regression cannot be attributed. Begin with a task distribution: single-page lookup, version comparison, multi-page troubleshooting, tool calculation and questions whose answers are absent. For each, define what a correct result must contain.

Separate three measurements. Retrieval asks whether supporting evidence was found. Answer assessment asks whether claims follow from it. Task assessment asks whether the user's problem was solved. An answer may be grounded yet incomplete; retrieval may succeed while generation fails. A “good answer” score collapses these distinctions and makes debugging harder.

### Worked example

Suppose a 20-question development set contains 12 lookups, 4 multi-page questions and 4 unanswerable questions. The system answers 15 questions and gets 12 right. Answered-question accuracy is 12/15 = 80%; answer coverage is 15/20 = 75%. Overall correctness depends on the refusal labels as well. If all five refusals were appropriate, that is 17/20 correct decisions; if only two were appropriate, it is 14/20. Never report selective accuracy without coverage and refusal behavior.

This week build a deterministic lexical/evidence baseline before loading a model. The starter's invented docs let you inspect every mistake. Its extraction output is intentionally limited; the baseline establishes that ingestion and evaluation work independently of generation.

### Experiment and common failure

Create ten questions before changing the retriever. Write evidence IDs and expected facts yourself. Run notebook 01, inspect each result, and classify errors as missing data, wrong version, retrieval miss, unsupported claim, or unclear question. Record latency with the timing boundary explicitly stated. Do not select ten easy questions after seeing the outputs: that produces a demonstration, not an evaluation set.

**Exit criterion:** explain the difference between model quality and system quality, and reproduce the same baseline result from saved inputs. **Reading:** R02 overview; R03 evaluation topic. **Lab:** 01. **Test:** week 1.

## Week 2 Tokens and the generative AI landscape

### Intuition

A language model does not see words as humans do. A tokenizer maps text into integer IDs, and the model predicts IDs. The same technical identifier may occupy several tokens. Therefore context length, inference cost, sequence truncation and label alignment are token-level properties. Character count is only an estimate.

For an autoregressive model, `p(x1,...,xT) = product_t p(xt | x1,...,x(t-1))`. Training usually minimizes the negative log of these conditional probabilities. Generation samples or selects one token, appends it, and repeats. This objective is broader than question answering: prompts and post-training shape a general continuation model into an interface that follows instructions.

### Other model families

An encoder produces contextual representations using available input; a causal decoder predicts continuations; an encoder-decoder reads one sequence and produces another. An embedding model is optimized to make representation geometry useful for a task. Its output vector is not an answer.

Generative AI also includes images, audio and video. A variational autoencoder learns a latent distribution and decoder, balancing reconstruction with regularization. A GAN trains a generator against a discriminator. A diffusion model learns to reverse corruption over noise levels. A flow model learns an invertible transformation or, in flow matching, a vector field transporting one distribution toward another. These are different modeling strategies, not alternative names for an LLM. Our deep implementation path is autoregressive text; week 31 revisits multimodal implications.

### Tokenization worked example

For byte-level UTF-8 tokenization, “cat” uses three bytes while some characters use multiple bytes. A learned subword tokenizer may encode “timeout_ms” as several vocabulary entries. Neither scheme permits you to assume one token equals one word. The starter's byte tokenizer is an educational stand-in, not the tokenizer of Qwen or MiniLM.

Let a model allow 2,048 tokens. If fixed instructions use 180, history 300, retrieved evidence 1,100 and the user question 70, the input totals 1,650. Reserving 300 output tokens leaves 98 tokens of slack. Adding an apparently short code example may exceed that margin. Count the complete serialized chat template with the actual tokenizer; special tokens and role separators count too.

### Practical consequences

Store raw source text as well as tokenized views. Tokenizer changes can alter chunk size and training sequences even when the source file stays identical. Keep code blocks intact where possible, avoid splitting a parameter name from its explanation, and track source offsets. A vector embedding model and a generator may have different limits and tokenizers; satisfying one limit does not satisfy the other.

**Experiment:** compare byte counts and real tokenizer counts for prose, code, Chinese text and long identifiers. Explain a case where a character-based chunker silently truncates evidence. **Exit criterion:** compute a full input/output budget and distinguish four generative model families. **Reading:** R01 tokenization lecture headings; R03 image generation topic. **Lab:** 01.

## Week 3 Embeddings are learned coordinates

### Intuition

Imagine arranging documentation passages so passages useful for the same questions lie nearby. An embedding model learns such a coordinate system. “How long before a request expires?” may be close to a paragraph about “request timeout” even without matching words. But geometry reflects a training objective and data, not a universal notion of meaning.

An embedding function maps text to a vector `e(x) in R^d`. Cosine similarity is `(u dot v)/(norm(u) norm(v))`. With unit-normalized vectors, cosine equals the dot product, and squared Euclidean distance equals `2 - 2(u dot v)`. This equivalence depends on normalization. Raw dot product also rewards magnitude, which can change rankings.

### Learning the geometry

A contrastive objective brings positive query-passage pairs together while separating negatives. One common form is `-log exp(s(q,p+)/tau) / sum_j exp(s(q,pj)/tau)`. Temperature affects how strongly relative similarities are emphasized. Hard negatives resemble the question but are incorrect, such as the right parameter from the wrong version. In-batch negatives are convenient, but another query's positive can sometimes also be relevant to this query.

A sentence representation may pool contextual token states; raw token embeddings are not automatically good sentence vectors. A bi-encoder embeds query and document independently, allowing document vectors to be cached. A cross-encoder processes the pair jointly, often useful for reranking a smaller candidate set at greater query-time cost. Some retrieval models need different query/document prefixes. Follow the selected model card rather than assuming all embedding APIs are interchangeable.

### Worked example

For `q=(1,0)`, `a=(0.8,0.6)` and `b=(4,3)`, cosine is 0.8 for both passages because their direction is the same. Raw dot product is 0.8 for a and 4 for b. If the index uses cosine but a hand-written reranker uses raw dot product, you have changed the scoring function without meaning to.

An embedding dimension of 384 with float32 storage uses 1,536 bytes per vector. One million raw vectors use about 1.536 GB decimal before graph links, payloads, IDs, replicas and allocator overhead. Storage estimates must include these extras and the original text.

### Experiment

Notebook 02 computes geometry with NumPy. Later notebook 06 embeds documentation using an actual sentence-transformer. For now construct a lexical synonym pair, an exact API-name question and a wrong-version distractor. Predict which needs semantics and which needs exact matching. Compare your prediction with the measured result after week 11.

**Failure to recognize:** a high similarity score is not a calibrated probability that a document answers the question. Thresholds must be chosen on development data and evaluated on a held-out distribution. A vector model change normally requires rebuilding or migrating the index; equal dimension does not imply a shared coordinate system. **Reading:** R07, R22. **Lab:** 02.

## Week 4 Attention is content-dependent mixing

### Intuition

When reading “set timeout_ms before calling send,” the representation of “send” should incorporate useful earlier information. Attention lets every position form a weighted combination of available token representations. The weights depend on content and learned projections rather than a fixed window average.

For a single batch element with `X` shaped `[T,d_model]`, compute `Q=XWq`, `K=XWk`, and `V=XWv`. If the head dimension is `d_head`, Q and K have shape `[T,d_head]`. Scores `QK^T/sqrt(d_head)` have shape `[T,T]`. Apply the mask, take softmax over keys for each query row, and multiply by V. The output shape is `[T,d_head]`.

Why divide by the square root? Under a simplified independent unit-variance assumption, a dot product's variance grows with `d_head`. Scaling helps prevent logits from becoming so large that softmax saturates. The assumption is an intuition for the normalization, not a theorem about every learned layer.

### Masking is part of correctness

A causal mask forbids position i from attending to positions j greater than i. Apply negative infinity to forbidden logits before softmax; multiplying probabilities by zero afterward without renormalizing does not implement the same operation. Padding masks are separate: a padded token should not become useful evidence. Test both dimensions and handle sequences with at least one valid key per query to avoid all-masked softmax rows.

### Worked example

Take a query `(1,0)`, keys `(1,0)` and `(0,1)`, and values `(2,0)` and `(0,4)`. Scaled logits are approximately `(0.7071,0)`. Softmax gives `(0.6698,0.3302)`, so the mixed result is about `(1.3395,1.3208)`. If the second key is future context, causal masking changes the result to `(2,0)`. Verify these numbers in notebook 02.

Multiple heads learn different projections, concatenate their outputs and project back into the residual stream. A head need not correspond to a simple human concept. Attention weights alone are not a complete explanation of why a model answered: values, residual connections and later layers also matter.

### Experiment

Implement attention without an attention library. Change only the last input token and assert earlier outputs remain unchanged under the causal mask. Then remove the mask and observe the failing invariance. This test catches leakage even if training loss looks excellent. Estimate score-matrix storage for increasing T: the quadratic T dimension matters before you optimize anything.

**Exit criterion:** derive every tensor shape, reproduce the worked example, and explain why a mask bug creates misleading language-model performance. **Reading:** R04 attention equation and diagram. **Lab:** 02. **Assessment:** checkpoint A and weekly test.

## Week 5 The decoder transformer

### Intuition

Attention moves information across positions. A feed-forward network transforms information within a position. A transformer block combines both operations with residual connections and normalization, and stacking blocks allows progressively richer computation. The output head converts the final representation at each position into vocabulary logits.

Our teaching model uses token embeddings plus learned position embeddings. A pre-normalization block is `h = x + Attention(LayerNorm(x))`, followed by `y = h + MLP(LayerNorm(h))`. The MLP expands the channel dimension, applies a nonlinearity, and projects back. Residual paths help gradients and preserve information. Modern models may use RMSNorm, rotary position embeddings, gated MLPs or grouped-query attention; these modifications do not remove the basic information-flow picture.

### Shapes and parameters

For batch B, length T and width D, the residual tensor is `[B,T,D]`. An MLP with expansion 4D has roughly `8D^2` weight parameters, ignoring biases. Standard multi-head attention's Q, K, V and output matrices contribute roughly `4D^2`. A rough block count is therefore `12D^2`; embeddings and output layers may dominate for a large vocabulary. Tied input/output embeddings reuse weights, changing the total.

For D=64 and two blocks, block matrices contain about `2*12*64^2 = 98,304` parameters. A 256-token embedding table adds 16,384. This is a tiny educational model, not an LLM. Counting parameters by summing `p.numel()` is the authoritative implementation check.

### Position and context

Without position information, pure self-attention cannot generally distinguish permutations of the same unmasked set in the intended way. Learned absolute embeddings assign a vector to each position. Rotary position methods rotate query/key components so relative displacement influences their dot products. Do not assume a position method alone grants reliable extrapolation beyond trained context lengths.

The model outputs one logit vector per input position. During training, the logit at position t predicts the token at t+1. During inference, use the last position's logits to select the next token. For encoder-decoder models, cross-attention additionally reads encoder outputs; our tiny model has no encoder.

### Experiment

Notebook 03 trains a byte-level decoder on the invented docs. Draw the block before running it, count parameters, and overfit a tiny batch as a debugging step. Then restore a held-out sequence split and report validation loss. Compare removing attention versus removing the MLP while keeping the training budget fixed. A larger model trained for more steps is not a clean architectural ablation.

**Failure to recognize:** generating plausible fragments from a tiny repeated corpus is not evidence of general documentation understanding. It demonstrates that the model and training loop run. **Reading:** R04 model architecture; optional R01 architectures lecture. **Lab:** 03.

## Week 6 Pretraining objectives and data discipline

### From prediction to loss

Given token IDs `x[0:T+1]`, the input is `x[0:T]` and the target is `x[1:T+1]`. For logits z at a position, cross entropy is `-log softmax(z)[target]`. The language-model loss averages over valid target positions. If the model assigns probability 0.25 to each correct token, loss is `-log(0.25)=1.3863` nats and perplexity is 4. Perplexity is comparable only under appropriate matching tokenization and evaluation conditions.

Padding targets should be ignored. In SFT later, prompt positions may also be ignored while answer positions receive loss. Confusing an attention mask with a loss mask is a common bug: one controls information access, the other controls which predictions are supervised.

### Data quality is an engineering problem

Pretraining data pipelines filter, deduplicate, segment and tokenize. Duplicated or near-duplicated documents crossing train/test boundaries can create inflated evaluations. Split at a meaningful group boundary before producing overlapping chunks. For documentation, a page family or API topic may be a stronger group than an arbitrary text span. Keep version, license, origin, time and transformation metadata.

Gradient descent reduces training loss but does not guarantee the desired application behavior. Use training and validation curves to separate underfitting, overfitting and implementation bugs. Validate with dropout disabled and gradients off, without accidentally leaving the model in evaluation mode for the next training batch.

### Worked optimization example

If the microbatch size is 2 and you accumulate gradients across 8 microbatches on one device, the effective example batch is 16, provided each microbatch is equally sized. Divide each microbatch's loss by 8 before backpropagation, step the optimizer once, and clear gradients afterward. If sequence lengths vary, equal averaging of microbatch means may not equal a global valid-token average. Account for token counts when exact equivalence matters.

Adam-style optimizers maintain moment estimates, adding substantial memory. Learning-rate warmup and clipping can stabilize some settings, but first verify labels, masks and data. A scheduler cannot repair training on the wrong target. Save optimizer state, random states, tokenizer identity and current step if you want faithful resume behavior.

### Experiment

In notebook 03, compare train/dev losses for one fixed configuration over time. Intentionally train with unshifted labels once and explain why the task changes. Try a one-batch overfit test, then an actual grouped split. The starter's tiny corpus is too small for strong statistical conclusions; your report should say so.

**Exit criterion:** implement shifted labels, explain perplexity and list the artifacts needed to resume a training run. **Reading:** R01 data and optimization lecture headings. **Lab:** 03.

## Week 7 Decoding and the chat contract

### Intuition

The model produces a distribution, but a decoder decides how to turn it into text. Greedy decoding takes the highest-scoring next token. Temperature rescales logits before sampling. Top-k restricts to k candidates; top-p restricts to a probability-mass subset. These choices alter behavior, latency and reproducibility. Lower temperature does not make facts true.

Suppose two logits are `(2,0)`. With temperature 1 the first-token probability is about 0.881. With temperature 2 it is about 0.731; with temperature 0.5 it is about 0.982. Greedy decoding is a separate argmax procedure; do not implement it by dividing by temperature zero.

### Messages are serialized input

A chat model still receives tokens. Its tokenizer's chat template encodes role separators, message delimiters and the beginning of the assistant response. A hand-written string saying “system:” is not necessarily equivalent. Use the model's own `apply_chat_template`, inspect a rendered example, and avoid adding special tokens twice. In notebook 04, generation uses only newly produced tokens, not the prompt echoed back as an answer.

Instruction hierarchy and context construction influence behavior, but a prompt is not a security boundary. Retrieved pages can contain imperative text. Treat them as evidence whose authority is bounded by application policy. The model can suggest an action; only code with explicit authorization may execute it.

### Output contracts

For our assistant, require an answer or an explicit insufficiency message, source IDs, and the requested version. Structured output helps downstream parsing, but JSON syntax alone does not establish truth. Validate fields, types, allowed IDs and evidence relationships. A citation to an existing page can still be irrelevant to the claim.

Generation needs termination rules: maximum new tokens, stop sequences where appropriate, request timeout and cancellation. A model can spend the entire output budget repeating itself. Include truncation and parse failure in evaluation, rather than dropping those examples from the denominator.

### Experiment

Notebook 04 loads a small instruction model, serializes messages with its chat template, and answers a versioned documentation question using supplied evidence. Compare greedy decoding and sampling across repeated runs with fixed inputs. Record model revision and the actual prompt token count. A seed improves reproducibility but does not promise identical outputs across different kernels, hardware or software versions.

**Common failure:** the question asks about version 2 while the context includes both versions with no labels. More eloquent wording will not reliably repair ambiguous evidence. Filter and label the context first. **Reading:** R09 and R23. **Lab:** 04.

## Week 8 Reasoning and chain of thought

### Intuition

Some questions require intermediate computation: “If each retry doubles a 100 ms backoff, what is the delay before attempt four?” Asking for intermediate steps can help some models and tasks, but a polished explanation can accompany a wrong answer. Treat reasoning approaches as experimental interventions, with answer correctness and resource use measured separately.

Chain-of-thought prompting supplies or requests intermediate reasoning before an answer. Reasoning-trained models may use additional inference computation without exposing every internal step. A displayed rationale is generated text; it is not a reliable transcript of internal causality. For deployment, request a concise justification, evidence and verifiable results rather than storing unrestricted deliberation.

### Mechanisms to compare

Direct answering minimizes tokens. Decomposition splits a task into explicit subproblems. Self-consistency samples multiple solutions and aggregates final answers; it can help when errors vary, but correlated errors remain. A verifier checks candidate results, often with executable tests or source evidence. Search explores alternative actions or solutions under a budget. More inference computation creates a cost/quality tradeoff, not a guarantee.

### Worked example

Assume the first retry delay is 100 ms, then 200 ms, then 400 ms, with no jitter. The delay immediately before the fourth attempt is 400 ms; the cumulative waiting time before that attempt is 700 ms. If the wording does not distinguish these, both evaluation and generation become ambiguous. Define the task before comparing prompting methods.

For documentation, a stronger approach is often to retrieve the authoritative retry rule and pass numerical arguments to a calculator. The executable result can be independently checked. A long free-text calculation without the correct version of the retry rule remains unreliable.

### Experiment

Prepare 20 development tasks: ten arithmetic or configuration tasks with executable answers, five source lookups, and five ambiguous/unsupported requests. Compare direct answers, concise decomposition and tool-assisted verification using the same model and task set. Record exact answer accuracy, unsupported-claim rate, token count, latency and parse failures. If you sample multiple candidates, report the total generation budget, not the cost of the winning candidate alone.

Use the checkpoint quiz before reading its solutions. Write down one hypothesis about where reasoning helps and another about where it adds unnecessary work. Your conclusion may be that a small model cannot perform the chosen tasks reliably; that is a valid measured result.

**Exit criterion:** distinguish CoT, reasoning training, verification and tool execution, and explain why rationale quality is not the same as answer correctness. **Reading:** R10; optional R03 reasoning/context-engineering videos. **Lab:** 04. **Assessment:** checkpoint B.
