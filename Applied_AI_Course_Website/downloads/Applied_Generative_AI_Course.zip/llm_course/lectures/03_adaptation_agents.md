# Semester 2 Adaptation and agents

## Week 17 Choose what to adapt

### Intuition

When an assistant fails, changing model weights is only one possible intervention. Missing source material suggests ingestion. Missing relevant passages suggests retrieval. An answer that ignores available evidence suggests context, prompting or model capability. Consistently wrong output format may be a candidate for supervised fine-tuning. Diagnose the failed boundary before paying a training cost.

Prompting changes instructions and demonstrations at inference time. RAG changes the information supplied. Supervised fine-tuning changes parameters to imitate desired outputs. Continued pretraining changes parameters through a language-model objective on new text. Preference optimization changes relative preferences among possible responses. These methods can coexist, but they solve different immediate problems and have different update costs.

### SFT dataset design

An SFT example contains inputs and a target response. For our assistant, teach a narrow behavior such as selecting a valid tool or producing an evidence-referencing JSON answer. Include answerable tasks, insufficiency cases, version-specific evidence and tool failures. If every example is answerable, the model may learn that producing an answer is always rewarded.

The target must be correct under the supplied context. A synthetic generator can create plausible but wrong examples; manually audit a sample and use executable or source checks where possible. Save provenance and generation settings. Split by task family or documentation group before making paraphrases. Otherwise stylistic near-duplicates can leak into evaluation.

### Worked intervention decision

Imagine 50 development failures: 25 have missing evidence, 10 contain the right evidence but invalid JSON, 10 require an unavailable calculation tool, and 5 are genuinely ambiguous. Training on all 50 would mix four causes. Fix ingestion/retrieval first, add a typed calculation interface, and clarify ambiguous tasks. Fine-tune format adherence only if prompt/schema constraints still leave a measured gap.

For an answer-only loss, mask prompt tokens with an ignored label and supervise answer tokens. Keep the evidence in the input. Do not train on the final held-out labels or use the hidden test set to choose the number of epochs. Record truncation rates; an example whose target is cut away provides no intended supervision.

### Experiment

Notebook 09 builds training records, checks source IDs and splits grouped tasks. Its tiny synthetic examples teach the data pipeline, not a useful production behavior. Build a larger, reviewed development dataset for your real project. Before training, write a prediction: which metric should improve and which might regress? Keep the frozen RAG baseline for comparison.

**Exit criterion:** justify SFT with an error taxonomy and construct a leakage-aware dataset. **Reading:** R01 post-training topic; R14 configuration overview. **Lab:** 09.

## Week 18 LoRA and quantized adaptation

### Mechanism

A dense layer computes `y = W x`. LoRA freezes W and learns `delta_W = (alpha/r) B A`, so `y = W x + (alpha/r) B A x`. For W shaped `[d_out,d_in]`, A has `[r,d_in]` and B `[d_out,r]`. Only `r*(d_in+d_out)` adapter parameters are trained for that layer. The choice of target layers is part of the experiment.

For a 4096×4096 matrix and r=8, the dense matrix has 16,777,216 parameters while A and B total 65,536, about 0.39%. This reduces trainable optimizer state substantially. It does not eliminate frozen model storage, activations or forward/backward computation through the model. LoRA can be applied to attention projections and other layers; examine actual module names rather than copying a configuration blindly.

### Initialization and scaling

A common initialization makes one factor zero so the initial update is zero while the other factor is random. Then the adapted model initially reproduces the base computation, apart from training-mode effects such as dropout. If both factors are zero, both factor gradients can initially be zero. Rank controls update capacity, not a guaranteed quality ordering. Increasing rank also changes parameters and potentially tuning behavior, so compare under a defined budget.

### QLoRA

QLoRA combines a quantized frozen base with low-rank trainable adapters [R13]. Four-bit base weights do not imply every tensor or calculation is four-bit. Quantization scales, compute dtype, adapters, gradients, optimizer states and activations remain relevant. Specialized backend support depends on hardware and software. The course requires a small ordinary LoRA run; a QLoRA comparison is optional if the available runtime supports it.

### Deployment considerations

Save the adapter with base model/tokenizer identity and target modules. An adapter checkpoint alone is insufficient if the base revision is unknown. Merging low-rank weights into a compatible unquantized base can remove the separate adapter path, but numerical behavior and quantized merge support require checking. Test the saved/reloaded artifact, not just the in-memory training object.

### Experiment

Notebook 09 calculates trainable parameter counts and inspects a planned model. Notebook 10 creates actual adapters and confirms which parameters receive gradients. Compare your analytical count with the model's count and explain biases or excluded modules. Estimate memory before loading, then measure after the first training step.

**Exit criterion:** derive LoRA shapes, explain the zero-update initialization, and distinguish LoRA from QLoRA. **Reading:** R12 method, R13 overview, R14. **Lab:** 09.

## Week 19 Run and evaluate a fine-tuning experiment

### Intuition

Training loss answers whether the model is fitting its supervised targets. The application question is whether the saved adapter improves the target task without unacceptable regressions. A completed experiment includes a baseline, a controlled training run, a held-out comparison and a reproducible checkpoint.

Use the same base revision, task contexts, decoding settings and evaluation parser for base and adapted models. If you improve the prompt while adding an adapter, run a separate prompt-only control. A minimal comparison matrix is base prompt, improved prompt, improved prompt plus RAG, and RAG plus adapter, with constraints appropriate to the task. Do not demand every combination when it cannot answer the research question.

### Training mechanics

Use a small batch, a short sequence length, gradient accumulation and checkpoints. Start with a few batches to verify valid-token counts, nonzero gradients and finite loss. Clip gradients if your chosen setup needs it. Disable inference-only caches during training when required by the model. Use the actual chat template consistently for preparation and evaluation.

Prompt loss masking must match serialization. The tutorial uses a single user message and assistant response, tokenizes the prefix and full conversation without duplicate special tokens, and checks that prefix IDs match the full prefix. Reject or redesign examples if this assumption fails. More complex multi-turn data needs a proper assistant-token mask, not a guess based on string length.

### Worked result interpretation

Suppose JSON validity rises from 80% to 96% while factual completeness stays at 70% and inappropriate answers to unsupported questions rise from 5% to 15%. The adapter learned formatting, but the release is not clearly better. A smaller loss or more valid JSON does not excuse a refusal regression. Inspect which training examples rewarded overconfident answering.

### Experiment

Notebook 10 runs a short small-model LoRA adaptation and saves the adapter, tokenizer and training metadata. The bundled task is deliberately narrow and tiny; do not infer generalization from it. Your required project report uses reviewed training data and independent development cases, or clearly labels a small pilot when resources/data are insufficient.

Measure runtime, peak GPU memory, trainable parameter count, task correctness, format validity and unsupported-answer behavior. Reload the saved adapter in a clean session and re-evaluate a smoke set. If quality does not improve, document the negative result and keep the stronger baseline for your final release.

**Exit criterion:** reproduce an actual small training run and defend whether its artifact should be deployed. **Reading:** R14 adapter save/load; R18 precision. **Lab:** 10.

## Week 20 Alignment, preferences and distillation

### Intuition

SFT says “imitate this answer.” Preference data says “prefer this answer to that answer for this prompt.” These signals do not directly encode universal truth. A rater may favor a pleasant but incorrect answer, and a teacher model may produce systematic errors.

RLHF often includes a preference-derived reward model and reinforcement learning against it. A reference-policy constraint helps limit uncontrolled policy drift. RL with verifiable rewards uses checkable outcomes, such as a correct executable result, but the checker itself can be incomplete or exploitable. A high reward on a narrow checker is not proof of broad reliability.

### DPO mechanism

DPO trains directly on preferred and rejected responses relative to a reference model. One form minimizes `-log sigmoid(beta * [(log pi(y+|x)-log pi_ref(y+|x)) - (log pi(y-|x)-log pi_ref(y-|x))])`. The bracket compares relative policy changes, not just raw sequence likelihoods. beta is a tuning parameter controlling this relationship; its practical effect depends on the setup.

If the preferred response improves relative to the rejected response, the loss decreases. But mislabeled preference pairs can optimize the wrong behavior. Deduplicate pairs, audit contradictory labels, and ensure answers are judged against the same context and task.

### Distillation and forgetting

Distillation trains a student using a teacher's outputs, probabilities or demonstrations. It can transfer behavior economically, but the student may inherit teacher errors or learn superficial formatting. Record provenance and verify the teacher-generated data. Fine-tuning can also weaken previously useful behavior; evaluate general-format, refusal and basic instruction-following cases alongside the narrow task.

### Worked comparison

A teacher produces a long explanation with a wrong API name; a shorter response cites the correct source and admits an unresolved version difference. If a preference label rewards length, the system may optimize verbosity rather than correctness. Write a rubric with factuality, evidence, completeness and action validity before collecting labels.

### Experiment

Notebook 10 includes a numerical DPO loss calculation, not a full RLHF training pipeline. Create 20 preference pairs from your development failures, label them using an explicit rubric, and check agreement on a small blinded re-labeling pass. Identify one case where a binary preference hides a meaningful tradeoff. Full DPO/RL training is an optional extension that replaces another experiment if chosen.

**Exit criterion:** distinguish SFT, reward-model RLHF, DPO, verifiable rewards and distillation, and explain the risk of optimizing a proxy. **Reading:** R15 objective; R03 post-training topic. **Lab:** 10.

## Week 21 Tools are typed capabilities

### Intuition

A model can propose calling a calculator, looking up a document, or inspecting a configuration. It does not gain authority merely by naming a function. A tool interface specifies which operations exist, which arguments are valid, and how results are returned. Application code enforces those rules.

Define a tool by name, input schema, output schema, authorization requirements, failure states and side effects. Separate read-only tools from actions that change external state. For this course, executable tools are a bounded arithmetic calculator and a fixed configuration validator. Neither exposes arbitrary Python evaluation, shell commands, network requests or file writes.

### Validation layers

Parse the model response; validate its shape; check the tool name; validate argument keys/types/ranges; enforce authorization; execute with time/resource limits; normalize the observation; log the outcome. Never use `eval` on model-generated expressions. The bundled calculator parses an arithmetic AST, accepts a narrow operator set and caps length, tree size and numerical magnitude. These checks are instructional, not a general sandbox for arbitrary code.

### Worked contract

`validate_config` accepts exactly `timeout_ms` as an integer in a documented range and `retries` as an integer in a documented range. An input containing an extra `command` field is rejected. An integer field should not silently accept Python's boolean subtype. The observation returns `valid` plus explicit errors; it does not return an unstructured exception traceback to the model.

Idempotency matters for side effects. Retrying a document lookup is usually harmless; retrying a deployment may create multiple releases. A real side-effecting tool needs an idempotency key, authorization and explicit retry semantics. We study these contracts without exposing deployment tools in the starter.

### Experiment

Notebook 11 exercises valid calls, unknown tools, missing arguments, oversized expressions, division by zero, extra fields and invalid value ranges. Predict whether each should be rejected before execution or reported as a tool failure. Build a small table of observable outcomes and expected traces.

The documentation assistant's useful executable behavior is narrow: calculate a retry delay from retrieved rules or validate a proposed configuration against the selected version. Generic shell access would expand risk and evaluation scope far beyond the task. Add capabilities only when an actual user task requires them.

**Exit criterion:** draw the boundary between a model's proposed call and authorized execution, and implement validation outside the prompt. **Reading:** R11 actions/observations; R03 agent/context topic. **Lab:** 11.

## Week 22 Agents and harnesses

### Intuition

A workflow has a largely predetermined control path. An agent lets model outputs influence which action happens next. Both need orchestration code. Agentic behavior is useful when tasks require adapting to observations; it can be unnecessary overhead for a fixed lookup.

The word harness has two relevant meanings. An **agent execution harness** manages state, model calls, tools, budgets, observation limits, cancellation and termination. An **evaluation harness** loads tasks, runs a specified system, records results and computes metrics. They may integrate, but they have different responsibilities. Naming both prevents the vague claim “we have a harness” from hiding missing controls.

### State and transitions

Represent state explicitly: question, allowed version, evidence IDs, observations, step count, token/cost budget, status and error. A planner proposes either a tool action or a final response. A controller validates it, executes allowed actions and updates state. Termination reasons include success, invalid proposal, tool failure, step exhaustion, timeout and cancellation. Every path must be observable.

### Worked trace

Step 1 retrieves retry rules. Step 2 calls a calculator with a bounded expression. Step 3 answers with the numerical result and source IDs. A repeated failed calculator call should not run forever. With a maximum of three planner steps, a proposal on the final step that still requires another observation should end with an explicit budget-exhausted status rather than a fabricated final answer.

Wall-clock limits require real enforcement. Checking elapsed time only after a blocking call returns cannot interrupt that call. Use client timeouts for network tools and process/container limits for untrusted execution. Our synchronous starter enforces step limits and arithmetic bounds; its deployment extension requires per-call timeout/cancellation implementations.

### Experiment

Notebook 11 runs a deterministic planner through the controller to test the execution contract. This is a controller fixture, not evidence of LLM planning. Notebook 12 connects a real model planner. Inject a planner that never stops, one that returns malformed JSON and one that invents a tool. Verify explicit terminal states and a finite number of tool calls.

For each trace, ask whether the information shown to the model is necessary. Large tool outputs can overflow context or carry adversarial instructions. Bound and label observations, preserve authoritative metadata separately, and avoid treating tool text as new policy.

**Exit criterion:** implement a bounded state machine and distinguish execution from evaluation harnesses. **Reading:** R11; R03 context engineering topic. **Lab:** 11.

## Week 23 Planning and memory

### Intuition

An agent's “memory” can mean its current prompt, a task scratch state, retrieved documents, or a persistent store of previous interactions. These have different retention and trust properties. More remembered text is not automatically more useful context.

Maintain a typed task state for facts such as requested version, selected source IDs and tool outcomes. Summaries can compress long histories, but they can omit an exception or turn an uncertain observation into a confident assertion. Preserve critical constraints in structured fields and retain source provenance.

### Planning patterns

ReAct-style systems interleave action selection and observations. Plan-and-execute generates a plan and then performs it, potentially revising it when observations disagree. Routing chooses a specialized workflow. Multi-agent systems distribute roles but add coordination, duplicated context, cost and evaluation complexity. A single bounded controller is the core path here; multi-agent implementation is not required.

A fixed workflow for versioned lookup may be retrieve, pack, answer and validate. A troubleshooting task may benefit from conditional actions: inspect version, retrieve a rule, validate a config, then explain the first violated requirement. The latter supplies a concrete reason for adaptive planning.

### Worked memory failure

A user first asks about v1, then says “now compare that with v2.” A summary storing only “user uses v1” can cause the next retrieval to filter out v2. Keep the task's allowed versions and comparison intent explicit. Authorization should come from authenticated application state, never from conversational memory or model-generated summaries.

### Experiment

Notebook 12 converts a small model's JSON proposal into a controller action. Compare it with a fixed workflow on the same set of lookups, calculations and troubleshooting tasks. Count invalid proposals, unnecessary tool calls, missed required actions, completion, latency and total model tokens. A small model may fail often; use those traces to decide where a deterministic route is preferable.

Test a long irrelevant observation and a misleading instruction embedded in a retrieved page. Verify that policy fields stay outside the model's authority. A failed model proposal must produce a controlled result, not fall back to executing guessed arguments.

**Exit criterion:** justify adaptive planning for a specific task and identify which state belongs in structured memory. **Reading:** R11; R03 context engineering. **Lab:** 12.

## Week 24 Evaluate the agent as a task performer

### Intuition

A convincing final sentence can hide a failed or forbidden action. Agent evaluation must inspect the environment and trace, not merely score final text. For read-only tools, correctness includes choosing the right evidence and calculation. For side effects in a future extension, it also includes the final state and the absence of unintended changes.

Define tasks with initial state, allowed actions, expected results and success predicates. Compare a model-only answer, a fixed tool workflow and the adaptive controller. Keep the tool affordances and budgets comparable. An agent given ten attempts should not be compared with a workflow allowed only one without reporting that difference.

### Metrics and recovery

Task success, valid-call rate, forbidden-action rate, tool failures, step count, budget exhaustion and cost are complementary. A system that never calls a tool can have a perfect valid-call rate on an empty denominator; report how often it used tools and whether tasks required them. Failure should be typed so analysis can separate planning, validation, execution and answer errors.

Retries must be bounded and appropriate. A transient read timeout may merit one backoff/retry. Repeating invalid arguments does not repair the schema. A non-idempotent side effect cannot be retried blindly. A circuit breaker limits repeated calls to a failing dependency; it does not replace correct per-request handling.

### Worked audit

An agent completes 18/20 tasks, but one successful task includes an unauthorized call that happened to return harmless data. Under a zero-forbidden-action release gate, it fails. Another system completes 17/20 with no violations and clearly reports three controlled failures. Depending on requirements, the latter may be the deployable candidate. State the gate before evaluating.

### Experiment

Create at least 20 tool tasks with deterministic checkers, including division by zero, unknown tool, wrong version, invalid config, misleading documentation and a forced step-limit failure. Run notebook 12, preserve full action/observation traces, and hand-audit a sample. Report failure counts even when the final answer looks reasonable.

For open-ended troubleshooting, use a rubric plus manual review rather than pretending one exact string captures success. Your project report should include one case where the agent adds value and one where the fixed workflow is simpler and equally effective. If the agent never improves your tasks, it can remain an evaluated experimental branch rather than the default product.

**Exit criterion:** defend an agent release decision using trace-level evidence and recovery behavior. **Reading:** R02 stakeholder requirements; R11 task/action evaluation. **Lab:** 12.
