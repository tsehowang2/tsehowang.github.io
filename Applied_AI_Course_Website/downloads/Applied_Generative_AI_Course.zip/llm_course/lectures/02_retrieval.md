# Semester 1 Hardware and retrieval systems

## Week 9 Hardware and memory accounting

### Intuition

A GPU accelerates many similar arithmetic operations, but a model must also move data and fit its working state into memory. “More FLOPs” alone does not predict whether your experiment will run or be fast. Distinguish CPU RAM, GPU VRAM, device memory bandwidth, host-to-device transfers and compute throughput.

The CPU schedules work and launches kernels. GPU execution groups threads across streaming multiprocessors. Registers are close to individual execution contexts, shared memory is visible within a block, caches serve broader access, and device DRAM stores large tensors. A tensor moving repeatedly between CPU and GPU can dominate a short computation even if the arithmetic is fast.

### Training versus inference

Parameter storage is `parameter_count * bytes_per_parameter`. Training may additionally store gradients, optimizer moments, master weights and activations. For an illustrative mixed-precision Adam configuration, 2 bytes of model weights + 2 bytes of gradients + 4 bytes of master weights + 8 bytes of two moments gives 16 bytes per parameter before activations and overhead. This is an example configuration, not a universal rule; frameworks and precision choices differ.

For 500 million parameters, that illustrative state is 8 GB decimal. A 2-byte inference weight copy alone is 1 GB decimal. A model that fits for inference can therefore fail in training. LoRA reduces trainable parameter state, but activations and frozen base weights still occupy memory.

### KV cache worked example

During autoregressive inference, cached keys and values avoid recomputing earlier projections. An approximate KV-cache size is `2 * layers * batch * tokens * kv_heads * head_dim * bytes`. For 24 layers, batch 1, 2,048 tokens, 8 KV heads, dimension 64 and 2-byte values, the cache is 100,663,296 bytes, or 96 MiB. Increasing batch or context multiplies this. Grouped-query attention can use fewer KV heads than query heads.

The original full attention score tensor also scales quadratically in sequence length when explicitly materialized. Memory-efficient attention implementations avoid storing all those intermediate scores in device DRAM, while retaining the operation's mathematical meaning subject to numerical precision differences.

### Experiment

Notebook 05 measures the device rather than assuming its capabilities. Calculate weight, optimizer and KV-cache estimates on paper, then compare allocated and peak memory. Account for warmup and allocator reservations. When an out-of-memory error occurs, reduce sequence length and microbatch before reaching for a different framework. Gradient accumulation changes effective batch but does not shrink the memory required by a single microbatch.

**Exit criterion:** explain why a model fits inference but not training, and estimate a context-dependent cache. **Reading:** R01 resource-accounting topic; R16 memory hierarchy. **Lab:** 05.

## Week 10 CUDA programming and honest profiling

### Intuition

PyTorch operations eventually execute kernels. A CUDA kernel specifies work for many threads. Writing one small kernel makes launch overhead, indexing, memory access and synchronization concrete, even if most application work should continue using optimized libraries.

For a one-dimensional array, thread index `i = blockIdx.x * blockDim.x + threadIdx.x`. A vector-add kernel computes `c[i]=a[i]+b[i]` when `i<n`. The bounds check matters when n is not divisible by the block size. Blocks are scheduled independently; code must not assume a general grid-wide barrier inside an ordinary kernel.

### Memory and performance

Adjacent threads reading adjacent elements often produce more efficient memory transactions than scattered accesses. Shared memory can reuse data within a block, but reuse must justify its loading and synchronization overhead. A barrier must be reached consistently by participating threads. Occupancy is one diagnostic, not an objective that guarantees maximum speed.

Arithmetic intensity is approximate operations divided by bytes moved. Vector addition performs roughly one addition for two input reads and one output write: about 1/12 operations per byte for float32, ignoring caching. This is low intensity, so increasing theoretical arithmetic throughput may help little compared with memory bandwidth. A matrix multiplication can reuse tiles and attain much higher intensity.

### Timing worked example

GPU work is asynchronous relative to the host. Timing a launch without synchronizing may mostly measure dispatch. Use CUDA events or synchronization around the defined measurement interval. Warm up first, repeat the operation, and report a median and spread. Include data transfers only if your stated question is end-to-end latency; separately report kernel-only time when studying the device operation.

Suppose end-to-end time is 20 ms, of which 3 ms is the kernel. Making the kernel twice as fast yields 18.5 ms total, a speedup of only 1.081. This is Amdahl-style reasoning: optimize what dominates the real task.

### Experiment

Notebook 05 compiles the bundled vector-add example if `nvcc` and a GPU are present. Run n=1, n=257 and a large n to exercise indexing and overhead. Compare against a CPU reference with a numerical tolerance. Then profile a PyTorch matrix multiplication or a short transformer forward pass. Save the trace and explain one bottleneck. FlashAttention is a deeper example of redesigning memory traffic rather than changing the attention objective [R26].

**Failure to recognize:** comparing a cold first call with a warmed library call measures setup differences. A benchmark that produces wrong values is not a performance result. **Reading:** R17 indexing example, R19 profiling; optional R26. **Lab:** 05.

## Week 11 Retrieval begins with a benchmark

### Intuition

A retriever must rank useful evidence, not merely related text. Exact API names and error codes favor lexical matching; paraphrased intent may favor semantic matching. Start with both kinds of questions and a simple baseline. Choose a scoring method because it addresses an observed failure, not because it has “vector” in its name.

An inverted index maps terms to matching documents. TF-IDF weights frequent-in-document but rare-in-corpus terms. BM25 additionally uses term-frequency saturation and document-length normalization. Dense retrieval encodes queries and passages into a shared vector space and compares them. A lexical baseline provides a valuable control for dense retrieval, especially on technical symbols.

### Relevance and metrics

Let G be the set of relevant evidence IDs and Rk the first k returned IDs. Recall@k is `|G intersection Rk| / |G|`. Hit@k is one if any relevant item appears. Reciprocal rank is `1/r` for the first relevant rank r, zero if none appears. When more than one passage is relevant, Hit@k and Recall@k answer different questions. NDCG can represent graded relevance and position discounts, provided the relevance labels and normalization are defined.

### Worked example

If G={A,B} and the first three results are C,A,D, Hit@3=1, Recall@3=1/2 and reciprocal rank=1/2. A report calling Hit@3 “recall” hides the missing second piece of evidence. For a comparison task requiring both versions, that missing piece may make the answer impossible.

For unanswerable questions with no relevant evidence, the ordinary recall denominator is zero. Do not silently assign perfect recall. Evaluate those questions separately through refusal, false-positive retrieval or unsupported-answer measures. The starter represents their retrieval metrics as not applicable.

### Experiment

Notebook 06 compares the bundled lexical retriever with actual sentence-transformer embeddings. Keep document chunks, questions, version filtering and k fixed. Include exact identifiers, paraphrases and wrong-version distractors. Save per-query ranks before computing averages; a mean can hide a systematic class of failures.

Separate model failure from ingestion failure. Inspect whether the expected passage actually exists in the index, whether truncation removed its key sentence, and whether metadata filters excluded it. For the real capstone, label enough question types that one example cannot dominate a slice. The tiny teaching fixture is a software correctness aid, not a sufficient research dataset.

**Exit criterion:** calculate recall, hit rate and reciprocal rank by hand, then explain a dense-versus-lexical tradeoff using a real failure. **Reading:** R07 and R25 concepts. **Lab:** 06.

## Week 12 A vector database is a maintained index

### Intuition

A list of vectors and cosine scores demonstrates semantic search. A vector database adds persistent collections, metadata, updates, filtering and operational behavior. These matter because documentation changes while users keep querying. The index is an artifact with a lifecycle, not a one-time preprocessing step.

Store each point with a stable ID, embedding, source reference, version, content hash and payload. Track the embedding model and tokenizer revision in the collection manifest. Two models can both output 384 numbers yet produce incompatible geometries. A model migration normally requires re-embedding and creating or rebuilding an index; do not mix vectors because their dimensions match.

### Exact and approximate search

Exact nearest-neighbor search evaluates all candidates and gives a useful reference. Approximate nearest-neighbor search trades work and storage for retrieval quality. HNSW builds a navigable graph; search breadth affects speed and recall. Index settings must be evaluated against exact results under the real metadata filters, not just against an unfiltered random benchmark.

Filtered search can behave differently when only a small fraction of documents match. Applying a version filter after retrieving a short top-k list may leave no valid candidates even when relevant documents exist. Apply constraints through the retrieval mechanism and measure the result. Security-related authorization filters must not be delegated to the language model.

### Worked migration

Suppose index A contains model M1 vectors and 10,000 source chunks. Build index B with M2 and the same source manifest. Check row counts, missing IDs, embedding dimensions and a development retrieval benchmark. Route a limited evaluation workload to B, then switch the active index only when gates pass. Retain A for rollback. If documents changed too, record that as a separate experimental variable.

Deletion matters. Removing a document from object storage does not automatically remove its chunks, cached answers or replicated index entries. Define a tombstone/update policy and a completion check.

### Experiment

Notebook 06 creates a local Qdrant collection, upserts vectors, filters by version, persists and reopens it, and queries again. Inspect payloads directly. Add an update with the same ID, then delete a point and verify it no longer appears. Local mode teaches the client and lifecycle; it does not establish distributed durability or production throughput.

**Exit criterion:** distinguish an embedding model, a vector similarity function, an ANN index and the database operating it. **Reading:** R08; optional R24. **Lab:** 06.

## Week 13 RAG is evidence selection plus conditional generation

### Intuition

The model's parameters provide learned capabilities and remembered patterns. Retrieval supplies task-specific evidence at request time. RAG combines these sources, but it does not automatically force the answer to follow the evidence. The system must construct context, constrain the response, and evaluate grounding.

A practical pipeline is question normalization, authorized retrieval, reranking or selection, context packing, generation, validation and response. The historical RAG paper describes a specific learned retrieval/generation formulation [R06]; the term is now also commonly used for retrieve-then-prompt applications. Be clear which system you implement.

### Context is a limited resource

Chunks should preserve coherent statements, headings, code blocks and source provenance. Overlap can prevent boundary losses but creates duplicate candidates. Track parent page IDs so duplicated chunks do not exaggerate evidence diversity. Context packing should respect the generator tokenizer's budget and reserve output space. Adding every retrieved passage can obscure the useful evidence.

### Worked evidence contract

Question: “What changed in the timeout default between v1 and v2?” Context contains v1's 10-second default and v2's 30-second default, each labeled with a source ID and version. A supported answer states both defaults and cites both IDs. Citing only v2 cannot support the claim about change. If only v2 is present, the assistant should state that the comparison lacks v1 evidence or retrieve it through an explicit comparison path.

Validate citations at two levels. Structural checks verify that the IDs exist and were authorized for this request. Semantic checks ask whether those passages support the individual claims. The first is automatable and necessary, but it does not substitute for the second. Neither a lexical overlap score nor a JSON schema proves entailment.

### Experiment

Notebook 07 assembles source-labeled context, runs the evidence-only baseline and then supplies the same context to a small LLM if available. Compare a supported question, a missing-answer question and a conflicting-version question. Remove a required source and see whether the model admits insufficiency.

Measure evidence coverage, factual completeness, unsupported claims and refusal quality. An assistant that refuses everything may have low unsupported-claim rate but zero usefulness. Your project needs both coverage and correctness targets. For access-controlled docs, context may include only documents the caller can read; citations and caches must follow the same rule.

**Exit criterion:** trace a factual claim back through the response, packed context, selected chunk and source manifest. **Reading:** R06 abstract/architecture; R09 context serialization. **Lab:** 07.

## Week 14 Hybrid retrieval and reranking

### Intuition

Lexical and semantic search make different errors. Hybrid retrieval combines candidate lists; reranking spends more work judging the best candidates. These are separate operations. Reranking cannot recover a relevant document absent from its candidate set.

Do not add BM25 scores directly to cosine scores without a justified calibration: their scales differ. Reciprocal rank fusion combines ranks: `RRF(d) = sum_lists 1/(c + rank_list(d))`, with ranks starting at one. c controls how sharply top ranks dominate. Choose settings on development data, and compare against each component alone.

### Worked fusion

With c=60, passage A ranked 1st lexically and 10th semantically scores `1/61 + 1/70`, approximately 0.03068. Passage B ranked 2nd in both scores `2/62`, approximately 0.03226. B wins because both systems support it. A document absent from one finite list contributes zero from that list. Fusion does not mean the scores are probabilities.

A cross-encoder reads question and candidate together to assign a relevance score. Rerank a sufficiently broad candidate pool, then select a small evidence set. Diversification can reduce near-duplicates, but too much diversity may discard necessary details from one source. Parent-child retrieval can search small chunks and include a larger parent section for coherent context.

### Query transformation

Query rewriting resolves conversational references or expands terms. Multi-query retrieval can broaden recall. Hypothetical-document approaches generate a possible answer-like passage to embed. These can help some distributions but may introduce unsupported assumptions, extra latency and correlated false evidence. Keep the original query and log transformations. Version and access constraints must survive rewriting.

### Experiment

Compare lexical only, dense only, rank fusion, and fusion plus a reranker on the same frozen development split. In the notebook, a simple deterministic reranking demonstration teaches the interface; an actual neural reranker is an optional extension, not a claimed baseline result. Report candidate recall before reranking and answer metrics after generation. This separates a recall problem from an ordering problem.

If hybrid improves identifiers but harms paraphrases, examine slice results and consider targeted routing. Do not add routing until you can explain its decision boundary and evaluation. A more complex pipeline has more timeouts, caches, artifacts and failure paths.

**Exit criterion:** calculate RRF, explain candidate recall, and justify whether the measured quality gain merits added latency. **Reading:** R07 for embedding side; optional R25 lexical model. **Lab:** 07.

## Week 15 Evaluation is an executable specification

### Intuition

Your benchmark is a small, imperfect specification of desired behavior. It should contain representative successes, difficult cases and explicit absences. A single average judge score makes release decisions hard to defend. Save the underlying examples, judgments and slices.

Partition by intended use: training/adaptation, development/tuning, and final held-out evaluation. Avoid nearly identical page families or generated paraphrases crossing boundaries when they reveal the answers. Retrieval is allowed to read the indexed reference documents at evaluation time; the leakage concern is using held-out questions, labels or near-duplicates to tune the system. Keep this distinction precise.

### Metrics at each boundary

Evaluate retrieval with labeled evidence; answer correctness against required facts; citation validity structurally and semantically; unsupported claims; appropriate refusal; task completion; latency, tokens and failures. For an agent later, also evaluate tool correctness, forbidden actions and budget exhaustion. State denominators explicitly, including timeouts and parse errors.

An LLM judge can provide scalable rubric-based assistance, but it can be biased by wording, answer length and its own model family. Calibrate it against human-labeled examples, randomize answer ordering in pairwise comparisons, inspect disagreement, and keep the judge prompt/model version. Do not use the same model's self-confidence as the only evidence of correctness.

### Worked uncertainty example

If system A answers 32/40 correctly and B answers 34/40 correctly, the observed difference is 5 percentage points. It is not automatically a meaningful improvement. Inspect paired differences: perhaps B fixes four A errors but creates two new ones. A paired bootstrap resamples task indices and recomputes the difference, preserving pairing. With small or correlated samples, uncertainty remains large; report intervals and assumptions instead of claiming superiority from two tasks.

### Experiment

Notebook 08 implements retrieval metrics, paired resampling and a JSON evaluation record. Add at least five adversarial cases, including version mismatch, irrelevant high-overlap evidence, missing answers, fake instructions inside a page and multi-source questions. Use development data for thresholds; run the held-out set only at the planned checkpoint.

The starter's structural tests establish software behavior and metric arithmetic. They do not establish natural-language grounding. Your manual scoring rubric must identify required facts and unsupported statements per task. Keep a short error notebook with the original question, expected evidence, actual output, diagnosis and next hypothesis.

**Exit criterion:** make a release recommendation supported by per-example evidence and uncertainty. **Reading:** R03 evaluation topic; R01 evaluation lecture headings. **Lab:** 08.

## Week 16 Deliver and defend RAG v1

### Intuition

A semester project is ready when another person can run it, understand its evidence, and observe its limitations. A chatbot screenshot alone does not demonstrate that ingestion, retrieval or evaluation are reproducible. Freeze an identifiable version and defend the engineering decisions.

Your v1 includes a source manifest, ingestion procedure, lexical baseline, semantic retriever, persisted index, generator adapter, citation contract and evaluation harness. The starter's invented fixture is replaced with public documentation. Save selected pages with source URLs, versions, hashes and license notes. Use a focused documentation area rather than attempting to ingest the whole internet.

### A release contract

Define a run manifest containing corpus hash, index identity, embedding model revision, generator revision, prompt hash, decoding settings and software environment. A single release version points to this set. If the embedding model changes, the index compatibility check should fail unless the correct index was rebuilt. If a source page disappears, ingestion should produce an explicit error or deletion record.

Failure behavior is part of the product. Unsupported questions receive a useful insufficiency message. Timeouts produce a controlled error. Citations lead to the matching version. Logs contain enough diagnostic data while avoiding unnecessary sensitive content. Your local demonstration can remain simple; its interfaces must make behavior inspectable.

### Worked release decision

Suppose the new retriever improves lookup correctness from 72% to 81%, but wrong-version answers rise from 0 to 4. If the release gate forbids cross-version evidence, do not release merely because the average improved. Diagnose filtering and fix the regression. Numerical quality targets can be tuned to your use case; an authorization invariant remains a hard requirement.

### Submission and examination

Run the held-out set once for the planned report, then freeze its raw outputs. Write the result, uncertainty, slice breakdown and top five failures. Include an ablation that changes one component, a reproducibility command and an architecture description. Present a three-minute demo: correct lookup, unsupported query and a deliberately difficult case. If you revise after seeing held-out failures, label the revision exploratory and create a future untouched test set before making fresh generalization claims.

Take semester exam 1 in `assessments/EXAMS.md` for two hours, then use the separate solution guide. The examination checks mechanisms and debugging judgment as well as definitions. A score below 60% means repeat the failed topics with smaller experiments before proceeding.

**Exit criterion:** reproduce RAG v1 from its manifest and explain one case where retrieval helps, one where it fails, and one where a simpler method is enough. **Reading:** R02 system lifecycle overview. **Lab:** 08. **Assessment:** semester exam 1.
