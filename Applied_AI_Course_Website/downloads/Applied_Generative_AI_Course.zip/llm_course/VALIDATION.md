# Validation and limits

Package created 20 October 2026.

## Completed checks

- All Python source files parsed successfully.
- All 42 Python code cells across the 16 version-4 notebooks parsed successfully; notebook IDs and required structure checked.
- CPU tutorial paths 01, 02, 07, 08, 09, 11, 13, 14, 15 and 16 executed successfully. Lab 07 real-model switch remained off.
- All 23 deterministic retrieval, metric, arithmetic, schema, controller and manifest tests passed.
- Lab 13 started the actual local HTTP API, checked health, made 20 successful scoped requests and recorded latency. This is an extraction-service smoke test, not an LLM throughput benchmark.
- Numerical examples were checked through executed calculations or worked solution arithmetic.
- The archive excludes test-generated runs, Python caches and model files. Notebook outputs are empty for clean student attempts.

## Not executed in the authoring environment

This environment did not have PyTorch/model dependencies or a GPU. Model loading/inference, sentence-transformer embedding, Qdrant persistence with downloaded embeddings, tiny-LM training, LoRA training/reload, model-directed planning and CUDA compilation/profiling were not executed here. Their notebook code was syntax-checked and written against the cited official API families. End-to-end execution and package resolution must be confirmed in the chosen Colab/runtime.

Dependency ranges are not a verified lockfile. Resolve them in a fresh runtime, save successful versions/model revisions, and complete measured tasks before marking those labs complete. CUDA toolchain/precision support and free GPU availability vary.

## Interpretation limits

Fixture data are invented and tiny. The lexical answerer is an extractor, not an LLM; deterministic planners test controller behavior, not model planning. Illustrative telemetry, rank lists and bootstrap arrays are labeled. Controller completion and source-ID existence do not prove correctness or semantic support.

The local API is instructional and unauthenticated. The controller enforces schemas, arithmetic bounds, request version and step count; it is not an arbitrary-code sandbox or blocking-call cancellation mechanism. Authentication, timeouts/cancellation, workload isolation, secrets, permissions and cache controls are deployment work where applicable.

References are primary papers, official course pages and documentation in REFERENCES.md. These are independent original materials, with no Stanford/NTU affiliation or certificate.
