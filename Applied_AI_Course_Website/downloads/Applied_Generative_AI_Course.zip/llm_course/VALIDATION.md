# Validation and limits

All 32 notebooks and companion scripts were syntax checked. Twenty-seven CPU-capable tutorial paths executed successfully with Python 3.13 and NumPy 2.5.4 where needed. Twenty-three support contract tests passed. Optional actual-model blocks were disabled for those CPU runs. The extraction API smoke test and controller fixtures were executed; these are not LLM inference benchmarks.

Actual tiny-transformer training (week 12), embedding/Qdrant execution (week 18), CUDA compilation/profiling (week 23), LoRA training (week 26) and actual model planning (week 28) were not executed in this revision environment. Optional model paths in weeks 13, 17 and 20 were not executed. Their code is syntax checked; package/device/model compatibility and model quality require your runtime. No fixture result is presented as a trained-model result. Distributed notebook outputs are empty. Verification runs and checkpoints are excluded.
