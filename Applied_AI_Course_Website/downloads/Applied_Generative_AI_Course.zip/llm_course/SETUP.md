# Setup and compute
## Read first
The website uses static HTML, CSS and JavaScript. Reading, slides, search, worked solutions, diagrams and progress tracking require no Python installation or paid service. Code runs separately on your computer or Colab.

## CPU foundation route
Use Python 3.10–3.12 in a virtual environment for broad package compatibility. Install NumPy for numerical lessons. Most early notebooks and controller/evaluation exercises need only the standard library and NumPy. Colab normally includes them.

Extract the full course ZIP. Its root contains coursekit, data, notebooks and tests. From that root run python -m unittest discover -s tests -v. In Colab, upload the ZIP, unzip it into /content/llm_course, and run the bootstrap cell. The cell also searches for an extracted llm_course_v2 folder. Do not upload a lone notebook without its support files.

## Model downloads and free GPUs
Week 12 introduces a small PyTorch transformer. A short CPU run checks the training path; Colab allows longer experiments when a GPU is available. Later notebooks have explicit installation/download cells. Free GPU availability varies; inspect the assigned device. Save checkpoints and reports outside a temporary runtime before disconnecting.

Your GTX 1650 Super is optional. Inspect actual free VRAM with nvidia-smi. Use CPU for numerical lessons and Colab for larger model experiments. Do not assume BF16, large batches or QLoRA kernels work on every GPU. Start with float32 CPU correctness or supported float16 GPU execution.

## Reproducible model work
Package ranges in notebooks are starting constraints, not immutable lockfiles. Record resolved Python, torch, transformers and accelerator versions, model/tokenizer commits, data hashes, seeds and configurations. Save a lockfile for a working environment. Check current official documentation if installation APIs differ.

Model labs download a small Qwen model and/or a sentence embedding model. QLoRA is explained but the guided LoRA pilot does not require a four-bit kernel. Week 23 CUDA compilation requires nvcc. If unavailable, inspect the kernel and record that limitation.

## Outputs
The bootstrap creates a runs directory. Use run IDs and keep actual outputs. The fictional teaching fixtures are tiny and cannot establish production quality or broad model capability.
