# Setup and compute plan

## CPU baseline

Use Python 3.10 or newer. From the extracted `llm_course` directory, run:

```powershell
python -m unittest discover -s tests -v
python -m coursekit.demo
python -m coursekit.server
```

The baseline uses only the Python standard library. Open `http://127.0.0.1:8000/health` in a browser. Query it from a second terminal:

```powershell
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/ask -ContentType 'application/json' -Body '{"question":"What is the default request timeout?","version":"2"}'
```

Use `curl` or Python `urllib.request` on Linux. The server binds to loopback and is an instructional service; shared deployment requires authentication, rate limiting, a process manager, and infrastructure configuration you will implement in the capstone. No executable shell tool is exposed.

## Colab

Upload a notebook and upload the ZIP. Extract the ZIP into `/content` using the Colab file browser or:

```python
from zipfile import ZipFile
with ZipFile('/content/Applied_Generative_AI_Course.zip') as z:
    z.extractall('/content')
```

Notebooks locate `llm_course` in the current directory or its parent. For the GPU notebooks select Runtime → Change runtime type → GPU when available. Record `nvidia-smi`, Python, PyTorch, CUDA runtime and package versions, free VRAM, and random seed. Save checkpoints and reports before the session ends. If a GPU is unavailable, do the CPU experiments first and reschedule the measured GPU task. A CPU skip does not count as having completed a CUDA benchmark.

## Optional model dependencies

Each model notebook includes its own installation cell. These are API-family constraints, not a verified binary lockfile:

```text
torch>=2.4,<3
transformers>=4.45,<5
sentence-transformers>=3,<6
peft>=0.13,<1
qdrant-client>=1.12,<2
```

The examples deliberately use the Transformers 4.x interface rather than assuming that a future major version has identical behavior. After a successful run, save `pip freeze` with the run artifacts. If a dependency resolver reports a conflict, use a new runtime, install only that notebook's dependencies, restart, and rerun from the top. Record the resolved versions; do not silently replace the evaluation model halfway through an experiment.

Default demonstration models: `sentence-transformers/all-MiniLM-L6-v2` for English retrieval and `Qwen/Qwen2.5-0.5B-Instruct` for generation/SFT. Read the model cards [R22, R23]; check licenses and model revision at download time. They are small instructional choices, not claims of current best quality. MiniLM truncates long input, so chunks must respect its actual tokenizer limit. A weak small-model answer is useful failure evidence.

## Resource tiers

| Tier | Activities | Fallback |
|---|---|---|
| CPU and no downloads | Lexical retrieval, exact-vector toy search, metrics, controllers, API, CI exercises | Fully bundled starter |
| CPU with model downloads | Semantic embedding, local vector DB, short small-model inference | Smaller batches and shorter input |
| Available Colab GPU | Tiny transformer, short LoRA run, profiling and CUDA kernel | Smaller model/sequence/batch; checkpoint and resume |
| Optional larger GPU | More useful model or longer training, QLoRA experiment | Never required for baseline completion |

The local GPU can run some small experiments if your driver/PyTorch build supports it. The course does not assume bfloat16, Tensor Core acceleration, a particular quantization backend, or that a multi-billion-parameter model fits. Prefer float32 for CPU correctness and select GPU precision only after checking support. Do not install a CUDA toolkit merely to use prebuilt PyTorch; the standalone CUDA C++ exercise additionally needs `nvcc`.

## What to save after every experiment

Save config JSON; git revision if you use git; dataset and index hashes; model/tokenizer revision; package freeze; device details; raw per-example outputs; aggregate metrics; elapsed time; and your explanation of the result. Keep model caches outside the ZIP or source repository. A run with no saved output is difficult to reproduce after a Colab reset.
