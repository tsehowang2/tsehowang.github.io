# Primary references

Links checked on 20 October 2026. Course pages are references for teaching structure and optional study; the written chapters and exercises are original. Software documentation changes: save the versions you actually run. Read the named section, not the whole source, unless marked optional.

| ID | Primary source | Use |
|---|---|---|
| R01 | [Stanford CS336 Language Modeling from Scratch](https://cs336.stanford.edu/) | Architecture, resource accounting, data, alignment; optional deeper assignments |
| R02 | [Stanford CS329S Machine Learning Systems Design](https://stanford-cs329s.github.io/) | Lifecycle, stakeholder requirements, deployment and monitoring |
| R03 | [Hung-yi Lee Introduction to GenAI and ML 2025](https://speech.ee.ntu.edu.tw/~hylee/GenAI-ML/2025-fall.php) | Optional intuition-first videos: context engineering, model internals, evaluation, post-training |
| R04 | [Vaswani et al. Attention Is All You Need](https://arxiv.org/abs/1706.03762) | Scaled dot-product attention and multi-head architecture |
| R05 | [Google Colab FAQ](https://research.google.com/colaboratory/faq.html) | Resource availability, session limits and persistence |
| R06 | [Lewis et al. Retrieval Augmented Generation](https://arxiv.org/abs/2005.11401) | Parametric and retrieved information; historical RAG formulation |
| R07 | [Sentence Transformers semantic similarity](https://www.sbert.net/docs/sentence_transformer/usage/semantic_textual_similarity.html) | Embedding encoding and similarity |
| R08 | [Qdrant local quickstart](https://qdrant.tech/documentation/quickstart/) | Collections, points and payloads |
| R09 | [Hugging Face Transformers chat templates](https://huggingface.co/docs/transformers/chat_templating) | Message serialization and generation prompts |
| R10 | [Wei et al. Chain of Thought Prompting](https://arxiv.org/abs/2201.11903) | Intermediate-step prompting and task-dependent evaluation |
| R11 | [Yao et al. ReAct](https://arxiv.org/abs/2210.03629) | Interleaving observations and actions |
| R12 | [Hu et al. LoRA](https://arxiv.org/abs/2106.09685) | Low-rank trainable updates |
| R13 | [Dettmers et al. QLoRA](https://arxiv.org/abs/2305.14314) | Quantized frozen base plus adapters |
| R14 | [Hugging Face PEFT LoRA guide](https://huggingface.co/docs/peft/main/en/conceptual_guides/lora) | Configurations and adapter operations; select installed version in docs |
| R15 | [Rafailov et al. Direct Preference Optimization](https://arxiv.org/abs/2305.18290) | Preference learning objective |
| R16 | [NVIDIA CUDA programming guide](https://docs.nvidia.com/cuda/cuda-programming-guide/) | Thread hierarchy, memory and synchronization |
| R17 | [NVIDIA CUDA introduction](https://developer.nvidia.com/blog/easy-introduction-cuda-c-and-c/) | A minimal CUDA C++ program |
| R18 | [PyTorch automatic mixed precision recipe](https://docs.pytorch.org/tutorials/recipes/recipes/amp_recipe.html) | Autocast and gradient scaling |
| R19 | [PyTorch profiler recipe](https://docs.pytorch.org/tutorials/recipes/recipes/profiler_recipe.html) | CPU/GPU activity, operator timing and memory |
| R20 | [MLflow experiment tracking](https://mlflow.org/docs/latest/ml/tracking/) | Runs, parameters, metrics and artifacts |
| R21 | [Ho et al. Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239) | Forward noising and learned denoising |
| R22 | [MiniLM L6 model card](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) | Embedding model use and limits |
| R23 | [Qwen2.5 0.5B Instruct model card](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct) | Small generator setup and chat format |
| R24 | [Malkov and Yashunin HNSW](https://arxiv.org/abs/1603.09320) | Hierarchical approximate nearest-neighbor graph |
| R25 | [Robertson and Zaragoza Probabilistic Relevance Framework](https://doi.org/10.1561/1500000019) | BM25 term saturation and length normalization |
| R26 | [Dao et al. FlashAttention](https://arxiv.org/abs/2205.14135) | Exact attention with reduced memory traffic |

## Readings by phase

Weeks 1–8: R03 introduction/evaluation lecture headings, R04 attention equation and model diagram, R09 examples, R10 abstract and experimental setup. Weeks 9–16: R16 thread hierarchy, R19 profiler example, R07 similarity example, R08 points/payloads, R06 abstract and architecture. Weeks 17–24: R12 method and parameterization, R14 adapter configuration, R13 overview, R15 objective, R11 action/observation examples. Weeks 25–32: R02 overview, R20 tracking concepts, R18 recipe, R21 noising/denoising intuition, R26 IO-aware attention. Remaining references are optional implementation or extension readings.
