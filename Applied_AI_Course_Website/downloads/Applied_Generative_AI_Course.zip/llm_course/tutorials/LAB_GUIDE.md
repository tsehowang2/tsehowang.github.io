# Tutorial and experiment guide

Each lab spans two weeks. Budget four hours for the guided notebook across those weeks and up to eight hours for the independent experiment/project work; the remaining time is lecture study, tests and review. On examination weeks use the special syllabus allocation. These estimates are targets, not measured runtimes; installation/downloads and unavailable GPUs may require rescheduling.

Submit a 1–2 page report using the experiment template, code changes, raw outputs and a reproducibility command. Shared lab rubric: mechanism/explanation 20%, correct implementation 30%, controlled measurement 30%, error analysis/reproducibility 20%. A notebook that ran without an independent experiment earns at most 50%. Numerical outputs below are expectations for worked examples, not claimed model benchmarks.

## Lab 01 Baseline and dataset Weeks 1 and 2

**Before running:** identify the two timeout versions and manually answer three fixture questions. Predict one unsupported case where lexical overlap might still return a passage.

**Tutorial:** run the lexical search for every visible task; inspect IDs, evidence and metric denominators. Inspect the byte-budget example. Write ten original questions for the planned public corpus before modifying retrieval.

**Independent experiment:** compare title+body versus body-only indexing or two tokenization rules. Keep tasks and k fixed. Report per-task ranks and answerable recall, then manually assess unsupported tasks. Inspect q11: the version-1 timeout page can overlap a question about undocumented retries; nonempty retrieval is not enough to answer it.

**Expected:** v2-scoped hits contain no v1 points; byte counts vary with Unicode; evidence budget is 1198 before extra template overhead. A perfect metric is not required.

**Debug:** empty results may reflect tokenization or missing data, not a model bug. **Submit:** charter, source plan, baseline JSON and diagnosis of three cases.

## Lab 02 Attention and geometry Weeks 3 and 4

**Before running:** compute both dot products/cosines and attention weights on paper.

**Tutorial:** implement stable softmax, scaled dot-product attention and a causal mask in NumPy. Explain each axis aloud. Perturb the final token; earlier outputs must remain equal with masking.

**Independent experiment:** add padding support with at least one valid key per row and test multiple sequence lengths. Compare masked/unmasked behavior and vary head dimension with/without scaling. Measure score-logit spread and entropy rather than declaring sharper attention better.

**Expected:** dot products .8 and 4; cosines both .8; attention output approximately (1.3395,1.3208). Masking the second key gives (2,0). Future perturbations do not change earlier causal outputs.

**Debug:** NaNs can arise from all-masked rows; check masks before adding numerical patches. **Submit:** implementation, property tests, shape worksheet and checkpoint A.

## Lab 03 Tiny language model Weeks 5 and 6

**Tutorial:** inspect token/position embeddings, two pre-norm blocks and the output head. Check shifted labels and causal invariance before training. Record parameter count and train/dev loss.

**Independent experiment:** overfit one batch to diagnose the loop, then restore grouped source separation and evaluate at least ten dev batches. Remove the MLP or attention under a fixed token/step budget and compare. If compute is limited, reduce width/steps consistently.

**Expected:** finite gradients/loss and a saved checkpoint. Loss reduction is plausible but not a promised quality result. The dev set has different source groups and is tiny.

**Debug:** wrong shifts, forgotten eval/train switches, accidental future leakage or insufficient data can mislead. Check them before hyperparameter tuning.

**Submit:** loss curve or table, exact settings, source split, model diagram, one controlled ablation, and a resume check. A toy byte LM is mechanism evidence, not your final assistant model.

## Lab 04 Small instruction model Weeks 7 and 8

**Tutorial:** download the small model, inspect its chat template, count serialized prompt tokens, generate only new tokens and save revision/output. Audit the answer against evidence.

**Independent experiment:** create 20 independently checkable development tasks. Compare direct answers, concise decomposition and tool-assisted verification; include five absent/ambiguous cases. Record answer correctness, support, model-call count, all tokens and latency. For sampling, run repeated trials with saved seeds.

**Expected:** model loads and produces a response within the specified token bound. Correctness and reasoning gains are empirical outcomes. A failure is kept in the denominator.

**Debug:** use the model's template, avoid duplicate special tokens, inspect truncation and check whether the relevant evidence actually appears. CPU inference can be slow; shorten the task, not the evaluation honesty.

**Submit:** prompt variants, raw outputs, paired comparison, checkpoint B and one case where extra reasoning was unnecessary.

## Lab 05 Hardware and CUDA Weeks 9 and 10

**Tutorial:** calculate memory, inspect actual GPU properties, compile vector_add when nvcc is available, test n=1/257/1048576 and profile PyTorch work with synchronization.

**Independent experiment:** compare at least three array sizes and block sizes, retaining bounds checks. Separate kernel timing from data-transfer timing. Repeat enough runs for a median/spread; the bundled executable prints an average that you should extend or repeat externally. Profile one short model forward pass and identify an operator/memory bottleneck.

**Expected:** cache example is 96 MiB; vector-add output matches CPU within tolerance. Small kernels may be dominated by launch overhead.

**Debug:** no nvcc means the C++ task was not run; no GPU means no GPU measurement. Unsupported dtype/toolchain errors require a compatible runtime, not fabricated timing.

**Submit:** kernel, correctness cases, device/software record, timing table, trace and bottleneck explanation. A CPU-only theoretical worksheet leaves the measured CUDA portion incomplete.

## Lab 06 Semantic retrieval and vector DB Weeks 11 and 12

**Tutorial:** encode actual sentence embeddings, normalize, inspect shape and compare dense/BM25 per task. Persist local Qdrant, close/reopen and check version filters.

**Independent experiment:** perform update/delete checks in a separate collection; compare exact identifier versus paraphrase slices. Verify the actual embedding tokenizer limit on your longest chunk. Save model revision, corpus hash and dimensionality. For your real project, use meaningful corpus/task sizes.

**Expected:** normalized vectors have norms near one; reopened results respect version payloads. Dense search need not beat lexical search on every question.

**Debug:** mismatched vector dimensions are obvious, but same-dimensional model mismatches are more dangerous; check the manifest. Distinguish local persistence from server durability and ANN performance.

**Submit:** saved collection instructions, raw rankings, slice metrics, update/deletion evidence and an index migration plan.

## Lab 07 Grounded context and hybrid search Weeks 13 and 14

**Tutorial:** reproduce RRF and source-labeled context selection. Then use the complete optional real-model block in the notebook to run dense+lexical fusion and generation. It is optional for an offline first pass but required for the completed RAG lab.

**Independent experiment:** compare lexical, dense, fused retrieval and one ordering/selection improvement with generator, corpus, budgets and tasks fixed. An actual neural reranker is optional; clearly name any heuristic. Evaluate candidate recall before generation and manually score claim support afterward.

**Expected:** context includes both timeout sources for a comparison when budget allows. A valid source ID does not prove the answer is supported.

**Debug:** document token limits differ from generator limits; preserve source/version labels, reserve output, and inspect duplicate context. Do not use a fixture list as measured dense retrieval.

**Submit:** real RAG outputs, context manifest, fusion ablation, citation/refusal audit and at least one failure involving missing evidence.

## Lab 08 Evaluation harness Weeks 15 and 16

**Tutorial:** produce per-task records with ungraded manual fields and reproduce recall/hit/RR arithmetic. Run paired bootstrap on illustrative data, then replace it with actual matched outputs.

**Independent experiment:** grade the chosen systems blind to configuration where feasible; add five original adversarial cases. Define primary metric and slice reports. Check whether source/task grouping makes an individual-task bootstrap optimistic.

**Expected:** gold-empty retrieval recall is not applicable; all parse/time/tool failures remain visible. A two-task improvement is not automatically significant.

**Debug:** do not average null fields as zeros or silently drop failures. Confirm that each output aligns to the correct task ID.

**Submit:** RAG v1, raw/graded records, uncertainty/error analysis, reproducibility manifest, semester report and exam 1 corrections. Exam week replaces ordinary project time.

## Lab 09 Fine-tuning data Weeks 17 and 18

**Tutorial:** construct context-conditioned targets, include insufficiency cases, split by group and calculate LoRA shapes/counts.

**Independent experiment:** write an error-based intervention proposal. Create a separate reviewed narrow-task train set and dev split, with provenance and manual audit. Aim for 100–300 clean examples if feasible; a smaller pilot must make a narrower claim. Inspect target/prompt truncation with the real tokenizer before training.

**Expected:** train/dev groups do not overlap; rank-8 update for 4096² has 65,536 trainable factors, .390625% of the dense matrix.

**Debug:** source-backed labels may still be incomplete or stylistically inconsistent. Synthetic examples require review; do not recycle final test labels.

**Submit:** data card, split/audit script, examples, parameter/memory worksheet and a hypothesis specifying expected improvements and possible regressions.

## Lab 10 LoRA training Weeks 19 and 20

**Tutorial:** run actual adapters on a frozen small base, check nonzero adapter gradients and absent base gradients, train briefly, save and reload. Calculate the separate illustrative DPO loss.

**Independent experiment:** compare generated base/adapter outputs on your narrow-task dev set with identical context/decoding/parser. Include refusal, wrong-version and argument-semantic cases. Inspect saved/reloaded behavior in a clean session. Save exact dependency/model/data revisions.

**Expected:** trainable factor count is much smaller; loss is finite; checkpoint reload works. Improvement is not guaranteed. DPO scalar loss≈.43749 does not mean DPO training occurred.

**Debug:** all labels -100 means the answer was truncated. Prefix mismatch means the masking assumption fails. OOM needs smaller sequences/batches/model; quantization is an explicitly checked optional path.

**Submit:** real run metadata/checkpoint reference, paired application metrics, negative findings if any, and 20 rubric-labeled preference pairs. GPU training and useful-size data remain separate evidence from a two-step CPU pilot.

## Lab 11 Tool controller Weeks 21 and 22

**Tutorial:** validate arithmetic/config schemas, run the deterministic lookup/calculator controller and inspect traces. Force unknown tool, wrong scope and endless loop failures.

**Independent experiment:** add at least ten contract cases covering extras, booleans, division by zero, bounds, malformed proposals, fabricated citations and repeated actions. Define controller terminal statuses and a real timeout plan for future blocking calls.

**Expected:** 700 ms fixture result, strict schema checks, unknown tools rejected, endless planner terminates with budget_exhausted. Structural citation checks do not verify the conclusion.

**Debug:** tool-call validity differs from tool result validity. A valid config-validator call can return valid=false without being a controller schema error.

**Submit:** contracts, tests, execution state diagram/description and traces. State clearly that this planner is deterministic; actual model planning follows in lab 12.

## Lab 12 Model planner Weeks 23 and 24

**Tutorial:** use a real model to propose JSON actions; preserve raw text, input/output tokens and controller results. Invalid JSON is a measured planner failure.

**Independent experiment:** build 20 tasks with independent checkers and compare fixed workflow with adaptive planning at stated budgets. Include simple lookups, calculations, invalid configs, unsupported questions, hostile observations and forced failures.

**Expected:** small-model failures may be common. Completed means accepted final proposal, not task success. Inspect actual tool usage for tasks requiring it.

**Debug:** do not repair malformed outputs silently or let fallback arguments bypass validators. Count every retry and model call. Bound output/context and distinguish step cap from call timeout.

**Submit:** paired success/cost/failure table, trace audit, one useful adaptive case and one workflow-preferred case. Keep a non-improving agent as an experimental branch rather than forcing it into the final release.

## Lab 13 Service and release Weeks 25 and 26

**Tutorial:** create and verify a corpus manifest, start the localhost extraction service, check health and API scope, measure end-to-end timings and stop the child process.

**Independent experiment:** replace the answerer with the chosen real generator behind the same contract; record all dependent revisions. Measure representative short/long inputs at multiple concurrency levels with failures and warm/cold states. Use enough requests to discuss p95 uncertainty honestly.

**Expected:** wrong manifest rejected; v2 request excludes v1 citations. The bundled 20-call extractor timing is not LLM throughput evidence.

**Debug:** port conflicts can query the wrong server; verify process ownership/health and change the port if needed. Health is not the same as model readiness.

**Submit:** API instructions, actual model-serving latency report, environment/manifest and deployment control plan. Public hosting is optional; local deployment claims must be labeled local.

## Lab 14 Observability and security Weeks 27 and 28

**Tutorial:** aggregate explicitly synthetic telemetry and exercise hostile proposals. Explain which checks reject an action and which produce an invalid configuration result.

**Independent experiment:** instrument the actual application with request IDs and step spans; derive at least three measured signals. Define alerts including sample floors and response/recovery procedures. Inject malicious evidence into the actual model and verify enforced tool bounds.

**Expected:** synthetic empty-retrieval alert changes at the proposed threshold. No secret-export tool exists. Prompt text remains an untrusted influence even when enforcement works.

**Debug:** do not call a string detector authorization, hash logs “anonymous,” or version filtering authentication. Add permission/cache tests if introducing private data.

**Submit:** trace examples, dashboard/alerts specification, threat model, adversarial results and source-deletion propagation plan.

## Lab 15 Regression and incident Weeks 29 and 30

**Tutorial:** run the contract suite, reject a mismatched candidate manifest and restore the previous manifest. Compute theoretical four-way speedups.

**Independent experiment:** rehearse actual artifact rollback on your project, not merely the starter metadata. Add one regression for a discovered error and write an incident report. Develop a capacity memo: present measured bottleneck, candidate scaling method, persistent-state/activation/communication budget and validating experiment.

**Expected:** incompatible candidate refused; ideal .7-scalable speedup≈2.105 and .8-scalable≈2.5, before overhead.

**Debug:** reverting only weights leaves index/prompt/corpus changes active. Data parallelism does not inherently shard all state.

**Submit:** release decision, recovery evidence, regression, incident and capacity memo. Proposed multi-GPU behavior must be identified as proposed unless actually measured.

## Lab 16 Final reproduction Weeks 31 and 32

**Tutorial:** reproduce scalar forward noising and inspect required artifact presence. Presence alone does not prove quality or successful execution.

**Independent experiment:** follow your README in a clean directory, verify the final gates and collect a five-minute demonstration. Optional multimodal task replaces other extension work: label and assess a table's values and header associations before asking an LLM to interpret it.

**Expected:** scalar xt=1; the audit may mark unfinished work missing. Keep those marks until real artifacts exist.

**Debug:** implicit notebook state and cached files can conceal missing reproduction steps. Download instructions must pin revisions and state internet/compute needs.

**Submit:** final report, code/artifact manifest, raw evaluation, demo and exam 2 corrections. Explain independent contributions, actual outcomes, limitations and one next experiment.
