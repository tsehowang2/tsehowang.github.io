# Examinations
Two hours per semester exam, 100 points. Closed notes; a calculator and blank Python interpreter are permitted. No LLM or internet. Show reasoning, assumptions and units. Checkpoints are diagnostic.

## Checkpoint A after week 4
Twenty minutes. (1) Estimate next-word probabilities from three bus, one train and one bicycle sentences. (2) Tokenize the school sentence and show shifted input/target IDs. (3) Compare dot product and cosine of [1,0] with [2,0] and [1,1]. (4) Compute softmax and target negative log likelihood for two equal logits. Repair missing concepts before week 5.

## Checkpoint B after week 8
Twenty minutes. (1) Mix [2,0] and [0,4] with weights .25 and .75. (2) Give Q/K/V and score shapes for T=8,D=32,d_head=16. (3) Explain masking before softmax. (4) Describe a future-token perturbation check. Repair missing concepts before week 9.

## Semester exam 1

### Question 1 Language modeling and representations 15 points
Using “I go to school by bus,” explain next-token training and give shifted inputs/targets (5). Distinguish token IDs from embedding vectors and explain why IDs cannot be averaged as meanings (5). For probabilities [.6,.2,.2], calculate negative log likelihood when train is the target and interpret lower loss (5).

### Question 2 Attention by hand 20 points
A query produces unscaled scores [2,0] with d_head=4 and values [2,0] and [0,4]. Calculate scaled scores, stable softmax and the mixed output (10). Mask the second key as a future position and recalculate (6). Explain the different roles of Q, K and V even when they come from the same input (4).

### Question 3 Transformer architecture 20 points
For B=2,T=128,D=256,H=8 give split Q/K/V, score, per-head output and merged output shapes (8). Compute explicitly stored float32 score memory in bytes and MiB (4). Explain residual, normalization and positionwise MLP paths in a pre-normalized block (4). Explain why position information and a causal mask solve different problems (4).

### Question 4 Training a tiny transformer 20 points
Give training-loop pseudocode with shifted labels, causal masking, cross entropy, backward pass and optimizer update (8). Describe a future-token perturbation check and a one-batch overfit diagnostic (6). Explain grouped train/dev splitting and why lower training loss does not prove generalization (6).

### Question 5 Generation and instruction following 15 points
Compare greedy decoding and sampling, including temperature (5). Explain what a KV cache stores and why it speeds decoding without learning new facts (4). Distinguish pretraining from instruction SFT (3). Explain why fluent chain-of-thought text does not establish correctness (3).

### Question 6 Beyond text and experimental reasoning 10 points
Compare autoregressive image-token generation with diffusion generation (4). Describe one transformer limitation and a controlled tiny-model experiment to investigate it (6).

## Semester exam 2

### Question 1 Adaptation 20 points

For W shaped [2048,4096] and LoRA rank 16, give A/B shapes and parameter counts, dense count and adapter/dense ratio (8). Explain zero-update initialization (4). Contrast LoRA and QLoRA without assuming four-bit activations (4). Name saved dependencies for adapter reproduction (4).

### Question 2 Fine-tuning study 15 points

A new adapter improves exact tool JSON from 75% to 95% but increases incorrect tool arguments from 5% to 20%. Design a controlled evaluation and release decision (8), identify two possible dataset causes (4), and explain why training loss alone cannot resolve the question (3).

### Question 3 Agent controller 20 points

Write pseudocode for a bounded model/tool loop with typed proposals, schema checks, scope checks, observations and terminal statuses (12). Explain why a step cap is not a call timeout (4). Explain how an invented but valid-looking citation must be handled and what checking its ID cannot establish (4).

### Question 4 MLOps and security 20 points

After changing the embedding model, developers reuse the old vectors and omit tenant scope from answer-cache keys. Explain both failures (6), propose manifest/index migration and cache controls (8), and define regression tests and rollback unit (6).

### Question 5 Performance and scaling 15 points

Average arrival rate is 1.5 requests/s and average time in system is 4 s. Estimate average work in flight and state assumptions (4). Distinguish TTFT and end-to-end latency (3). Calculate ideal four-way speedup for 80% scalable and 20% serial work (4). Explain why this does not predict production p95 or communication cost (4).

### Question 6 Capstone defense 10 points

Your agent is more expensive than the fixed workflow, your adapter shows no reliable improvement, and your retriever measurably improves paraphrase questions. Choose a default release and justify it with the evidence you would present (6). Name two limitations and a focused next experiment (4).
