# Examinations

Each semester exam is two hours, 100 points, closed notes except a blank Python interpreter and calculator. Do not use an LLM or internet during the attempt. Show reasoning, assumptions and units. Afterward, self-grade against `solutions/EXAM_SOLUTIONS.md` and write corrections. Exam points are separate from weekly tests and lab reports.

## Checkpoint A after week 4

20 minutes, diagnostic only. (1) Explain why embedding dimension does not establish model compatibility. (2) Give all single-head attention shapes for T=8,D=32,d_head=16. (3) Describe a mask-leakage test. (4) Explain why attention weights alone do not establish a factual explanation. Use weekly solutions 3–4 to mark each as correct/partial/missing. Repeat the relevant notebook if two or more are missing.

## Checkpoint B after week 8

20 minutes, diagnostic only. (1) Shift labels for [1,4,7,2]. (2) Distinguish chat role serialization from visible role words. (3) Calculate softmax for logits (0,0). (4) Explain a fair CoT versus direct comparison. Use weekly solutions 6–8. A missing label/mask concept must be repaired before the hardware and retrieval block.

## Semester exam 1

### Question 1 Attention and architecture 20 points

For B=2,T=128,D=256,H=8 with standard multi-head attention: give Q/K/V, score, per-head output and merged output shapes (8). Calculate explicitly stored float32 score memory across all heads/batches in bytes and MiB (4). Explain the causal perturbation test (4). Explain why improved training loss after removing the mask is not evidence of a better model (4).

### Question 2 Training and resources 15 points

For a hypothetical 300-million-parameter model, estimate parameter-state memory under a stated 16-byte/parameter training configuration, excluding activations (5). Contrast with 2-byte inference weights (3). Name four other memory sources/qualifications (4). Explain why accumulation cannot solve all OOMs (3).

### Question 3 Retrieval calculations 20 points

Gold evidence is {P,Q}. Lexical ranking is [R,P,S,Q]; dense ranking is [Q,T,P,R]. Compute Recall@3, Hit@3 and reciprocal rank for each (8). With RRF c=0, compute fused scores for P,Q,R and rank those three (6). Explain why c=0 is more top-heavy than c=60 and why these scores are not probabilities (3). Name a fair evaluation control (3).

### Question 4 RAG debugging 20 points

An assistant answers a v2 timeout question with a v1 value, cites a real v1 page, and reports valid JSON. The vector database contains both versions. Give four plausible causes at distinct pipeline stages (8), one discriminating check per cause (8), and explain why a stricter JSON schema is insufficient (4).

### Question 5 Experimental design 15 points

You have 120 labeled documentation questions and a candidate hybrid retriever. Design train/dev/test use and group handling (5), retrieval/answer/resource metrics (5), and a paired uncertainty/error-analysis procedure (5). Explain how indexed documents may remain available without exposing held-out labels.

### Question 6 Delivery judgment 10 points

A candidate improves 5 percentage points overall, introduces wrong-version answers, and has incomplete source hashes. Give a release decision with stated gates (4), minimum repair/evaluation steps (4), and one honest portfolio claim (2).

## Semester exam 2

### Question 1 Adaptation 20 points

For W shaped [2048,4096] and LoRA rank 16, give A/B shapes and parameter counts, dense count and adapter/dense ratio (8). Explain zero-update initialization (4). Contrast LoRA and QLoRA without assuming four-bit activations (4). Name saved dependencies for adapter reproduction (4).

### Question 2 Fine-tuning study 15 points

A new adapter improves exact tool JSON from 75% to 95% but increases incorrect tool arguments from 5% to 20%. Design a controlled evaluation and release decision (8), identify two possible dataset causes (4), and explain why training loss alone cannot resolve the question (3).

### Question 3 Agent controller 20 points

Write pseudocode for a bounded model/tool loop with typed proposals, schema checks, scope checks, observations and terminal statuses (12). Explain why a step cap is not a call timeout (4). Explain how an invented but valid-looking citation must be handled and what checking its ID cannot establish (4).

### Question 4 MLOps and security 20 points

After changing the embedding model, developers reuse the old vectors and omit tenant scope from answer-cache keys. Explain both failures (6), propose manifest/index migration and cache controls (8), and define regression tests and rollback unit (6).

### Question 5 Performance and scaling 15 points

Average arrival rate is 1.5 requests/s and average time in system is 4 s. Estimate average work in flight and state assumptions (4). Distinguish TTFT and end-to-end latency (3). Calculate ideal four-way speedup for 80% scalable and 20% serial work (4). Explain why this does not predict production p95 or communication cost (4).

### Question 6 Capstone defense 10 points

Your agent is more expensive than the fixed workflow, your adapter shows no reliable improvement, and your retriever measurably improves paraphrase questions. Choose a default release and justify it with the evidence you would present (6). Name two limitations and a focused next experiment (4).
