# Weekly tests

Attempt each week's questions in 35–45 minutes without notes, then use the remaining review time to correct them. Each week is 10 points: Q1 3, Q2 3, Q3 4. For calculations, show the formula and units. For design answers, name the assumption and the enforcement/measurement point. Weekly grade is total points divided by 320, scaled to 15% of the course.

## Week 1
1. Distinguish retrieval success, groundedness and task success using one documentation question.
2. A system answers 15/20 tasks and 12 answers are correct. Calculate answered-question accuracy and coverage. What else is needed for overall correctness?
3. Propose a five-class task taxonomy and one measurable requirement per class for your assistant.

## Week 2
1. Explain why token count differs from word or character count, especially for code.
2. A 2048-token context reserves 300 output tokens. Instructions, history and question use 550 input tokens. What is the evidence budget before additional template overhead?
3. Compare autoregressive generation, embedding encoding and diffusion by their outputs and learning/generation objectives.

## Week 3
1. For q=(1,0), a=(0.8,0.6), b=(4,3), compute cosine and raw dot product rankings.
2. Explain why two 384-dimensional embedding models cannot be mixed in an index by default.
3. Design positive and hard-negative pairs for a version-aware documentation retriever. Identify a possible false negative.

## Week 4
1. Give shapes for Q, K, V, scores and output for B=2,T=16,D=64,H=4, using explicit head axes.
2. Compute attention for q=(1,0), keys (1,0),(0,1), values (2,0),(0,4), with sqrt(2) scaling. Then mask the second key.
3. Write a property test for causal attention that would catch future-token leakage without inspecting the mask itself.

## Week 5
1. Explain the role of attention, MLP, normalization and residual paths in a block.
2. Estimate block-matrix parameters for two standard blocks with D=64, ignoring bias and embeddings.
3. Explain how training logits differ from inference's next-token selection, and where position information enters the teaching model.

## Week 6
1. Write input/target sequences from IDs [5,8,2,9]. Distinguish attention masking from loss masking.
2. Compute loss in nats and perplexity if every correct target has probability 0.25.
3. A corpus is chunked with overlap before a random split. Explain a leakage path and repair the pipeline.

## Week 7
1. Explain temperature, greedy decoding and top-p without claiming that any ensures factual accuracy.
2. For logits (2,0), compute the first-token probability at temperatures 1 and 2.
3. A model outputs valid JSON and an existing source ID but the wrong API name. Which validation stages passed and which failed?

## Week 8
1. Distinguish displayed CoT, reasoning training and executable verification.
2. Retry waits are 100,200,400 ms. Give the delay immediately before attempt four and cumulative wait before it; state your assumption.
3. Design a fair comparison of direct answer, decomposition and tool-assisted reasoning, including total inference budget.

## Week 9
1. List major memory components in training and contrast with inference.
2. Calculate KV cache for L=24,B=1,T=2048,Hkv=8,Dhead=64,b=2 bytes. Give bytes and MiB.
3. Explain what gradient accumulation fixes and what it cannot fix when one sequence alone causes OOM.

## Week 10
1. Explain CUDA threads, blocks and the one-dimensional global index.
2. End-to-end time is 20 ms, including a 3 ms kernel. Calculate the new total and speedup if that kernel becomes twice as fast.
3. Specify a correct GPU benchmark protocol, including warmup, synchronization, correctness and transfer boundaries.

## Week 11
1. Compare lexical and dense retrieval for exact identifiers and paraphrased questions.
2. Gold={A,B}, ranking=[C,A,D]. Compute Recall@3, Hit@3 and RR.
3. Explain how to evaluate unsupported questions without assigning arbitrary perfect retrieval recall.

## Week 12
1. Distinguish embedding model, similarity metric, ANN index and vector database.
2. Calculate raw float32 storage for one million 384-dimensional vectors. Name three omitted costs.
3. Design a model/index migration with validation and rollback. Why might post-filtering top-k fail?

## Week 13
1. Describe each boundary from source ingestion to cited answer.
2. A version-comparison answer cites only v2. Explain what it can and cannot support.
3. Design a context-packing strategy that handles source labels, duplicate chunks, output reservation and missing evidence.

## Week 14
1. Explain why reranking cannot repair absent candidates.
2. With c=60, compare RRF for A ranked (1,10) and B ranked (2,2).
3. Propose a controlled ablation of lexical, dense, hybrid and reranked search. What must remain fixed?

## Week 15
1. Distinguish training, development and held-out data in a RAG system whose corpus is readable at inference.
2. A gets 32/40 tasks correct; B gets 34/40. What is the observed difference, and why are paired results needed?
3. Specify how you would calibrate an LLM judge and handle parse failures/timeouts in the denominator.

## Week 16
1. List the artifacts necessary to reproduce RAG v1.
2. Aggregate correctness improves but four wrong-version answers appear. Make a release decision under a zero-cross-version gate.
3. Draft a three-minute demonstration that includes success, insufficiency and a difficult failure case.

## Week 17
1. Map missing evidence, invalid output format and unavailable calculation to likely interventions.
2. Explain answer-only loss masking and why a fully truncated answer is a bad training record.
3. Propose a leakage-aware SFT dataset for your project, with a manual audit and refusal cases.

## Week 18
1. Give shapes of A and B for a LoRA update to W in R^(4096×4096), rank 8.
2. Calculate adapter parameters and their fraction of W. Why should both factors not initialize to zero?
3. Compare LoRA and QLoRA memory components, hardware assumptions and saved-artifact requirements.

## Week 19
1. Explain why falling SFT loss is insufficient evidence for a release.
2. JSON validity rises 80→96%, completeness stays 70%, unsupported-answer rate rises 5→15%. Interpret the result.
3. Specify a controlled base-versus-adapter experiment and a saved/reloaded checkpoint check.

## Week 20
1. Distinguish SFT, RLHF, DPO and distillation.
2. In DPO's sigmoid argument, the preferred response improves +0.4 log units relative to reference and the rejected response improves +0.1. If beta=2, compute the margin and loss.
3. Write a preference rubric that would not automatically reward a long but incorrect answer. Identify a proxy failure.

## Week 21
1. List validation stages between a model proposal and tool execution.
2. Should {timeout_ms:true,retries:0} pass an integer-only schema in Python? Explain and implement the type check.
3. Design tests for unknown tools, extra arguments, arithmetic injection and non-idempotent retry behavior.

## Week 22
1. Distinguish an execution harness and an evaluation harness.
2. A planner always proposes another tool. What must happen with a three-step limit? What does that limit fail to bound?
3. Define typed states and terminal reasons for an agent, including malformed proposals and citation failures.

## Week 23
1. Distinguish context history, structured task state and persistent memory.
2. A summary says “user uses v1” but the user requests a v1/v2 comparison. Diagnose and repair the state representation.
3. Define a task where adaptive planning could outperform a fixed workflow, then design the comparison.

## Week 24
1. Explain why final-answer scoring alone is inadequate for agents.
2. Agent A solves 18/20 tasks with one forbidden call; B solves 17/20 with none. Decide under a zero-forbidden-call gate.
3. Specify a 20-task agent suite with success predicates, failure injections, resource metrics and human audits.

## Week 25
1. List five LLM application artifacts beyond model weights and their dependencies.
2. Which artifacts/checks are affected by changing the prompt versus changing the embedding model?
3. Design a manifest sufficient to reproduce your evaluation, without storing secrets.

## Week 26
1. Distinguish TTFT, inter-token latency, throughput and end-to-end latency.
2. At 2 requests/s and 3 seconds average time in system, estimate average in-flight work. What cannot this predict?
3. Design a load experiment with warm/cold states, lengths, concurrency, failures and p95 reporting.

## Week 27
1. Distinguish logs, metrics and traces with one useful example each.
2. Empty retrieval jumps 3→25% after an index update while model latency is stable. Name three checks to prioritize.
3. Specify a quality alert with window, denominator, sample floor, threshold, response and recovery criterion.

## Week 28
1. Explain why retrieved instructions are not authorization.
2. An answer cache omits tenant scope from its key. Describe a concrete leak and repair it.
3. Threat-model a documentation lookup plus config validator, with enforcement points and residual risks.

## Week 29
1. Distinguish unit, integration, behavioral and quality evaluations in CI.
2. A model rollback leaves a malicious new corpus in place. Explain why rollback failed.
3. Design release gates, a rollback drill and a regression test for one actual project failure.

## Week 30
1. Compare data, tensor and pipeline parallelism; identify what data parallelism leaves replicated.
2. With 70% perfectly scalable work and 30% serial work, calculate ideal four-way speedup.
3. Choose between accumulation, activation checkpointing and state sharding for three distinct bottlenecks; state the costs.

## Week 31
1. Explain diffusion's forward corruption versus autoregressive next-token generation.
2. With alpha_bar=0.64, x0=2 and epsilon=-1, calculate xt.
3. A table loses column relationships during OCR. Explain how retrieval can succeed while the answer fails; propose an extraction evaluation.

## Week 32
1. List evidence supporting an honest claim of independently delivering an LLM application.
2. Fine-tuning fails to outperform the base model. What should be released and reported?
3. Give a five-minute defense plan including one failure, one baseline comparison and reproducibility instructions.
