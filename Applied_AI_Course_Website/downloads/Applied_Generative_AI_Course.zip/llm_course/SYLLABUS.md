# Syllabus and dependency map

The course has a 16-week foundation-and-retrieval semester and a 16-week adaptation-and-delivery semester. Every week has a lecture chapter and a three-question written test. Labs span two weeks. The final report grows from the same documentation assistant throughout.

| Week | Lecture | Lab | Project evidence |
|---:|---|---|---|
| 1 | Generative AI as a measurable system | 01 Baseline and dataset | Charter, task taxonomy, baseline |
| 2 | Tokens and generative model families | 01 | Token/context budget; corpus manifest |
| 3 | Embeddings and similarity | 02 Attention and geometry | Retrieval hypotheses |
| 4 | Attention with shapes and masking | 02 | Checkpoint quiz A; attention tests |
| 5 | Transformer architecture | 03 Tiny language model | Model diagram and parameter count |
| 6 | Pretraining data and optimization | 03 | Loss curve and leakage audit |
| 7 | Decoding and chat interfaces | 04 Small instruction model | Versioned model adapter |
| 8 | Reasoning and chain of thought | 04 | Checkpoint quiz B; reasoning experiment |
| 9 | GPU hardware and resource accounting | 05 Hardware and CUDA | Resource worksheet |
| 10 | CUDA kernels and profiling | 05 | Correctness and timing report |
| 11 | Lexical and semantic retrieval | 06 Semantic retrieval | Search benchmark |
| 12 | Vector databases and ANN | 06 | Persisted, filterable index |
| 13 | RAG and context construction | 07 Grounded generation | Citation and refusal contract |
| 14 | Hybrid retrieval and reranking | 07 | Retrieval ablation |
| 15 | Evaluating the full RAG system | 08 Evaluation harness | Frozen semester evaluation |
| 16 | RAG delivery and semester examination | 08 | RAG v1 and semester report |
| 17 | Adaptation choices and SFT data | 09 Fine-tuning data | Labeled training/dev split |
| 18 | LoRA and QLoRA | 09 | Adapter plan and data audit |
| 19 | Fine-tuning and controlled comparison | 10 LoRA training | Actual adapter checkpoint and metrics |
| 20 | Preference optimization and distillation | 10 | Base versus SFT report |
| 21 | Tools and typed interfaces | 11 Tool controller | Validated tool contracts |
| 22 | Agents and harnesses | 11 | Budgeted controller and traces |
| 23 | Planning and agent memory | 12 Model planner | Workflow versus agent experiment |
| 24 | Agent evaluation and failure recovery | 12 | Agent task benchmark |
| 25 | MLOps lifecycle and provenance | 13 Service and release | Reproducible artifact manifest |
| 26 | Inference serving and performance | 13 | API, latency and load report |
| 27 | Monitoring, tracing, and feedback | 14 Observability | Dashboard specification and alerts |
| 28 | Security and authorization | 14 | Threat model and adversarial suite |
| 29 | CI, release gates, and rollback | 15 Regression and incident | Release decision and rollback drill |
| 30 | Distributed training and efficiency | 15 | Scaling and capacity memo |
| 31 | Multimodal documents and frontier topics | 16 Final reproducibility | Limitations and optional extension |
| 32 | Capstone defense and final examination | 16 | Reproducible release and demo |

## Dependencies

Tokenization precedes shifted next-token loss; embeddings precede attention and retrieval; attention precedes transformer training and KV-cache reasoning. Retrieval metrics precede RAG changes. Frozen evaluations precede tuning and agent comparisons. Typed tools precede model-directed execution. Versioned artifacts precede deployment, monitoring, and rollback.

## Weekly workload exceptions

Default: notes/readings 2h, guided lab 2h, experiment/project 4h, test/review 2h. Week 16: review 1h, lab/evaluation 2h, semester report 3h, exam 2h, correction 2h. Week 32: review 1h, reproducibility 2h, defense/demo 3h, exam 2h, correction 2h. Other project work must fit the four-hour allocation; optional extensions replace other experiments, never expand the compulsory week.

## Scope and depth

Core depth: RAG, semantic retrieval, vector database lifecycle, evaluation, SFT/LoRA, typed tools, agents, inference, MLOps/LLMOps, security and operations. Mechanism depth: attention, decoder transformers, tokenization, optimization, GPU memory and introductory CUDA. Survey depth: VAEs, GANs, diffusion, flow matching, RLHF/DPO/RLVR, MoE, multimodality and distributed training. A survey topic has a defined explanation/test or toy calculation; it does not promise a production implementation.

## If you stop after one semester

Weeks 1–16 form a complete introduction with a measured RAG v1. You will not yet have completed agent delivery, fine-tuning experiments, or the full operations lifecycle. The requested complete path is the full 32 weeks; compressing all topics into 16 weeks at ten hours would require substantially less depth.

## Reading protocol

Each lecture lists reference IDs mapped to links in `REFERENCES.md`. Required reading means the named section or concept for at most 30 minutes; stop and record questions if the paper is too dense. Optional sources provide deeper treatment. No paid textbook, API subscription, or specific GPU allocation is required for the baseline path. Model downloads require internet access and sufficient host RAM/disk.
