# Examination solutions

Award partial credit for correct methods with a minor arithmetic error. Do not award design points for an unmeasured claim such as “use a larger model and it will be correct.” For open questions, the criteria below define a defensible answer, not a unique wording.

## Checkpoint calculations

A: Q/K/V=[8,16] for one head; scores=[8,8]; output=[8,16]. Embedding compatibility and causal tests follow weekly solutions 3–4. B: input [1,4,7], targets [4,7,2]; equal logits produce probabilities [.5,.5]. Chat and reasoning answers follow weeks 7–8.

## Semester exam 1

**Q1 (20).** Q/K/V=[2,8,128,32]; scores=[2,8,128,128]; per-head output=[2,8,128,32]; merged=[2,128,256] (8). Score elements=262144; float32 bytes=1,048,576=1 MiB (4). Perturb a future input with fixed model/eval mode; earlier outputs must remain equal within tolerance (4). Without masking, a target's future token can leak, making training easier while violating autoregressive conditioning (4).

**Q2 (15).** 300,000,000×16=4.8 billion bytes=4.8 GB decimal, about 4.47 GiB (5). Inference weights at 2 bytes=600 MB decimal, about .559 GiB (3). Additional memory: activations, temporaries, allocator reserve, KV cache for inference, precision-specific states or implementation differences; four justified items (4). Accumulation lowers microbatch needs, not a single sequence's minimum footprint or all persistent state (3).

**Q3 (20).** Lexical first three [R,P,S]: recall=.5,hit=1,RR=.5. Dense [Q,T,P]: recall=1,hit=1,RR=1 (8). c=0: P=1/2+1/3=5/6; Q=1/4+1=5/4; R=1+1/4=5/4. Q and R tie, both above P (6). c=0 weights rank one much more strongly; c=60 smooths rank differences. Fusion scores are rank-derived, uncalibrated scores (3). Same documents/chunks/tasks/filters/k and tuning/evaluation protocol; any justified control (3).

**Q4 (20).** Possible causes: source mislabeled v2; retrieval omitted/misapplied filter; context packer mixed versions; generator ignored correct labels or citation validator checked only existence. Four distinct causes earn 8. Checks: inspect source manifest/text; execute raw filtered search; save exact packed context; inspect generated claims/citations against supplied evidence. One discriminating check each earns 8. JSON ensures structure, not version correctness or semantic support (4).

**Q5 (15).** One defensible split: 60 dev/tuning, 30 validation/checkpoint, 30 final test with source/task families grouped; if no model training occurs, no artificial training partition is required. If adapting, reserve an actual train subset and separate dev/test. Keep test labels/questions out of tuning; corpus remains the permitted reference knowledge (5). Retrieval recall/RR, answer facts/grounding/refusal, version errors, latency/tokens/failures and slices (5). Save paired per-task outputs, bootstrap paired differences with assumptions and inspect corrected/new errors; recognize small/correlated test limitations (5). Specific split numbers are not required if justified.

**Q6 (10).** Reject under zero-cross-version and reproducibility gates (4). Fix/filter labels, complete hashes/manifest, rebuild affected artifacts, rerun invariant suite and planned eval without pretending an already-inspected test is untouched (4). Honest claim: independently built and evaluated a documentation RAG prototype, with actual measured numbers only; no invented production usage (2).

## Semester exam 2

**Q1 (20).** A=[16,4096], B=[2048,16]. Adapter=16×(4096+2048)=98,304; dense=2048×4096=8,388,608; ratio=.01171875=1.171875% (8). One random factor/one zero factor yields zero initial delta while allowing gradient flow; both zero can block initial factor learning (4). LoRA trains factors on frozen base; QLoRA additionally quantizes frozen base, retaining higher-precision compute/state where required (4). Base/tokenizer revision, adapter config/weights, target modules, environment, training data/config and eval metadata; four distinct dependencies (4).

**Q2 (15).** Same model/base/context/tasks/decoding/tool validator, separate prompt control, per-task valid JSON and semantic argument correctness, invalid/forbidden actions and budgets; reject if incorrect actions violate gate even though syntax improved (8). Dataset may reward valid format with wrong arguments, omit negative/refusal cases, include wrong-version labels or have leaked paraphrases; two diagnosed causes (4). Loss is fit to labels, and biased/wrong labels can be learned successfully (3).

**Q3 (20).** Initialize scope/state/budgets; for finite steps call planner with controlled context; parse and validate proposal; final validates citations/contract then terminates; tool action validates name/schema/authority/limits, executes with per-call enforcement, records normalized result; catches typed failures; exhausts explicitly. Six meaningful controls/branches at 2 points each (12). A blocking call can exceed wall time before loop checks; real client timeout/process enforcement needed (4). Reject IDs not authorized/observed; existing IDs still do not prove semantic entailment (4).

**Q4 (20).** Incompatible coordinate systems make old vectors unsuitable; missing tenant cache scope can expose restricted answers (6). Manifest embeds model/index/source compatibility, rebuild versioned index, benchmark/switch/rollback; scope-aware cache keys, permission enforcement and invalidation (8). Tests deliberately mismatch embedding manifest and cross tenant requests; roll back coherent prompt/model/adapter/index/tool/corpus config, not weights alone (6).

**Q5 (15).** L=1.5×4=6 average in system, assuming stable averages and correct boundary (4). TTFT until first output token; end-to-end until response finishes including all application stages (3). 1/(.2+.8/4)=2.5 ideal speedup (4). Tail latency depends on variance/load/queueing and distributed work has communication/coordination; no p95 prediction from these means (4).

**Q6 (10).** Prefer qualifying retriever plus fixed workflow/base generator if agent/adapter add no demonstrated value; retain experimental branches and raw comparisons, report budget/quality/safety and actual negative results (6). Limits could be task-set size, small model capability, lack of real users or untested high concurrency. Next experiment must target an observed failure with a control and metric, e.g. reranking the paraphrase misses under a fixed context budget (4).
