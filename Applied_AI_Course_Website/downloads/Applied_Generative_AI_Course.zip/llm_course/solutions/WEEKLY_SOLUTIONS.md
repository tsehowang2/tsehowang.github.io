# Weekly test solutions and marking guide

Use the weekly allocation Q1=3,Q2=3,Q3=4. For open answers award points for distinct correct requirements and their rationale, not for matching wording. Deduct for claims that a prompt, score or schema alone guarantees truth/security. Review each mistake with a runnable counterexample where possible.

## Week 1
1. Retrieval finds the relevant versioned timeout passage; grounding means answer claims follow from it; task success means the answer actually gives the requested setting and usable context. One can occur without the others.
2. Accuracy among answers=12/15=80%; coverage=15/20=75%. Need labels for the five refusals and a definition of task-level correctness to count them.
3. Example: lookup/correct fact+source; comparison/both versions; troubleshooting/supported resolution; calculation/verified value; unsupported/appropriate insufficiency. Award one per justified measurable class, capped at four.

## Week 2
1. Tokenizers use learned subwords/bytes, not a fixed word mapping. Code identifiers, Unicode and role delimiters change counts. Count with the actual model tokenizer.
2. 2048−300−550=1198 tokens, reduced by additional template overhead if not included in 550.
3. Autoregressive predicts next-token distributions and generates sequential tokens; embedding encoding produces a fixed representation for a geometric task; diffusion learns denoising-related targets and generates by reversing corruption. Award distinctions, not a claim that all share one loss.

## Week 3
1. Dot: a=.8,b=4 so b wins. Norms a=1,b=5; cosine=.8 for both, a tie.
2. Coordinates arise from different learned functions/objectives; equal dimensionality says nothing about aligned axes. Re-embed/migrate and evaluate.
3. Positive correct-version paragraph; hard negative same API/wrong version or similar API/wrong semantics. A passage considered negative may also answer the query, creating a false negative. Group/split appropriately.

## Week 4
1. Q/K/V=[2,4,16,16]; scores=[2,4,16,16], with query/key axes; per-head output same shape as Q; merged output=[2,16,64]. State the coincidental equality T=d_head.
2. Logits=(.7071,0), weights≈(.6698,.3302), output≈(1.3395,1.3208). Mask second: weights=(1,0), output=(2,0).
3. Fix parameters and eval mode; perturb token j; earlier positions i<j must remain equal within tolerance. Test several lengths/positions and padding separately. The test checks behavior, not mask syntax.

## Week 5
1. Attention mixes positions; MLP transforms channels per position; normalization controls representation scale; residuals preserve/add information and aid optimization.
2. 2×12×64²=98,304, a rough matrix-only count under stated assumptions.
3. Training supervises next-token logits at every valid input position. Inference selects from the final position and appends. Learned position embeddings are added to token embeddings in the teaching model.

## Week 6
1. Input=[5,8,2], target=[8,2,9]. Attention masks restrict information access; loss masks select supervised targets.
2. Loss=ln4≈1.3863 nats; perplexity=exp(loss)=4. Requires matching tokenization for comparisons.
3. Overlapping chunks from one page can cross splits. Split source/page families first, deduplicate/group, then chunk each partition. Keep held-out question labels away from tuning.

## Week 7
1. Temperature rescales logits for sampling; greedy is argmax; top-p restricts a probability-mass subset. None checks factual support.
2. exp2/(exp2+1)≈.8808; exp1/(exp1+1)≈.7311.
3. Syntax/schema and source-ID existence passed. Claim correctness/semantic citation support failed. Add evidence-based checking; do not conflate a valid ID with entailment.

## Week 8
1. CoT is generated intermediate explanation/prompting; reasoning training changes learned behavior; executable verification checks a result externally. A displayed rationale is not guaranteed internal causality.
2. Assuming attempt one is immediate and waits precede attempts 2–4: last delay=400 ms, cumulative=700 ms. Jitter/caps would require more specification.
3. Same tasks/model/context/decoding where applicable; predeclared answer checker, failures, tokens/time, repeated seeds for sampling; count all candidates and verification calls. Include lookup cases where extra reasoning may not help.

## Week 9
1. Weights, gradients, optimizer moments, optional master weights, activations and temporary/allocator buffers. Inference drops training states but may add a large KV cache.
2. 2×24×1×2048×8×64×2=100,663,296 bytes=96 MiB.
3. Accumulation permits smaller microbatches for the desired effective batch. It does not shrink one sequence's activation footprint or all persistent state; shorten context, checkpoint activations or change/shard the model.

## Week 10
1. Threads execute a kernel; blocks group cooperating threads and schedule independently. i=blockIdx.x×blockDim.x+threadIdx.x, with i<n guard.
2. New total=17+1.5=18.5 ms; speedup=20/18.5≈1.081.
3. CPU reference/tolerance, edge sizes, warmup, CUDA events or synchronization, repeated timings/spread, stated transfer boundary, device/software metadata. No credit for unsynchronized host timing alone.

## Week 11
1. Lexical handles exact symbols well, dense can handle paraphrases; both can fail on versions and require labels/filters. Measure slices instead of declaring a universal winner.
2. Recall=.5; hit=1; RR=.5.
3. Mark retrieval recall not applicable when gold is empty; evaluate false evidence, unsupported answers and correct refusals separately with explicit denominators.

## Week 12
1. Encoder generates coordinates; metric scores them; ANN organizes/searches approximately; database adds persistence/payload/filter/update/operations.
2. 1,000,000×384×4=1,536,000,000 bytes, ~1.43 GiB. Excludes graph, payload/text, IDs, replicas and allocation overhead.
3. Build new compatible collection, check manifest/counts/IDs, benchmark filtered exact/ANN behavior, switch only after gates, retain old collection. Post-filter top-k may discard all candidates before valid relevant candidates were considered.

## Week 13
1. Source→versioned chunks→embeddings/index→authorized candidates→selected context→generation→validation→answer; each transformation retains identity/provenance.
2. V2 source supports its own default, not a claim about v1 or change. Retrieve v1 or admit insufficient comparison evidence.
3. Preserve complete statements/code, deduplicate by parent, label source/version, actual-tokenizer count and output reservation, select useful evidence, explicit insufficiency. Four justified elements earn full credit.

## Week 14
1. Reranker sees only candidate pool; missing evidence must be fixed earlier or via another retrieval step.
2. A=1/61+1/70≈.030679; B=2/62≈.032258; B wins.
3. Same corpus/chunker/tasks/filters/k, model/answer contract and evaluation; vary only retrieval stage. Report candidate recall, final metrics, latency and per-slice failures. Tune only on dev.

## Week 15
1. Train changes parameters; dev selects prompts/thresholds/configs; test estimates held-out performance. Reading indexed documents at inference is intended RAG behavior; using test labels/questions to tune is leakage.
2. Difference=2/40=.05=5 percentage points. Paired outcomes reveal fixes and new errors; resample task pairs for intervals. Small/correlated samples limit inference.
3. Explicit rubric, human calibration, randomized pair order, model/prompt version and disagreement audit; count parse/time failures as failures or separately specified outcomes, never drop silently.

## Week 16
1. Sources/hashes, chunker, embedding/model/tokenizer revisions, index/config, prompt/decoding, software environment, evaluation labels/raw outputs and commands.
2. Reject under the stated gate; diagnose/filter and rerun relevant checks. Aggregate improvement cannot override the invariant.
3. Supported answer with trace/citation, genuine absence/refusal, difficult case/failure diagnosis, plus version and reproduction command. Show observed behavior rather than rehearsed claims alone.

## Week 17
1. Missing evidence→ingestion/retrieval; format errors→schema/prompt then possible SFT; computation→typed tool. Diagnose before weight changes.
2. Ignore prompt labels, supervise answer tokens. If truncation removes every target token, there is no intended training signal and loss can become invalid.
3. Group split before paraphrases; source-backed targets, version labels, unknown cases, provenance, sampled manual/executable audits, frozen independent evaluation. Four justified controls earn full credit.

## Week 18
1. A=[8,4096], B=[4096,8], W=[4096,4096].
2. 65,536 / 16,777,216=.00390625=.390625%. Both zero factors can yield zero gradients initially; initialize one nonzero and one zero for a zero initial update with a trainable path.
3. LoRA freezes base and trains adapters; QLoRA also quantizes base. Both retain activations and some higher-precision states. Check backend/device; save base/tokenizer revisions, adapter config/weights, environment and measured quality.

## Week 19
1. Loss measures fit to training targets, not held-out task quality or regressions. Need application evaluation and reload verification.
2. Format improved; completeness did not; unsupported behavior worsened by 10 percentage points. Do not call it an unqualified improvement; inspect data/reward and gate release.
3. Same inputs/context/base/decoding/evaluator; separate prompt-only changes; dev for tuning; raw paired outputs; save/reload adapter in fresh session and rerun smoke/eval cases.

## Week 20
1. SFT imitates targets; RLHF often optimizes learned preference reward with RL; DPO optimizes preference pairs relative to reference directly; distillation learns from teacher behavior/distributions.
2. Relative margin=.4−.1=.3; scaled margin=.6; loss=−ln(sigmoid(.6))≈.43749.
3. Facts/evidence, completeness, valid action and useful concision; length alone no reward. Proxy failure: fluent verbosity or fabricated citations win over a correct insufficient-evidence answer.

## Week 21
1. Parse, schema/name validation, argument constraints, caller authorization, execution limits, normalized observation and trace. Security must be enforced outside model text.
2. No: `isinstance(True,int)` is true in Python. Use `type(value) is int` or a strict schema validator, then range-check.
3. Reject unknown tools before execution; reject extras; AST restricts expressions and bounds; non-idempotent actions require explicit retry/idempotency policy. Four distinct tests/policies earn full credit.

## Week 22
1. Execution harness runs state/model/tools with budgets; evaluation harness runs tasks/checkers and collects metrics. Both need versions and observability.
2. Stop with budget_exhausted after at most three allowed steps; no fabricated success. Step limits do not bound blocking call duration or all memory/token costs.
3. Fields include question/scope/observations/evidence/budget/status; terminal reasons success, invalid_action, planner/tool error, exhaustion, timeout/cancel. Citation IDs must be previously allowed/observed; semantic support still needs checking.

## Week 23
1. History is interaction text; task state is explicit current constraints/results; persistent memory survives tasks and needs retention/provenance/access policy.
2. Store comparison intent and both allowed versions explicitly; do not use a lossy summary as authorization or source of immutable scope.
3. Conditional config troubleshooting is plausible. Same tasks/tools/budget, compare workflow/agent on completion, valid actions, calls, latency and costs; include simple lookups where workflow may win.

## Week 24
1. Final text can hide wrong/forbidden calls, missing side effects or accidental success. Check trace and environment predicates.
2. A fails the hard gate. B may qualify if other predeclared requirements pass; report both success rates and violations.
3. Mix lookup/calculation/config/unsupported/hostile/failure tasks; expected state/result, allowed actions, bounded retries, trace audit and resource costs. Empty action denominators must be explicit.

## Week 25
1. Corpus/chunks, embeddings/index, prompts, adapters/tokenizers, tool schemas, evaluation data; describe their dependencies.
2. Prompt change→behavioral/quality checks, usually no re-embedding. Embedding change→compatible rebuilt index, retrieval and downstream checks. Record revision differences.
3. Hashes/revisions of code/data/prompt/model/index/tools, configs, environment/device, random seeds, raw outputs and commands. Secret values excluded; identities and required secret names can be documented.

## Week 26
1. TTFT until first token; inter-token subsequent token intervals; throughput completed useful work/time; end-to-end entire interaction including retrieval/queueing/output.
2. L=lambda×W=2×3=6 average in system under stable assumptions. Does not determine safe concurrency, worker count or p95.
3. Fixed representative lengths/tasks, concurrency sweep, warm/cold separation, client timeouts, failures/cancellations, repeated samples and raw timings; state small-sample quantile limits.

## Week 27
1. Log=request event; metric=error rate time series; trace=linked retrieval/generation/tool spans with request ID. Include privacy limits.
2. Check version/payload types and filters, missing point counts/ingestion failures, manifest/index identity. Stable model latency does not exonerate retrieval.
3. Example: 10-min window, requests denominator, >=50 samples, empty retrieval >20%, investigate latest corpus/index/filter change, recover <5% across two windows; thresholds are proposed, not universal defaults.

## Week 28
1. Sources can be attacker-controlled data; instructions cannot expand tool/caller authority. Validate/authorize in code.
2. Tenant A caches restricted answer; B with same question receives it if scope omitted. Include authorization scope and revisions, enforce access again, invalidate on permission change.
3. Assets, attackers and input surfaces; authorized retrieval, typed tool validation, no shell/eval, bounded operations, protected logs/caches; residual prompt influence and incomplete semantic checking. Full credit requires enforcement locations.

## Week 29
1. Unit=function contract; integration=index/API interaction; behavioral=version/refusal/tool invariants; quality=task benchmark and resource tradeoffs.
2. Dependent corpus/index/prompt/tool artifacts were not restored. Roll back a coherent manifest or remove malicious source and rebuild/invalidate affected artifacts.
3. Predeclared hard/soft gates, immutable version, smoke plus quality checks, explicit prior manifest and rollback command, test with a meaningful failure predicate. Do not assert only one hard-coded answer string.

## Week 30
1. Data parallel replicates model and divides batch; tensor divides layer operations; pipeline divides layers/schedules microbatches. Basic data parallel still replicates parameters and usually associated state.
2. 1/(.3+.7/4)=1/.475≈2.1053, before communication overhead.
3. Accumulation→microbatch pressure, more sequential passes; checkpointing→activation pressure, recomputation; state sharding→persistent-state pressure, communication/coordination. Name unresolved parts of each budget.

## Week 31
1. Diffusion adds noise then learns denoising-related predictions and samples in reverse steps; autoregression learns next-token conditionals and extends a sequence. They may coexist in broader systems.
2. sqrt(.64)×2 + sqrt(.36)×(−1)=.8×2−.6=1.0.
3. Right page retrieved but row/column associations lost; evaluate cell values, headers, associations and answer provenance against manually labeled table cases. Compare extraction and reasoning separately.

## Week 32
1. Runnable repository, actual data/model provenance, raw evaluations, baseline/ablation, deployed/local API instructions, observed operations/failure tests and clear individual contributions. No invented work/client claims.
2. Release the better qualifying baseline; report the actual adapter experiment and negative finding with limitations. A training checkpoint is evidence of experimentation, not an automatic product improvement.
3. Architecture/task contract, baseline numbers, supported lookup/tool result/refusal/controlled failure, reproducibility command and limits. Full credit requires evidence links/artifacts rather than a slide-only description.
