# Weekly worked solutions

Use the 3 3 4 allocation. Award partial credit for the correct mechanism with a small arithmetic error. For design questions, require a concrete enforcement or measurement point.

## Week 1

1. The prefix is available input such as “I go to school by.” A distribution scores possible next tokens. Training changes counts/parameters from examples. Inference uses the trained model to predict/select a continuation.
2. There are seven examples. Bus=3/7, train=3/7, bicycle=1/7. These estimate this collection, not real-world commuting frequencies.
3. Likelihood reflects learned patterns, not verified personal facts. Exact-prefix counting cannot automatically share evidence between related but unseen prefixes such as school and work.

## Week 2

1. Text is the original string; the tokenizer defines pieces; vocabulary IDs label those pieces; each ID selects a learned numerical row. ID magnitude is not semantic magnitude.
2. The table contains 100×16=1600 parameters. Seven lookups give [7,16], before batch or context processing.
3. The model associates ID 5 with a particular learned row and output label. An inconsistent reassignment changes the computation/interpretation. A consistent joint relabeling is different from swapping the tokenizer alone.

## Week 3

1. Norm=5, unit vector=[0.6,0.8], cosine=0.6.
2. Dot products are .8 and 4; b wins. Norms are 1 and 5; cosine is .8 for both because directions match.
3. Addition/averaging is invariant to row permutation. Initial lookup uses token identity; a contextual representation also depends on permitted other positions. Position and contextual processing can distinguish ordered sentences.

## Week 4

1. Logits are real scores. Softmax converts them into positive normalized probabilities. Equal logits give [1/3,1/3,1/3].
2. Exponentials normalize to about [.66524,.24473,.09003]. Target loss=-ln(.24473)≈1.4076 nats.
3. A common exponential factor cancels in numerator/denominator. Subtraction improves stability. The gradient is p minus the target one-hot vector.

## Week 5

1. A fixed window exposes a limited set of positions; recurrence carries a compressed evolving state; attention compares queries with accessible key/value positions. Describe actual dependencies rather than a universal ranking of quality.
2. First states=[1,.5,.25,.125]. Second=[0,0,0,1]. The order changes how many transformations each input undergoes.
3. The task determines available information. The encoder receives a complete input. A next-token prediction cannot use its unavailable future target without leakage.

## Week 6

1. It sums over visible key/value positions for one query, not vocabulary entries or different batch items. Valid softmax rows sum to one.
2. First output=[1.4,1.6]. Second=[1.0,2.6]. Each weight applies to every coordinate of its value vector.
3. A normalized mixture stays v. Weights alone do not determine the informational effect; values and subsequent operations matter.

## Week 7

1. They are learned projected representations serving comparison/query, comparison/key, and mixture-information roles. Their names describe computation.
2. Wq/Wk=[4,2], Wv=[4,3]; Q/K=[6,2], V=[6,3], scores=[6,6], output=[6,3].
3. Changing V changes contributed content with unchanged weights. Changing K changes scores and weights, potentially redistributing several value contributions. Cross-attention can use different source lengths.

## Week 8

1. I, go, to, school are visible. The representation at school predicts the next token and cannot use future by/bus input positions.
2. Scores≈[.7071,0], weights≈[.66976,.33024], output≈[1.33952,1.32095]. Correct pre-softmax masking gives weights [1,0], output [2,0].
3. Without renormalization the surviving weights no longer sum to one and output differs. Perturb a future token with fixed eval-mode computation; earlier outputs must remain equal within tolerance. Test the unmasked control to show sensitivity.

## Week 9

1. No. Heads use different learned projections over the allowed positions, usually partitioning feature computation while each may access all visible keys.
2. Dhead=4; Q=[2,3,6,4]; scores=[2,3,6,6]; merged=[2,6,12].
3. Position addition modifies starting features by location. Rotary methods apply position-dependent rotations to query/key coordinate pairs. A causal mask specifies visibility. They address different parts of computation.

## Week 10

1. h=x+Attention(LN(x)); y=h+MLP(LN(h)). Attention mixes positions; the MLP transforms features per position with shared weights.
2. MLP=[64,256] and [256,64], about 8D² parameters. Standard attention adds about 4D²; total≈12D²=49152.
3. Addition needs compatible [B,T,D] tensors. Without a nonlinearity the maps compose into one linear map. Normalization acts over features of each token, not across future tokens.

## Week 11

1. Encoder for a complete-input representation; causal decoder for continuation; encoder-decoder is a common translation arrangement with causal target self-attention and source cross-attention.
2. Scores=[4,7]. Softmax runs over seven source keys for each query. Causal target self-attention instead has [4,4].
3. Training already has the sequence and uses visibility constraints. During generation a selected new token changes the next prefix, so output decisions depend on earlier selections.

## Week 12

1. Input=[3,8,2], targets=[8,2,5]. Causal mask controls information access; loss mask controls supervised prediction positions.
2. Average=(ln2+ln4+ln4)/3≈1.15525; perplexity≈3.1748. Comparisons require compatible tokenization/protocol.
3. Use fixed small data to test implementation, then separate grouped validation examples. Split before overlapping windows and deduplicate near copies. Check shifts and future masking. Overfit success is not generalization.

## Week 13

1. Produce next-token logits from the prefix, select, append, and repeat. Cache earlier layer keys/values when valid under the exact causal prefix/model.
2. For k=2 divide by .8: [.625,.375]. For k=3 divide by .95: approximately [.52632,.31579,.15789].
3. Earlier representations depend on the actual token sequence and model configuration. Length alone does not identify the cached computation. Chat-template or weight changes can invalidate it too.

## Week 14

1. Pretraining learns broad prediction patterns; SFT optimizes desired target responses; prompt demonstrations affect current context without gradient updates; preference methods learn from judged alternatives.
2. Correct=12 dollars. Any plausible-looking explanation ending with an incorrect amount illustrates why fluency is not a correctness checker.
3. They are generated outputs that can be wrong or rationalized. Compare independent final checks and full inference costs; reasoning training, prompts, and verification are distinct interventions.

## Week 15

1. Autoregression predicts sequential conditionals; VAE learns a probabilistic latent/reconstruction formulation; GAN uses a generator-discriminator game; diffusion learns denoising-related predictions across a corruption schedule.
2. xt=.8×2+.6×(-1)=1. At 0 it is -1 (noise); at 1 it is 2 (signal).
3. The visualization knows the original signal and re-evaluates mixtures. A trained reverse process must generate/denoise from appropriate states using learned predictions; it cannot simply reveal a known source.

## Week 16

1. IDs→token/position representations→normalization/QKV/masked attention/head merge/residual→normalization/MLP/residual, repeated→final normalization/output vocabulary logits.
2. IDs=[2,5]; Q=[2,2,5,4]; scores=[2,2,5,5]; logits=[2,5,20].
3. It may exploit future targets or learn same-token copying. Print input/targets, test causal perturbation, evaluate proper held-out next-token loss and generation. Lower loss on the wrong task is not improvement.

## Week 17

1. Lookup row represents token identity; contextual row depends on permitted context; a sentence embedding uses a representation/pooling objective suited to whole-input comparison.
2. Hit=1 and Recall=1/2. A related passage need not provide every required fact.
3. Exact API/error names can favor lexical matching; paraphrases can favor semantic representations. Use same-subject wrong-version or bus-departure versus school-opening distractors. Measure actual outcomes.

## Week 18

1. Stable IDs, payload/source references, scope/version and content lineage. Mislabeling survives even a correct nearest-neighbor computation.
2. 1,536,000,000 bytes, before graph, payloads, IDs, replicas, text, and overhead.
3. Build compatible re-embedded collection, verify/benchmark, switch with rollback. Unfiltered top-k may omit eligible relevant points before invalid candidates are removed.

## Week 19

1. Find supporting passages; choose/label what fits; generate a response conditioned on question and evidence. Each boundary can fail independently.
2. State the supported time and missing fare, or explicitly say the complete question lacks sufficient evidence. Do not fabricate fare or cite time evidence for it.
3. Enforce eligible sources; verify cited IDs; audit whether each claim follows from them; verify required facts are all addressed. Valid JSON/IDs alone cannot prove grounding.

## Week 20

1. It sees only its candidate pool; absent necessary evidence cannot be restored by reordering.
2. A≈.030679, B≈.032258. B wins. Scores are rank-derived, not truth probabilities.
3. Hold corpus/chunks/tasks/filters/generator/budgets/evaluator fixed. Measure candidate recall and final claims, latency, calls and failures; tune on dev only.

## Week 21

1. Correct facts may be incomplete; supported claims must follow from sources; coverage is fraction answered; refusals must match actual absence. Give task-based examples.
2. 80% selective accuracy; 75% coverage. Need refusal labels to compute complete decision correctness.
3. Observed gap=5 points. Inspect fixes/new errors, resample matched tasks with correlation caveats, calibrate judge rubric against reviewed labels and retain failures.

## Week 22

1. Weights, gradients, moments, optional master weights, activations/buffers; generation additionally has context-dependent KV state. Device/allocator behavior matters.
2. 2×24×1×2048×8×64×2=100663296 bytes=96 MiB.
3. Accumulation shrinks microbatch needs but not all persistent state or a single sequence minimum. Checkpointing trades recomputation for some activation storage. Identify the actual component.

## Week 23

1. i=blockIdx.x×blockDim.x+threadIdx.x; two blocks give 512 threads; only i<257 accesses arrays.
2. New total=18.5 ms, speedup=20/18.5≈1.081.
3. CPU reference/tolerances and awkward sizes, warmup, synchronization/events, repeated timings/spread, transfer boundary, actual device/software metadata and saved workload/trace.

## Week 24

1. Improve ingestion/retrieval, prompt/schema or targeted SFT for persistent format gaps, and a checked narrow tool for arithmetic. Diagnose before training.
2. Keep prompt as context with ignored labels, supervise answer under the library shift convention, ensure nonzero valid target count and compatible template prefix.
3. Split families before paraphrases, review source-backed targets, retain provenance, audit uncertainty/absence and wrong versions, reserve final tasks from tuning/adaptation.

## Week 25

1. A=[8,4096], B=[4096,8]; 65536 parameters versus 16777216 dense, .390625%.
2. BA=[[.1,.2],[.2,.4]], output=[.3,.6]. Tiny 2×2 rank1 uses four factor entries, so it does not yet save parameter count.
3. One nonzero/one zero factor allows zero initial update with gradient path; both zero can stall. Frozen base/activations remain. QLoRA quantizes base while retaining higher-precision states/compute where required.

## Week 26

1. It measures fit to provided targets. Independent correctness, refusals, semantic arguments and regressions determine release quality.
2. Margin=.3, scaled=.6, loss=-ln(sigmoid(.6))≈.43749. This is an objective calculation, not proof of good labels.
3. Pin base/data/templates/decoding, control prompt changes, retain paired outputs and failures, save/reload exact artifacts and smoke/evaluate them. Release the stronger qualifying baseline if no gain.

## Week 27

1. Tool exposes a contracted capability; workflow largely fixes action order; agent lets model outputs influence next actions while controller retains enforcement.
2. Expression 2*4+1*2 is proposed; validated calculator returns 10; final response must match and use correct price evidence.
3. Reject unknown tools, extra keys, booleans as strict integers, unsupported AST nodes, numeric/size violations and wrong scope. Domain-invalid config differs from invalid call schema; never eval model code.

## Week 28

1. Execution runs controlled state/actions; evaluation checks tasks. History, structured current task state, and persistent memory have different provenance/retention/trust.
2. Stop with budget_exhausted after at most the allowed proposals. A step cap alone does not interrupt blocking calls or bound all time/memory/token use.
3. Same tasks/tools/budgets; independent state/result predicates; call/scope failures, forbidden actions, costs and termination. Audit traces, including accidental-looking final success and unnecessary actions.

## Week 29

1. Corpus/chunker, embeddings/index, tokenizer/adapter, prompt, tools, environment, evaluation records and configs; identify changed-dependency effects.
2. Average=6 under stable matching boundaries. This does not specify worker count, p95, or saturation behavior.
3. Pin artifacts, validate schema/scope/failures, measure actual generator with lengths/concurrency/warm/cold and timeouts, save raw timings, reproduce fresh. Label the instructional extractor appropriately.

## Week 30

1. Latency/errors/queues; evidence/answer/refusal measures; event logs; connected per-request spans. Interpret traffic/corpus changes and protect logged content.
2. The source/index/context/cache dependencies can remain malicious. Restore a coherent release or remove/rebuild/invalidate affected artifacts and verify.
3. Authorize/validate outside text, scope caches and source fetches, enforce typed tools, run invariant and quality gates, retain compatible rollback and meaningful incident regression tests.

## Week 31

1. Preserve scope, retrieve both required rules, pack sources, perform validated tool work if needed, form claims, validate/audit support and task success.
2. 1/(.3+.7/4)=2.1053 before communication/coordination overhead.
3. Use the stronger qualifying retrieval/base/workflow configuration; retain measured experimental branches, report uncertainty and limits, choose a focused next experiment rather than inventing gains.

## Week 32

1. Explain token/position/block/logit/generation mechanism first, then external evidence selection and authorized execution around it. Model weights and application controls have distinct roles.
2. Runnable code/manifest, actual data/model provenance, raw evaluations, controlled comparisons, observed API/operations/failure checks, clear contributions and limitations.
3. Show baseline, one controlled change, success/absence/failure examples and reproduction. Choose a measured unresolved bottleneck, define next hypothesis/control/metric, and distinguish proposals from completed work.
